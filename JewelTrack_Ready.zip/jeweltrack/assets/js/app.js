/**
 * JewelTrack — Frontend JavaScript
 * Vanilla JS for UI interactions only.
 * All calculations and business logic happen on the server.
 */

/* ============================================================
   Sidebar Toggle
   ============================================================ */
(function () {
  const sidebar    = document.getElementById('sidebar');
  const wrapper    = document.getElementById('mainWrapper');
  const toggleBtn  = document.getElementById('sidebarToggle');
  const overlay    = document.getElementById('sidebarOverlay');

  if (!sidebar) return;

  const COLLAPSED_KEY = 'jt_sidebar_collapsed';

  function setCollapsed(collapsed) {
    sidebar.classList.toggle('collapsed', collapsed);
    wrapper.classList.toggle('sidebar-collapsed', collapsed);
    localStorage.setItem(COLLAPSED_KEY, collapsed ? '1' : '0');
  }

  // Restore state
  const saved = localStorage.getItem(COLLAPSED_KEY);
  if (saved === '1') setCollapsed(true);

  toggleBtn?.addEventListener('click', () => {
    const isMobile = window.innerWidth <= 768;
    if (isMobile) {
      sidebar.classList.toggle('mobile-open');
      overlay?.classList.toggle('d-none');
    } else {
      setCollapsed(!sidebar.classList.contains('collapsed'));
    }
  });

  overlay?.addEventListener('click', () => {
    sidebar.classList.remove('mobile-open');
    overlay.classList.add('d-none');
  });
})();

/* ============================================================
   Auto-dismiss alerts after 4 s
   ============================================================ */
document.querySelectorAll('.alert.alert-dismissible').forEach(el => {
  setTimeout(() => {
    const bsAlert = bootstrap.Alert.getOrCreateInstance(el);
    if (bsAlert) bsAlert.close();
  }, 4000);
});

/* ============================================================
   Confirm delete / destructive actions
   ============================================================ */
document.querySelectorAll('[data-confirm]').forEach(el => {
  el.addEventListener('click', function (e) {
    const msg = this.getAttribute('data-confirm') || 'Are you sure?';
    if (!confirm(msg)) e.preventDefault();
  });
});

/* ============================================================
   Sale / Purchase Line-item Calculator (client-side preview only)
   Server recalculates on submit.
   ============================================================ */
function recalcLines() {
  let subtotal = 0;
  document.querySelectorAll('.line-item-row').forEach(row => {
    const qty   = parseFloat(row.querySelector('.item-qty')?.value)  || 0;
    const price = parseFloat(row.querySelector('.item-price')?.value) || 0;
    const total = qty * price;
    const totalEl = row.querySelector('.item-line-total');
    if (totalEl) totalEl.textContent = '₹ ' + total.toLocaleString('en-IN', {minimumFractionDigits: 2});
    subtotal += total;
  });

  const discEl   = document.getElementById('discount');
  const taxRateEl = document.getElementById('tax_rate');
  const subEl    = document.getElementById('preview_subtotal');
  const taxEl    = document.getElementById('preview_tax');
  const grandEl  = document.getElementById('preview_grand');

  if (!subEl) return;

  const discount = parseFloat(discEl?.value) || 0;
  const taxRate  = parseFloat(taxRateEl?.value) || 0;
  const taxable  = Math.max(0, subtotal - discount);
  const tax      = taxable * taxRate / 100;
  const grand    = taxable + tax;

  subEl.textContent  = '₹ ' + subtotal.toLocaleString('en-IN', {minimumFractionDigits: 2});
  taxEl.textContent  = '₹ ' + tax.toLocaleString('en-IN', {minimumFractionDigits: 2});
  grandEl.textContent = '₹ ' + grand.toLocaleString('en-IN', {minimumFractionDigits: 2});
}

document.addEventListener('input', function (e) {
  if (e.target.matches('.item-qty, .item-price, #discount, #tax_rate')) {
    recalcLines();
  }
});

/* ============================================================
   Product search autocomplete (for sale/purchase forms)
   ============================================================ */
function initProductSearch(inputEl, hiddenIdEl, onSelect) {
  if (!inputEl) return;
  let timer;
  const dropdown = document.createElement('ul');
  dropdown.className = 'list-group position-absolute w-100 shadow z-3';
  dropdown.style.top = '100%';
  dropdown.style.maxHeight = '220px';
  dropdown.style.overflowY = 'auto';
  dropdown.style.display = 'none';
  inputEl.parentElement.style.position = 'relative';
  inputEl.parentElement.appendChild(dropdown);

  inputEl.addEventListener('input', () => {
    clearTimeout(timer);
    const q = inputEl.value.trim();
    if (q.length < 2) { dropdown.style.display = 'none'; return; }
    timer = setTimeout(async () => {
      const resp = await fetch('/jeweltrack/includes/ajax/product_search.php?q=' + encodeURIComponent(q));
      const data = await resp.json();
      dropdown.innerHTML = '';
      if (!data.length) {
        dropdown.innerHTML = '<li class="list-group-item text-muted fs-13">No products found</li>';
      } else {
        data.forEach(p => {
          const li = document.createElement('li');
          li.className = 'list-group-item list-group-item-action fs-13 cursor-pointer';
          li.innerHTML = `<strong>${p.name}</strong> <span class="text-muted">(${p.sku})</span>
            <span class="float-end text-success">₹${parseFloat(p.selling_price).toLocaleString('en-IN')}</span>
            <br><small class="text-muted">Stock: ${p.quantity}</small>`;
          li.addEventListener('click', () => {
            inputEl.value = `${p.name} (${p.sku})`;
            if (hiddenIdEl) hiddenIdEl.value = p.id;
            dropdown.style.display = 'none';
            if (onSelect) onSelect(p);
          });
          dropdown.appendChild(li);
        });
      }
      dropdown.style.display = 'block';
    }, 250);
  });

  document.addEventListener('click', e => {
    if (!inputEl.contains(e.target)) dropdown.style.display = 'none';
  });
}

/* ============================================================
   Add line item row (sales / purchases)
   ============================================================ */
let lineCount = 0;

function addLineItem(container, type) {
  lineCount++;
  const idx = lineCount;
  const priceLabel = type === 'sale' ? 'Unit Price' : 'Unit Cost';
  const priceField = type === 'sale' ? 'unit_price' : 'unit_cost';

  const html = `
  <div class="line-item-row border rounded-10 p-3 mb-2 position-relative" id="line_${idx}">
    <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 remove-line"
            onclick="removeLine(${idx})" title="Remove item">
      <i class="bi bi-x-lg"></i>
    </button>
    <div class="row g-2">
      <div class="col-md-4">
        <label class="form-label">Product <span class="text-danger">*</span></label>
        <div>
          <input type="text" class="form-control product-search-input" placeholder="Search by name or SKU…" autocomplete="off">
          <input type="hidden" name="items[${idx}][product_id]" class="product-id-hidden" required>
        </div>
      </div>
      <div class="col-md-2">
        <label class="form-label">Available</label>
        <input type="text" class="form-control item-stock" readonly placeholder="—">
      </div>
      <div class="col-md-2">
        <label class="form-label">Qty <span class="text-danger">*</span></label>
        <input type="number" name="items[${idx}][quantity]" class="form-control item-qty" min="1" value="1" required>
      </div>
      <div class="col-md-2">
        <label class="form-label">${priceLabel} <span class="text-danger">*</span></label>
        <input type="number" name="items[${idx}][${priceField}]" class="form-control item-price" step="0.01" min="0" required>
      </div>
      <div class="col-md-2">
        <label class="form-label">Line Total</label>
        <div class="form-control bg-light text-end item-line-total fw-600">₹ 0.00</div>
      </div>
    </div>
  </div>`;

  container.insertAdjacentHTML('beforeend', html);
  const row        = document.getElementById('line_' + idx);
  const searchInput = row.querySelector('.product-search-input');
  const hiddenId    = row.querySelector('.product-id-hidden');
  const stockField  = row.querySelector('.item-stock');
  const priceInput  = row.querySelector('.item-price');

  initProductSearch(searchInput, hiddenId, p => {
    stockField.value = p.quantity;
    priceInput.value = type === 'sale' ? p.selling_price : p.purchase_cost;
    recalcLines();
  });
}

function removeLine(idx) {
  document.getElementById('line_' + idx)?.remove();
  recalcLines();
}

/* ============================================================
   Charts — initialise only when canvas present
   ============================================================ */
function initDashboardCharts(salesData, categoryData) {
  // 7-day Sales Chart
  const salesCtx = document.getElementById('salesChart');
  if (salesCtx && salesData) {
    new Chart(salesCtx, {
      type: 'bar',
      data: {
        labels: salesData.labels,
        datasets: [{
          label: 'Sales (₹)',
          data: salesData.values,
          backgroundColor: 'rgba(201,164,92,0.7)',
          borderColor: '#C9A45C',
          borderWidth: 2,
          borderRadius: 6,
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: ctx => '₹ ' + ctx.raw.toLocaleString('en-IN') } }
        },
        scales: {
          y: { beginAtZero: true, grid: { color: '#f0f0f0' } },
          x: { grid: { display: false } }
        }
      }
    });
  }

  // Category Doughnut
  const catCtx = document.getElementById('categoryChart');
  if (catCtx && categoryData) {
    new Chart(catCtx, {
      type: 'doughnut',
      data: {
        labels: categoryData.labels,
        datasets: [{
          data: categoryData.values,
          backgroundColor: [
            '#123D32','#C9A45C','#1a5244','#e0b97e','#2d7a60',
            '#f0c888','#3d9b7c','#f5dba0','#0B2923','#a07830',
          ],
          borderWidth: 2,
          borderColor: '#fff',
        }]
      },
      options: {
        responsive: true,
        cutout: '65%',
        plugins: { legend: { position: 'right', labels: { font: { size: 11 }, padding: 14 } } }
      }
    });
  }
}

/* ============================================================
   Print invoice
   ============================================================ */
function printInvoice() { window.print(); }

/* ============================================================
   Expose globals
   ============================================================ */
window.JT = { addLineItem, removeLine, recalcLines, initDashboardCharts, printInvoice };
