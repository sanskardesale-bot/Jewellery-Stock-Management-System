<?php
/**
 * JewelTrack — Application Configuration
 * Central place for app-wide constants and settings.
 */

// ---------- Environment ----------
define('APP_DEBUG', true);   // Set false in production
define('APP_NAME', 'JewelTrack');
define('APP_VERSION', '1.0.0');

// ---------- Paths ----------
define('BASE_PATH', dirname(__DIR__));          // /jeweltrack
define('UPLOAD_PATH', BASE_PATH . '/assets/uploads/products/');
define('UPLOAD_URL',  '/jeweltrack/assets/uploads/products/');

// ---------- Upload limits ----------
define('MAX_UPLOAD_SIZE', 2 * 1024 * 1024);   // 2 MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg','image/png','image/webp']);
define('ALLOWED_IMAGE_EXTS',  ['jpg','jpeg','png','webp']);

// ---------- Pagination ----------
define('PER_PAGE', 20);

// ---------- Session ----------
define('SESSION_LIFETIME', 3600 * 2);   // 2 hours

// ---------- Load core includes ----------
require_once BASE_PATH . '/config/database.php';
require_once BASE_PATH . '/includes/functions.php';
require_once BASE_PATH . '/includes/auth.php';

// Kick off / validate session
initSession();
