<?php
/**
 * JewelTrack — Database Configuration
 * Uses PDO for all database operations.
 */

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'jeweltrack_db');
define('DB_USER', 'root');
define('DB_PASS', '');   // Change for production
define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a singleton PDO connection.
 */
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
        );
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Show a user-friendly error; log the real message in production
            if (defined('APP_DEBUG') && APP_DEBUG) {
                die('<pre style="color:red">DB Connection Error: ' . htmlspecialchars($e->getMessage()) . '</pre>');
            }
            die('<p style="color:red;font-family:sans-serif">Database connection failed. Please contact the administrator.</p>');
        }
    }
    return $pdo;
}
