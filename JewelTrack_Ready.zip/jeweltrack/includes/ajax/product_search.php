<?php
/**
 * JewelTrack — AJAX Product Search
 * Returns JSON array of matching active products.
 */
require_once __DIR__ . '/../../config/app.php';
requireLogin();

header('Content-Type: application/json');

$q = trim($_GET['q'] ?? '');
if (strlen($q) < 2) { echo '[]'; exit; }

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id, sku, name, quantity, purchase_cost, selling_price
     FROM products
     WHERE is_active=1 AND (name LIKE ? OR sku LIKE ?)
     ORDER BY name LIMIT 15"
);
$stmt->execute(["%$q%", "%$q%"]);
echo json_encode($stmt->fetchAll());
