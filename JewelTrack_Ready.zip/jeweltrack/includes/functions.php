<?php
/**
 * JewelTrack — Shared Helper Functions
 */

// ============================================================
// Output sanitisation
// ============================================================
function e(mixed $val): string {
    return htmlspecialchars((string)$val, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// ============================================================
// Flash messages
// ============================================================
function setFlash(string $type, string $msg): void {
    $_SESSION['flash_' . $type] = $msg;
}

function getFlash(string $type): ?string {
    $msg = $_SESSION['flash_' . $type] ?? null;
    unset($_SESSION['flash_' . $type]);
    return $msg;
}

function renderFlash(): void {
    foreach (['success','error','warning','info'] as $type) {
        $msg = getFlash($type);
        if ($msg) {
            $icon = match($type) {
                'success' => 'check-circle-fill',
                'error'   => 'x-circle-fill',
                'warning' => 'exclamation-triangle-fill',
                default   => 'info-circle-fill',
            };
            echo "<div class=\"alert alert-{$type} alert-dismissible fade show d-flex align-items-center gap-2\" role=\"alert\">"
               . "<i class=\"bi bi-{$icon}\"></i><span>" . e($msg) . "</span>"
               . "<button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\"></button></div>";
        }
    }
}

// ============================================================
// Currency formatting
// ============================================================
function formatMoney(float $amount, string $symbol = '₹'): string {
    return $symbol . ' ' . number_format($amount, 2, '.', ',');
}

function getSetting(string $key, string $default = ''): string {
    static $cache = [];
    if (!isset($cache[$key])) {
        try {
            $stmt = getDB()->prepare('SELECT setting_val FROM settings WHERE setting_key = ? LIMIT 1');
            $stmt->execute([$key]);
            $row = $stmt->fetch();
            $cache[$key] = $row ? (string)$row['setting_val'] : $default;
        } catch (Throwable) {
            $cache[$key] = $default;
        }
    }
    return $cache[$key];
}

function currencySymbol(): string {
    return getSetting('currency_symbol', '₹');
}

// ============================================================
// Activity log
// ============================================================
function logActivity(string $action, ?string $entityType = null, ?int $entityId = null, ?string $description = null): void {
    try {
        $userId = $_SESSION['user_id'] ?? null;
        $ip     = $_SERVER['REMOTE_ADDR'] ?? null;
        $stmt   = getDB()->prepare(
            'INSERT INTO activity_logs (user_id, action, entity_type, entity_id, description, ip_address)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$userId, $action, $entityType, $entityId, $description, $ip]);
    } catch (Throwable) {
        // Never let logging failure break the application
    }
}

// ============================================================
// Pagination
// ============================================================
function paginate(int $totalRows, int $currentPage, int $perPage = PER_PAGE): array {
    $totalPages = max(1, (int)ceil($totalRows / $perPage));
    $currentPage = max(1, min($currentPage, $totalPages));
    $offset = ($currentPage - 1) * $perPage;
    return [
        'total'        => $totalRows,
        'per_page'     => $perPage,
        'current_page' => $currentPage,
        'total_pages'  => $totalPages,
        'offset'       => $offset,
    ];
}

function renderPagination(array $pager, string $baseUrl): string {
    if ($pager['total_pages'] <= 1) return '';
    $html = '<nav><ul class="pagination pagination-sm mb-0">';
    // Prev
    $disabled = $pager['current_page'] <= 1 ? ' disabled' : '';
    $prevUrl  = $baseUrl . '&page=' . ($pager['current_page'] - 1);
    $html .= "<li class=\"page-item{$disabled}\"><a class=\"page-link\" href=\"{$prevUrl}\">‹ Prev</a></li>";
    // Pages
    $start = max(1, $pager['current_page'] - 2);
    $end   = min($pager['total_pages'], $pager['current_page'] + 2);
    for ($i = $start; $i <= $end; $i++) {
        $active = $i === $pager['current_page'] ? ' active' : '';
        $url    = $baseUrl . '&page=' . $i;
        $html  .= "<li class=\"page-item{$active}\"><a class=\"page-link\" href=\"{$url}\">{$i}</a></li>";
    }
    // Next
    $disabled = $pager['current_page'] >= $pager['total_pages'] ? ' disabled' : '';
    $nextUrl  = $baseUrl . '&page=' . ($pager['current_page'] + 1);
    $html .= "<li class=\"page-item{$disabled}\"><a class=\"page-link\" href=\"{$nextUrl}\">Next ›</a></li>";
    $html .= '</ul></nav>';
    return $html;
}

// ============================================================
// Reference number generators
// ============================================================
function generatePurchaseRef(): string {
    $db   = getDB();
    $year = date('Y');
    $stmt = $db->query("SELECT COUNT(*) FROM purchases WHERE YEAR(purchase_date) = $year");
    $count = (int)$stmt->fetchColumn();
    return sprintf('PO-%s-%04d', $year, $count + 1);
}

function generateInvoiceNumber(): string {
    $db   = getDB();
    $year = date('Y');
    $stmt = $db->query("SELECT COUNT(*) FROM sales WHERE YEAR(sale_date) = $year");
    $count = (int)$stmt->fetchColumn();
    return sprintf('INV-%s-%04d', $year, $count + 1);
}

// ============================================================
// Image upload helper
// ============================================================
function uploadProductImage(array $file): array {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'File upload error.'];
    }
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return ['success' => false, 'message' => 'Image exceeds 2 MB limit.'];
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mime, ALLOWED_IMAGE_TYPES, true)) {
        return ['success' => false, 'message' => 'Only JPEG, PNG, and WebP images are allowed.'];
    }
    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = bin2hex(random_bytes(16)) . '.' . strtolower($ext);
    $dest     = UPLOAD_PATH . $filename;
    if (!is_dir(UPLOAD_PATH)) {
        mkdir(UPLOAD_PATH, 0755, true);
    }
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return ['success' => false, 'message' => 'Failed to save uploaded file.'];
    }
    return ['success' => true, 'filename' => $filename];
}

// ============================================================
// Stock badge
// ============================================================
function stockBadge(int $qty, int $reorder): string {
    if ($qty === 0) {
        return '<span class="badge bg-danger">Out of Stock</span>';
    }
    if ($qty <= $reorder) {
        return '<span class="badge bg-warning text-dark">Low Stock</span>';
    }
    return '<span class="badge bg-success">In Stock</span>';
}

// ============================================================
// Date helpers
// ============================================================
function dateRange(): array {
    $from = $_GET['date_from'] ?? date('Y-m-01');
    $to   = $_GET['date_to']   ?? date('Y-m-d');
    return [
        'from' => $from,
        'to'   => $to,
    ];
}

// ============================================================
// Safe redirect
// ============================================================
function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

// ============================================================
// POST/Redirect/GET helper — check double submit
// ============================================================
function preventDoubleSubmit(string $key): bool {
    $token = $_POST['form_token'] ?? '';
    if (empty($token)) return false;
    if (isset($_SESSION['used_tokens'][$key][$token])) {
        return true; // already submitted
    }
    $_SESSION['used_tokens'][$key][$token] = true;
    // Keep only last 20 tokens per key
    if (count($_SESSION['used_tokens'][$key]) > 20) {
        array_shift($_SESSION['used_tokens'][$key]);
    }
    return false;
}

function formToken(): string {
    return bin2hex(random_bytes(16));
}

// ============================================================
// CSV export header
// ============================================================
function sendCsvHeaders(string $filename): void {
    header('Content-Type: text/csv; charset=UTF-8');
    header("Content-Disposition: attachment; filename=\"{$filename}\"");
    header('Cache-Control: no-cache, no-store, must-revalidate');
    // UTF-8 BOM for Excel compatibility
    echo "\xEF\xBB\xBF";
}
