<?php
/**
 * JewelTrack — Page Header (HTML head + sidebar open)
 * Include at top of every protected page.
 *
 * Variables that can be set before including:
 *   $pageTitle   - tab/page title
 *   $activePage  - sidebar active key
 */

require_once __DIR__ . '/../config/app.php';
requireLogin();

$pageTitle  = $pageTitle  ?? 'Dashboard';
$activePage = $activePage ?? '';
$shopName   = getSetting('shop_name', 'JewelTrack');
$userName   = $_SESSION['user_name'] ?? 'User';
$userRole   = $_SESSION['user_role'] ?? 'staff';
$initials   = strtoupper(substr($userName, 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="JewelTrack — Jewellery Inventory &amp; Stock Management System">
  <title><?= e($pageTitle) ?> — <?= e($shopName) ?></title>

  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap 5 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- App CSS -->
  <link rel="stylesheet" href="/jeweltrack/assets/css/style.css">
</head>
<body>

<!-- Sidebar Overlay (mobile) -->
<div id="sidebarOverlay" class="d-none position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-50" style="z-index:1039;"></div>

<!-- ============================================================
     SIDEBAR
     ============================================================ -->
<nav class="sidebar" id="sidebar" role="navigation" aria-label="Main navigation">

  <!-- Brand -->
  <a href="/jeweltrack/dashboard.php" class="sidebar-brand">
    <div class="brand-icon"><i class="bi bi-gem"></i></div>
    <span class="brand-text"><?= e($shopName) ?></span>
  </a>

  <!-- Nav Links -->
  <ul class="sidebar-nav list-unstyled">

    <li><span class="sidebar-section-title">Main</span></li>

    <li class="nav-item">
      <a href="/jeweltrack/dashboard.php"
         class="nav-link <?= $activePage === 'dashboard' ? 'active' : '' ?>">
        <i class="bi bi-speedometer2"></i>
        <span class="nav-label">Dashboard</span>
      </a>
    </li>

    <li><span class="sidebar-section-title">Inventory</span></li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/products/index.php"
         class="nav-link <?= $activePage === 'products' ? 'active' : '' ?>">
        <i class="bi bi-grid-3x3-gap"></i>
        <span class="nav-label">Jewellery Inventory</span>
      </a>
    </li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/categories/index.php"
         class="nav-link <?= $activePage === 'categories' ? 'active' : '' ?>">
        <i class="bi bi-tag"></i>
        <span class="nav-label">Categories</span>
      </a>
    </li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/stock/index.php"
         class="nav-link <?= $activePage === 'stock' ? 'active' : '' ?>">
        <i class="bi bi-arrow-left-right"></i>
        <span class="nav-label">Stock Movements</span>
      </a>
    </li>

    <li><span class="sidebar-section-title">Transactions</span></li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/purchases/index.php"
         class="nav-link <?= $activePage === 'purchases' ? 'active' : '' ?>">
        <i class="bi bi-cart-plus"></i>
        <span class="nav-label">Purchases</span>
      </a>
    </li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/sales/index.php"
         class="nav-link <?= $activePage === 'sales' ? 'active' : '' ?>">
        <i class="bi bi-receipt-cutoff"></i>
        <span class="nav-label">Sales &amp; Billing</span>
      </a>
    </li>

    <li><span class="sidebar-section-title">Contacts</span></li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/suppliers/index.php"
         class="nav-link <?= $activePage === 'suppliers' ? 'active' : '' ?>">
        <i class="bi bi-truck"></i>
        <span class="nav-label">Suppliers</span>
      </a>
    </li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/customers/index.php"
         class="nav-link <?= $activePage === 'customers' ? 'active' : '' ?>">
        <i class="bi bi-people"></i>
        <span class="nav-label">Customers</span>
      </a>
    </li>

    <li><span class="sidebar-section-title">Reports</span></li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/reports/index.php"
         class="nav-link <?= $activePage === 'reports' ? 'active' : '' ?>">
        <i class="bi bi-bar-chart-line"></i>
        <span class="nav-label">Reports &amp; Analytics</span>
      </a>
    </li>

    <?php if (isAdmin()): ?>
    <li><span class="sidebar-section-title">Administration</span></li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/users/index.php"
         class="nav-link <?= $activePage === 'users' ? 'active' : '' ?>">
        <i class="bi bi-person-lock"></i>
        <span class="nav-label">User Management</span>
      </a>
    </li>

    <li class="nav-item">
      <a href="/jeweltrack/modules/settings/index.php"
         class="nav-link <?= $activePage === 'settings' ? 'active' : '' ?>">
        <i class="bi bi-gear"></i>
        <span class="nav-label">Settings</span>
      </a>
    </li>
    <?php endif; ?>

  </ul><!-- /.sidebar-nav -->

  <!-- Sidebar Footer -->
  <div class="sidebar-footer">
    <a href="/jeweltrack/logout.php"
       class="nav-link text-danger"
       data-confirm="Are you sure you want to logout?"
       style="border-radius:8px;">
      <i class="bi bi-box-arrow-left"></i>
      <span class="nav-label">Logout</span>
    </a>
  </div>
</nav>
<!-- /SIDEBAR -->

<!-- ============================================================
     MAIN WRAPPER
     ============================================================ -->
<div class="main-wrapper" id="mainWrapper">

  <!-- TOPBAR -->
  <header class="topbar" role="banner">
    <div class="topbar-left">
      <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
      </button>
      <span class="topbar-title d-none d-sm-inline"><?= e($pageTitle) ?></span>
    </div>
    <div class="topbar-right">
      <a href="/jeweltrack/modules/products/index.php?filter=low_stock"
         class="btn btn-sm btn-outline-warning position-relative me-1 d-none d-md-flex align-items-center gap-1"
         title="Low stock alerts">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <?php
        try {
          $ls = getDB()->query('SELECT COUNT(*) FROM products WHERE quantity <= reorder_level AND quantity > 0 AND is_active=1')->fetchColumn();
          if ($ls > 0): ?><span class="badge bg-warning text-dark ms-1"><?= (int)$ls ?></span><?php endif;
        } catch(Throwable) {}
        ?>
      </a>
      <div class="dropdown">
        <button class="d-flex align-items-center gap-2 bg-transparent border-0 p-0 dropdown-toggle"
                data-bs-toggle="dropdown" aria-expanded="false">
          <div class="user-avatar"><?= e($initials) ?></div>
          <div class="text-start d-none d-md-block">
            <div style="font-size:0.82rem;font-weight:600;"><?= e($userName) ?></div>
            <div style="font-size:0.72rem;color:var(--clr-muted);"><?= ucfirst(e($userRole)) ?></div>
          </div>
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
          <li><a class="dropdown-item" href="/jeweltrack/modules/users/profile.php"><i class="bi bi-person me-2"></i>My Profile</a></li>
          <?php if(isAdmin()): ?>
          <li><a class="dropdown-item" href="/jeweltrack/modules/settings/index.php"><i class="bi bi-gear me-2"></i>Settings</a></li>
          <?php endif; ?>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="/jeweltrack/logout.php"
                 data-confirm="Are you sure you want to logout?">
            <i class="bi bi-box-arrow-left me-2"></i>Logout
          </a></li>
        </ul>
      </div>
    </div>
  </header>
  <!-- /TOPBAR -->

  <!-- MAIN CONTENT area opened here; closed in footer.php -->
  <main class="main-content" role="main">
    <?php renderFlash(); ?>
