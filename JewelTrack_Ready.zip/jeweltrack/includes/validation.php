<?php
/**
 * JewelTrack — Server-side Validation Helpers
 */

class Validator {
    private array $errors = [];
    private array $data   = [];

    public function __construct(array $input) {
        $this->data = $input;
    }

    public function required(string $field, string $label): static {
        $val = trim($this->data[$field] ?? '');
        if ($val === '') {
            $this->errors[$field] = "{$label} is required.";
        }
        return $this;
    }

    public function maxLength(string $field, int $max, string $label): static {
        $val = trim($this->data[$field] ?? '');
        if (strlen($val) > $max) {
            $this->errors[$field] = "{$label} must not exceed {$max} characters.";
        }
        return $this;
    }

    public function email(string $field, string $label, bool $optional = false): static {
        $val = trim($this->data[$field] ?? '');
        if ($val === '' && $optional) return $this;
        if (!filter_var($val, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = "{$label} must be a valid email address.";
        }
        return $this;
    }

    public function numeric(string $field, string $label, float $min = 0, ?float $max = null): static {
        $val = $this->data[$field] ?? '';
        if (!is_numeric($val)) {
            $this->errors[$field] = "{$label} must be a number.";
            return $this;
        }
        $val = (float)$val;
        if ($val < $min) {
            $this->errors[$field] = "{$label} must be at least {$min}.";
        }
        if ($max !== null && $val > $max) {
            $this->errors[$field] = "{$label} must not exceed {$max}.";
        }
        return $this;
    }

    public function integer(string $field, string $label, int $min = 0): static {
        $val = $this->data[$field] ?? '';
        if (!ctype_digit((string)$val) && !(is_numeric($val) && (int)$val == $val)) {
            $this->errors[$field] = "{$label} must be a whole number.";
            return $this;
        }
        if ((int)$val < $min) {
            $this->errors[$field] = "{$label} must be at least {$min}.";
        }
        return $this;
    }

    public function date(string $field, string $label): static {
        $val = $this->data[$field] ?? '';
        $d   = DateTime::createFromFormat('Y-m-d', $val);
        if (!$d || $d->format('Y-m-d') !== $val) {
            $this->errors[$field] = "{$label} must be a valid date (YYYY-MM-DD).";
        }
        return $this;
    }

    public function unique(string $field, string $label, string $table, string $column, ?int $exceptId = null): static {
        if (isset($this->errors[$field])) return $this;
        $val  = trim($this->data[$field] ?? '');
        $db   = getDB();
        $sql  = "SELECT id FROM `{$table}` WHERE `{$column}` = ?";
        $args = [$val];
        if ($exceptId !== null) {
            $sql   .= ' AND id != ?';
            $args[] = $exceptId;
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($args);
        if ($stmt->fetch()) {
            $this->errors[$field] = "{$label} already exists. Please use a unique value.";
        }
        return $this;
    }

    public function inList(string $field, string $label, array $allowed): static {
        $val = $this->data[$field] ?? '';
        if (!in_array($val, $allowed, true)) {
            $this->errors[$field] = "{$label} contains an invalid value.";
        }
        return $this;
    }

    public function passes(): bool {
        return empty($this->errors);
    }

    public function errors(): array {
        return $this->errors;
    }

    public function firstError(): string {
        return reset($this->errors) ?: '';
    }

    /** Return sanitised value */
    public function get(string $field, mixed $default = ''): mixed {
        return $this->data[$field] ?? $default;
    }
}
