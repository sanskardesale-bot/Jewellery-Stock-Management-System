  </main><!-- /.main-content -->

  <footer class="py-3 px-4 mt-auto border-top" style="font-size:0.78rem;color:var(--clr-muted);background:var(--clr-white);">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
      <span>&copy; <?= date('Y') ?> <?= e(getSetting('shop_name','JewelTrack')) ?>. Academic Project.</span>
      <span>JewelTrack v<?= APP_VERSION ?> &mdash; PHP <?= PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION ?></span>
    </div>
  </footer>

</div><!-- /.main-wrapper -->

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<!-- App JS -->
<script src="/jeweltrack/assets/js/app.js"></script>
</body>
</html>
