<?php
/**
 * JewelTrack — Authentication & Session Helpers
 */

// ============================================================
// Session Initialisation
// ============================================================
function initSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
    // Expire idle sessions
    if (isset($_SESSION['last_activity']) &&
        (time() - $_SESSION['last_activity'] > SESSION_LIFETIME)) {
        session_unset();
        session_destroy();
        session_start();
    }
    $_SESSION['last_activity'] = time();
}

// ============================================================
// Check if user is logged in; redirect if not
// ============================================================
function requireLogin(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: /jeweltrack/login.php');
        exit;
    }
}

// ============================================================
// Check if logged-in user is admin; redirect if not
// ============================================================
function requireAdmin(): void {
    requireLogin();
    if (($_SESSION['user_role'] ?? '') !== 'admin') {
        $_SESSION['flash_error'] = 'Access denied. Administrator privileges required.';
        header('Location: /jeweltrack/dashboard.php');
        exit;
    }
}

// ============================================================
// Check permission; return bool
// ============================================================
function isAdmin(): bool {
    return ($_SESSION['user_role'] ?? '') === 'admin';
}

function isLoggedIn(): bool {
    return !empty($_SESSION['user_id']);
}

// ============================================================
// Login logic
// ============================================================
function loginUser(string $email, string $password): array {
    $db   = getDB();
    $stmt = $db->prepare('SELECT id, name, email, password_hash, role, is_active FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        return ['success' => false, 'message' => 'Invalid email or password.'];
    }
    if (!$user['is_active']) {
        return ['success' => false, 'message' => 'Your account has been deactivated. Contact the administrator.'];
    }
    if (!password_verify($password, $user['password_hash'])) {
        return ['success' => false, 'message' => 'Invalid email or password.'];
    }

    // Regenerate session ID to prevent fixation
    session_regenerate_id(true);

    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_name']  = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role']  = $user['role'];

    // Update last login
    $db->prepare('UPDATE users SET last_login_at = NOW() WHERE id = ?')->execute([$user['id']]);

    // Activity log
    logActivity('login', 'users', $user['id'], 'User logged in');

    return ['success' => true];
}

// ============================================================
// Logout
// ============================================================
function logoutUser(): void {
    if (isLoggedIn()) {
        logActivity('logout', 'users', $_SESSION['user_id'], 'User logged out');
    }
    session_unset();
    session_destroy();
}

// ============================================================
// CSRF helpers
// ============================================================
function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfField(): string {
    return '<input type="hidden" name="csrf_token" value="' . csrfToken() . '">';
}

function verifyCsrf(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals(csrfToken(), $token)) {
        http_response_code(403);
        die('CSRF token mismatch. Please go back and try again.');
    }
}
