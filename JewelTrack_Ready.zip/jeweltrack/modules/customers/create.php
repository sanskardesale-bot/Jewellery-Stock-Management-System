<?php
/**
 * JewelTrack — Add Customer
 */
$pageTitle='Add Customer'; $activePage='customers';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';
$db = getDB(); $errors = []; $old = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $v = (new Validator($_POST))->required('name','Customer Name')->email('email','Email',true)->maxLength('name',150,'Name');
    $errors = $v->errors(); $old = $_POST;
    if (empty($errors)) {
        $db->prepare("INSERT INTO customers (name,phone,email,address,notes) VALUES (?,?,?,?,?)")
           ->execute([trim($_POST['name']),trim($_POST['phone']??''),trim($_POST['email']??''),trim($_POST['address']??''),trim($_POST['notes']??'')]);
        $newId = $db->lastInsertId();
        logActivity('customer_created','customers',(int)$newId,"Customer '{$_POST['name']}' created");
        setFlash('success',"Customer '{$_POST['name']}' added.");
        redirect('/jeweltrack/modules/customers/view.php?id='.$newId);
    }
}
?>
<div class="page-header"><h1><i class="bi bi-person-plus text-gold me-2"></i>Add Customer</h1>
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="/jeweltrack/modules/customers/index.php">Customers</a></li>
    <li class="breadcrumb-item active">Add</li>
  </ol></nav>
</div>
<?php if($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e2): ?><li><?= e($e2) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<div class="row justify-content-center"><div class="col-lg-7">
<div class="jt-card"><div class="jt-card-body">
  <form method="POST" novalidate>
    <?= csrfField() ?>
    <div class="row g-3">
      <div class="col-12"><label class="form-label">Full Name <span class="text-danger">*</span></label>
        <input type="text" name="name" class="form-control" value="<?= e($old['name']??'') ?>" required></div>
      <div class="col-md-6"><label class="form-label">Phone</label>
        <input type="text" name="phone" class="form-control" value="<?= e($old['phone']??'') ?>"></div>
      <div class="col-md-6"><label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="<?= e($old['email']??'') ?>"></div>
      <div class="col-12"><label class="form-label">Address</label>
        <textarea name="address" class="form-control" rows="2"><?= e($old['address']??'') ?></textarea></div>
      <div class="col-12"><label class="form-label">Notes</label>
        <textarea name="notes" class="form-control" rows="2"><?= e($old['notes']??'') ?></textarea></div>
      <div class="col-12 d-flex gap-2">
        <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg me-1"></i>Save Customer</button>
        <a href="/jeweltrack/modules/customers/index.php" class="btn btn-outline-secondary">Cancel</a>
      </div>
    </div>
  </form>
</div></div>
</div></div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
