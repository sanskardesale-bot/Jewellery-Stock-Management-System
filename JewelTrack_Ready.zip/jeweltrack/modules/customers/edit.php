<?php
/**
 * JewelTrack — Edit Customer
 */
$pageTitle = 'Edit Customer';
$activePage = 'customers';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';

$db = getDB();
$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    redirect('/jeweltrack/modules/customers/index.php');
}

$stmt = $db->prepare("SELECT * FROM customers WHERE id = ?");
$stmt->execute([$id]);
$customer = $stmt->fetch();
if (!$customer) {
    setFlash('danger', 'Customer not found.');
    redirect('/jeweltrack/modules/customers/index.php');
}

$errors = [];
$old = $customer;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $v = (new Validator($_POST))->required('name', 'Customer Name')->email('email', 'Email', true)->maxLength('name', 150, 'Name');
    $errors = $v->errors();
    $old = $_POST;

    if (empty($errors)) {
        $upd = $db->prepare("UPDATE customers SET name = ?, phone = ?, email = ?, address = ?, notes = ?, updated_at = NOW() WHERE id = ?");
        $upd->execute([
            trim($_POST['name']),
            trim($_POST['phone'] ?? ''),
            trim($_POST['email'] ?? ''),
            trim($_POST['address'] ?? ''),
            trim($_POST['notes'] ?? ''),
            $id
        ]);

        logActivity('customer_updated', 'customers', $id, "Customer '{$_POST['name']}' updated");
        setFlash('success', "Customer updated successfully.");
        redirect('/jeweltrack/modules/customers/view.php?id=' . $id);
    }
}
?>

<div class="page-header d-flex align-items-center justify-content-between mb-4">
  <div>
    <h1><i class="bi bi-pencil-square text-gold me-2"></i>Edit Customer</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-0">
        <li class="breadcrumb-item"><a href="/jeweltrack/modules/customers/index.php">Customers</a></li>
        <li class="breadcrumb-item"><a href="/jeweltrack/modules/customers/view.php?id=<?= $id ?>"><?= e($customer['name']) ?></a></li>
        <li class="breadcrumb-item active">Edit</li>
      </ol>
    </nav>
  </div>
  <div>
    <a href="/jeweltrack/modules/customers/view.php?id=<?= $id ?>" class="btn btn-outline-secondary">
      <i class="bi bi-arrow-left me-1"></i>Back to Details
    </a>
  </div>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0">
      <?php foreach ($errors as $e2): ?>
        <li><?= e($e2) ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="jt-card">
      <div class="jt-card-body p-4">
        <form method="POST" novalidate>
          <?= csrfField() ?>
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Full Name <span class="text-danger">*</span></label>
              <input type="text" name="name" class="form-control" value="<?= e($old['name'] ?? '') ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Phone</label>
              <input type="text" name="phone" class="form-control" value="<?= e($old['phone'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" value="<?= e($old['email'] ?? '') ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Address</label>
              <textarea name="address" class="form-control" rows="2"><?= e($old['address'] ?? '') ?></textarea>
            </div>
            <div class="col-12">
              <label class="form-label">Notes</label>
              <textarea name="notes" class="form-control" rows="2"><?= e($old['notes'] ?? '') ?></textarea>
            </div>
            <div class="col-12 d-flex gap-2 pt-2">
              <button type="submit" class="btn btn-gold">
                <i class="bi bi-check-lg me-1"></i>Update Customer
              </button>
              <a href="/jeweltrack/modules/customers/view.php?id=<?= $id ?>" class="btn btn-outline-secondary">Cancel</a>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
