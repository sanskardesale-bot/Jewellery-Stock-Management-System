<?php
/**
 * JewelTrack — Customer View
 */
$pageTitle='Customer Details'; $activePage='customers';
require_once __DIR__ . '/../../includes/header.php';
$db = getDB(); $sym = currencySymbol();
$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect('/jeweltrack/modules/customers/index.php');
$cStmt = $db->prepare("SELECT * FROM customers WHERE id=?"); $cStmt->execute([$id]); $cust = $cStmt->fetch();
if (!$cust) { setFlash('error','Customer not found.'); redirect('/jeweltrack/modules/customers/index.php'); }
$sales = $db->prepare("SELECT s.invoice_number,s.sale_date,s.grand_total,s.payment_status FROM sales s WHERE s.customer_id=? ORDER BY s.created_at DESC LIMIT 10");
$sales->execute([$id]); $saleHistory = $sales->fetchAll();
$totalSpent = $db->prepare("SELECT COALESCE(SUM(grand_total),0) FROM sales WHERE customer_id=?");
$totalSpent->execute([$id]); $total = (float)$totalSpent->fetchColumn();
?>
<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div><h1><i class="bi bi-person text-gold me-2"></i><?= e($cust['name']) ?></h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/jeweltrack/modules/customers/index.php">Customers</a></li>
      <li class="breadcrumb-item active"><?= e($cust['name']) ?></li>
    </ol></nav>
  </div>
  <a href="/jeweltrack/modules/customers/edit.php?id=<?= $id ?>" class="btn btn-gold btn-sm"><i class="bi bi-pencil me-1"></i>Edit</a>
</div>
<div class="row g-4">
  <div class="col-lg-4">
    <div class="jt-card mb-3"><div class="jt-card-header"><h2>Contact Info</h2></div>
      <div class="jt-card-body">
        <?php foreach(['Phone'=>$cust['phone'],'Email'=>$cust['email'],'Address'=>$cust['address'],'Notes'=>$cust['notes'],'Member Since'=>date('d M Y',strtotime($cust['created_at']))] as $k=>$v): ?>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted fs-13"><?= $k ?></span><span class="fw-600 text-end"><?= e($v?:'—') ?></span>
        </div>
        <?php endforeach; ?>
        <div class="d-flex justify-content-between py-2">
          <span class="text-muted fs-13">Lifetime Value</span>
          <span class="fw-700 text-emerald"><?= formatMoney($total,$sym) ?></span>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="jt-card"><div class="jt-card-header">
      <h2><i class="bi bi-receipt me-2 text-gold"></i>Purchase History</h2>
      <a href="/jeweltrack/modules/sales/create.php?customer_id=<?= $id ?>" class="btn btn-sm btn-gold">New Sale</a>
    </div>
    <div class="table-responsive">
      <?php if($saleHistory): ?>
      <table class="jt-table"><thead><tr><th>Invoice</th><th>Date</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach($saleHistory as $sale): ?>
        <tr>
          <td><a href="/jeweltrack/modules/sales/view.php?id=<?= $sale['invoice_number'] ?>" class="fw-600 text-emerald"><?= e($sale['invoice_number']) ?></a></td>
          <td class="fs-13"><?= date('d M Y',strtotime($sale['sale_date'])) ?></td>
          <td class="fw-600"><?= formatMoney((float)$sale['grand_total'],$sym) ?></td>
          <td><span class="badge bg-<?= match($sale['payment_status']){'paid'=>'success','partial'=>'warning',default=>'secondary'} ?>"><?= ucfirst($sale['payment_status']) ?></span></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php else: ?><div class="empty-state"><i class="bi bi-receipt d-block"></i><p>No purchases yet.</p></div><?php endif; ?>
    </div></div>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
