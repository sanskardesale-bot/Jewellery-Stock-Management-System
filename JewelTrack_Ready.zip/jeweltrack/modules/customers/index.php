<?php
/**
 * JewelTrack — Customers List
 */
$pageTitle  = 'Customers';
$activePage = 'customers';
require_once __DIR__ . '/../../includes/header.php';
$db  = getDB(); $sym = currencySymbol();
$search = trim($_GET['q'] ?? ''); $page = max(1,(int)($_GET['page']??1));
$where  = $search ? "WHERE c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?" : '';
$params = $search ? ["%$search%","%$search%","%$search%"] : [];
$count  = $db->prepare("SELECT COUNT(*) FROM customers c $where"); $count->execute($params);
$total  = (int)$count->fetchColumn(); $pager = paginate($total,$page,PER_PAGE);
$stmt   = $db->prepare(
    "SELECT c.*, COUNT(s.id) AS sale_count, COALESCE(SUM(s.grand_total),0) AS total_spent
     FROM customers c LEFT JOIN sales s ON s.customer_id=c.id $where GROUP BY c.id ORDER BY c.name
     LIMIT {$pager['per_page']} OFFSET {$pager['offset']}"
); $stmt->execute($params); $customers = $stmt->fetchAll();
?>
<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div><h1><i class="bi bi-people text-gold me-2"></i>Customers</h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item active">Customers</li></ol></nav>
  </div>
  <a href="/jeweltrack/modules/customers/create.php" class="btn btn-gold"><i class="bi bi-plus-lg me-1"></i>Add Customer</a>
</div>
<form method="GET"><div class="filter-bar">
  <div class="flex-fill"><label class="form-label mb-1 fs-13">Search</label>
    <input type="text" name="q" class="form-control form-control-sm" placeholder="Name, phone, email…" value="<?= e($search) ?>">
  </div>
  <div class="d-flex align-items-end gap-2">
    <button type="submit" class="btn btn-emerald btn-sm"><i class="bi bi-search me-1"></i>Search</button>
    <a href="/jeweltrack/modules/customers/index.php" class="btn btn-sm btn-outline-secondary">Reset</a>
  </div>
</div></form>
<div class="jt-card">
  <div class="jt-card-header"><h2>All Customers <span class="badge bg-secondary ms-1"><?= $total ?></span></h2></div>
  <div class="table-responsive">
    <?php if($customers): ?>
    <table class="jt-table">
      <thead><tr><th>#</th><th>Name</th><th>Phone</th><th>Email</th><th>Sales</th><th>Total Spent</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach($customers as $i=>$c): ?>
      <tr>
        <td class="text-muted"><?= $pager['offset']+$i+1 ?></td>
        <td class="fw-600"><?= e($c['name']) ?></td>
        <td class="fs-13"><?= e($c['phone']?:'—') ?></td>
        <td class="fs-13"><?= e($c['email']?:'—') ?></td>
        <td><span class="badge bg-secondary"><?= (int)$c['sale_count'] ?></span></td>
        <td class="fw-600"><?= formatMoney((float)$c['total_spent'],$sym) ?></td>
        <td><?= $c['is_active']?'<span class="badge bg-success">Active</span>':'<span class="badge bg-secondary">Inactive</span>' ?></td>
        <td><div class="d-flex gap-1">
          <a href="/jeweltrack/modules/customers/view.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
          <a href="/jeweltrack/modules/customers/edit.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-gold"><i class="bi bi-pencil"></i></a>
        </div></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?><div class="empty-state"><i class="bi bi-people d-block"></i><p>No customers found.</p></div><?php endif; ?>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
