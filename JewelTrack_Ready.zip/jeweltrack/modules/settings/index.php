<?php
/**
 * JewelTrack — Store & System Settings (Admin Only)
 */
$pageTitle = 'Settings';
$activePage = 'settings';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';

requireAdmin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $settingsToSave = [
        'shop_name'           => trim($_POST['shop_name'] ?? 'JewelTrack Store'),
        'shop_phone'          => trim($_POST['shop_phone'] ?? ''),
        'shop_email'          => trim($_POST['shop_email'] ?? ''),
        'shop_address'        => trim($_POST['shop_address'] ?? ''),
        'currency_symbol'     => trim($_POST['currency_symbol'] ?? '₹'),
        'currency_code'       => trim($_POST['currency_code'] ?? 'INR'),
        'tax_rate'            => (string)(float)($_POST['tax_rate'] ?? 3.0),
        'tax_label'           => trim($_POST['tax_label'] ?? 'GST'),
        'invoice_footer'      => trim($_POST['invoice_footer'] ?? ''),
        'gold_rate_24k_10g'   => trim($_POST['gold_rate_24k_10g'] ?? '75000'),
        'gold_rate_22k_10g'   => trim($_POST['gold_rate_22k_10g'] ?? '68750'),
        'silver_rate_1kg'     => trim($_POST['silver_rate_1kg'] ?? '90000')
    ];

    $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_val) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_val = VALUES(setting_val)");
    foreach ($settingsToSave as $k => $v) {
        $stmt->execute([$k, $v]);
    }

    logActivity('settings_updated', 'settings', null, 'System settings updated');
    setFlash('success', 'Store and system settings saved successfully.');
    redirect('/jeweltrack/modules/settings/index.php');
}

// Load current settings
$rows = $db->query("SELECT setting_key, setting_val FROM settings")->fetchAll();
$current = [];
foreach ($rows as $r) {
    $current[$r['setting_key']] = $r['setting_val'];
}
?>

<div class="page-header d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
  <div>
    <h1><i class="bi bi-gear-fill text-gold me-2"></i>System &amp; Store Settings</h1>
    <p class="text-muted mb-0">Manage jewellery store information, tax preferences, currency, and market bullion rates.</p>
  </div>
</div>

<div class="row justify-content-center">
  <div class="col-lg-10">
    <form method="POST" novalidate>
      <?= csrfField() ?>

      <!-- Store Profile -->
      <div class="jt-card mb-4">
        <div class="jt-card-header">
          <h5 class="mb-0"><i class="bi bi-shop text-gold me-2"></i>Jewellery Store Information</h5>
        </div>
        <div class="jt-card-body p-4">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Store / Business Name <span class="text-danger">*</span></label>
              <input type="text" name="shop_name" class="form-control" value="<?= e($current['shop_name'] ?? 'JewelTrack Store') ?>" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Phone Number</label>
              <input type="text" name="shop_phone" class="form-control" value="<?= e($current['shop_phone'] ?? '') ?>">
            </div>
            <div class="col-md-3">
              <label class="form-label">Email Address</label>
              <input type="email" name="shop_email" class="form-control" value="<?= e($current['shop_email'] ?? '') ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Store Address (printed on invoices)</label>
              <textarea name="shop_address" class="form-control" rows="2"><?= e($current['shop_address'] ?? '') ?></textarea>
            </div>
          </div>
        </div>
      </div>

      <!-- Financial & Tax Preferences -->
      <div class="jt-card mb-4">
        <div class="jt-card-header">
          <h5 class="mb-0"><i class="bi bi-currency-exchange text-gold me-2"></i>Currency &amp; Tax Preferences</h5>
        </div>
        <div class="jt-card-body p-4">
          <div class="row g-3">
            <div class="col-md-3">
              <label class="form-label">Currency Symbol</label>
              <input type="text" name="currency_symbol" class="form-control" value="<?= e($current['currency_symbol'] ?? '₹') ?>" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Currency Code</label>
              <input type="text" name="currency_code" class="form-control" value="<?= e($current['currency_code'] ?? 'INR') ?>" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Tax Label</label>
              <input type="text" name="tax_label" class="form-control" value="<?= e($current['tax_label'] ?? 'GST') ?>">
            </div>
            <div class="col-md-3">
              <label class="form-label">Default Tax Rate (%)</label>
              <div class="input-group">
                <input type="number" step="0.01" name="tax_rate" class="form-control" value="<?= e($current['tax_rate'] ?? '3.0') ?>">
                <span class="input-group-text">%</span>
              </div>
            </div>
            <div class="col-12">
              <label class="form-label">Invoice Disclaimer / Footer Text</label>
              <textarea name="invoice_footer" class="form-control" rows="2"><?= e($current['invoice_footer'] ?? '') ?></textarea>
              <div class="form-text">This note appears at the bottom of customer invoices.</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Live Bullion Reference Rates -->
      <div class="jt-card mb-4">
        <div class="jt-card-header">
          <h5 class="mb-0"><i class="bi bi-graph-up text-gold me-2"></i>Daily Reference Bullion Rates</h5>
        </div>
        <div class="jt-card-body p-4">
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label">Gold 24K Rate (per 10g)</label>
              <div class="input-group">
                <span class="input-group-text"><?= e($current['currency_symbol'] ?? '₹') ?></span>
                <input type="number" step="0.01" name="gold_rate_24k_10g" class="form-control" value="<?= e($current['gold_rate_24k_10g'] ?? '75000') ?>">
              </div>
            </div>
            <div class="col-md-4">
              <label class="form-label">Gold 22K Rate (per 10g)</label>
              <div class="input-group">
                <span class="input-group-text"><?= e($current['currency_symbol'] ?? '₹') ?></span>
                <input type="number" step="0.01" name="gold_rate_22k_10g" class="form-control" value="<?= e($current['gold_rate_22k_10g'] ?? '68750') ?>">
              </div>
            </div>
            <div class="col-md-4">
              <label class="form-label">Silver Rate (per 1kg)</label>
              <div class="input-group">
                <span class="input-group-text"><?= e($current['currency_symbol'] ?? '₹') ?></span>
                <input type="number" step="0.01" name="silver_rate_1kg" class="form-control" value="<?= e($current['silver_rate_1kg'] ?? '90000') ?>">
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="d-flex justify-content-end gap-2 mb-5">
        <button type="submit" class="btn btn-gold btn-lg px-4">
          <i class="bi bi-save me-1"></i>Save All Settings
        </button>
      </div>

    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
