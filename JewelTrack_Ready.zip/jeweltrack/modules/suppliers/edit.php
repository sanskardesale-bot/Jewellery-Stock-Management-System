<?php
/**
 * JewelTrack — Edit Supplier
 */
$pageTitle  = 'Edit Supplier';
$activePage = 'suppliers';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';
requireAdmin();
$db = getDB();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
if (!$id) redirect('/jeweltrack/modules/suppliers/index.php');
$supStmt = $db->prepare("SELECT * FROM suppliers WHERE id=?"); $supStmt->execute([$id]); $s = $supStmt->fetch();
if (!$s) { setFlash('error','Not found.'); redirect('/jeweltrack/modules/suppliers/index.php'); }
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $v = (new Validator($_POST))->required('name','Name')->email('email','Email',true);
    $errors = $v->errors();
    if (empty($errors)) {
        $db->prepare("UPDATE suppliers SET name=?,phone=?,email=?,address=?,notes=?,is_active=? WHERE id=?")
           ->execute([trim($_POST['name']),trim($_POST['phone']??''),trim($_POST['email']??''),
                      trim($_POST['address']??''),trim($_POST['notes']??''),(int)($_POST['is_active']??1),$id]);
        logActivity('supplier_updated','suppliers',$id,"Supplier updated");
        setFlash('success','Supplier updated.');
        redirect('/jeweltrack/modules/suppliers/view.php?id='.$id);
    }
    $s = array_merge($s, $_POST);
}
?>
<div class="page-header"><h1><i class="bi bi-pencil text-gold me-2"></i>Edit Supplier</h1>
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="/jeweltrack/modules/suppliers/index.php">Suppliers</a></li>
    <li class="breadcrumb-item active">Edit</li>
  </ol></nav>
</div>
<?php if($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e2): ?><li><?= e($e2) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<div class="row justify-content-center"><div class="col-lg-7">
<div class="jt-card">
  <div class="jt-card-body">
    <form method="POST" novalidate>
      <?= csrfField() ?><input type="hidden" name="id" value="<?= $id ?>">
      <div class="row g-3">
        <div class="col-12"><label class="form-label">Name <span class="text-danger">*</span></label>
          <input type="text" name="name" class="form-control" value="<?= e($s['name']) ?>" required></div>
        <div class="col-md-6"><label class="form-label">Phone</label>
          <input type="text" name="phone" class="form-control" value="<?= e($s['phone']) ?>"></div>
        <div class="col-md-6"><label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= e($s['email']) ?>"></div>
        <div class="col-12"><label class="form-label">Address</label>
          <textarea name="address" class="form-control" rows="2"><?= e($s['address']) ?></textarea></div>
        <div class="col-12"><label class="form-label">Notes</label>
          <textarea name="notes" class="form-control" rows="2"><?= e($s['notes']) ?></textarea></div>
        <div class="col-md-4"><label class="form-label">Status</label>
          <select name="is_active" class="form-select">
            <option value="1" <?= $s['is_active']?'selected':'' ?>>Active</option>
            <option value="0" <?= !$s['is_active']?'selected':'' ?>>Inactive</option>
          </select></div>
        <div class="col-12 d-flex gap-2">
          <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg me-1"></i>Update</button>
          <a href="/jeweltrack/modules/suppliers/view.php?id=<?= $id ?>" class="btn btn-outline-secondary">Cancel</a>
        </div>
      </div>
    </form>
  </div>
</div>
</div></div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
