<?php
/**
 * JewelTrack — Suppliers List
 */

$pageTitle  = 'Suppliers';
$activePage = 'suppliers';
require_once __DIR__ . '/../../includes/header.php';

$db  = getDB();
$sym = currencySymbol();

$search = trim($_GET['q'] ?? '');
$page   = max(1, (int)($_GET['page'] ?? 1));
$where  = $search ? "WHERE s.name LIKE ? OR s.phone LIKE ? OR s.email LIKE ?" : '';
$params = $search ? ["%$search%","%$search%","%$search%"] : [];

$count = $db->prepare("SELECT COUNT(*) FROM suppliers s $where");
$count->execute($params);
$total = (int)$count->fetchColumn();
$pager = paginate($total, $page, PER_PAGE);

$stmt = $db->prepare(
    "SELECT s.*, COUNT(p.id) AS purchase_count, COALESCE(SUM(p.grand_total),0) AS total_purchased
     FROM suppliers s
     LEFT JOIN purchases p ON p.supplier_id=s.id
     $where GROUP BY s.id ORDER BY s.name
     LIMIT {$pager['per_page']} OFFSET {$pager['offset']}"
);
$stmt->execute($params);
$suppliers = $stmt->fetchAll();
?>

<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div>
    <h1><i class="bi bi-truck text-gold me-2"></i>Suppliers</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb"><li class="breadcrumb-item active">Suppliers</li></ol>
    </nav>
  </div>
  <?php if (isAdmin()): ?>
  <a href="/jeweltrack/modules/suppliers/create.php" class="btn btn-gold">
    <i class="bi bi-plus-lg me-1"></i>Add Supplier
  </a>
  <?php endif; ?>
</div>

<!-- Search -->
<form method="GET">
  <div class="filter-bar">
    <div class="flex-fill">
      <label class="form-label mb-1 fs-13">Search</label>
      <input type="text" name="q" class="form-control form-control-sm" placeholder="Name, phone, email…" value="<?= e($search) ?>">
    </div>
    <div class="d-flex align-items-end gap-2">
      <button type="submit" class="btn btn-emerald btn-sm"><i class="bi bi-search me-1"></i>Search</button>
      <a href="/jeweltrack/modules/suppliers/index.php" class="btn btn-sm btn-outline-secondary">Reset</a>
    </div>
  </div>
</form>

<div class="jt-card">
  <div class="jt-card-header">
    <h2>All Suppliers <span class="badge bg-secondary ms-1"><?= $total ?></span></h2>
  </div>
  <div class="table-responsive">
    <?php if ($suppliers): ?>
    <table class="jt-table">
      <thead>
        <tr><th>#</th><th>Name</th><th>Phone</th><th>Email</th><th>Purchases</th><th>Total Purchased</th><th>Status</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($suppliers as $i => $s): ?>
        <tr>
          <td class="text-muted"><?= $pager['offset']+$i+1 ?></td>
          <td class="fw-600"><?= e($s['name']) ?></td>
          <td class="fs-13"><?= e($s['phone'] ?: '—') ?></td>
          <td class="fs-13"><?= e($s['email'] ?: '—') ?></td>
          <td><span class="badge bg-secondary"><?= (int)$s['purchase_count'] ?></span></td>
          <td class="fw-600"><?= formatMoney((float)$s['total_purchased'], $sym) ?></td>
          <td><?= $s['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>' ?></td>
          <td>
            <div class="d-flex gap-1">
              <a href="/jeweltrack/modules/suppliers/view.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
              <?php if (isAdmin()): ?>
              <a href="/jeweltrack/modules/suppliers/edit.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-gold"><i class="bi bi-pencil"></i></a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><i class="bi bi-truck d-block"></i><p>No suppliers found.</p></div>
    <?php endif; ?>
  </div>
  <?php if ($pager['total_pages']>1): ?>
  <div class="jt-card-body border-top d-flex justify-content-between align-items-center">
    <small class="text-muted">Showing <?= $pager['offset']+1 ?>–<?= min($pager['offset']+$pager['per_page'],$total) ?> of <?= $total ?></small>
    <?= renderPagination($pager, '/jeweltrack/modules/suppliers/index.php?q='.urlencode($search)) ?>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
