<?php
/**
 * JewelTrack — Add Supplier
 */
$pageTitle  = 'Add Supplier';
$activePage = 'suppliers';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';
requireAdmin();

$db = getDB(); $errors = []; $old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $v = (new Validator($_POST))
          ->required('name','Supplier Name')
          ->email('email','Email', true)
          ->maxLength('name',150,'Name')
          ->maxLength('phone',30,'Phone');
    $errors = $v->errors();
    $old    = $_POST;
    if (empty($errors)) {
        $db->prepare("INSERT INTO suppliers (name,phone,email,address,notes) VALUES (?,?,?,?,?)")
           ->execute([trim($_POST['name']),trim($_POST['phone']??''),trim($_POST['email']??''),
                      trim($_POST['address']??''),trim($_POST['notes']??'')]);
        $newId = $db->lastInsertId();
        logActivity('supplier_created','suppliers',(int)$newId,"Supplier '{$_POST['name']}' created");
        setFlash('success',"Supplier '{$_POST['name']}' added.");
        redirect('/jeweltrack/modules/suppliers/view.php?id='.$newId);
    }
}
?>
<div class="page-header">
  <h1><i class="bi bi-plus-circle text-gold me-2"></i>Add Supplier</h1>
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="/jeweltrack/modules/suppliers/index.php">Suppliers</a></li>
    <li class="breadcrumb-item active">Add</li>
  </ol></nav>
</div>
<?php if($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e2): ?><li><?= e($e2) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<div class="row justify-content-center"><div class="col-lg-7">
<div class="jt-card">
  <div class="jt-card-header"><h2>Supplier Information</h2></div>
  <div class="jt-card-body">
    <form method="POST" novalidate>
      <?= csrfField() ?>
      <div class="row g-3">
        <div class="col-12"><label class="form-label">Business/Contact Name <span class="text-danger">*</span></label>
          <input type="text" name="name" class="form-control" value="<?= e($old['name']??'') ?>" required maxlength="150"></div>
        <div class="col-md-6"><label class="form-label">Phone</label>
          <input type="text" name="phone" class="form-control" value="<?= e($old['phone']??'') ?>" maxlength="30"></div>
        <div class="col-md-6"><label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= e($old['email']??'') ?>"></div>
        <div class="col-12"><label class="form-label">Address</label>
          <textarea name="address" class="form-control" rows="2"><?= e($old['address']??'') ?></textarea></div>
        <div class="col-12"><label class="form-label">Notes</label>
          <textarea name="notes" class="form-control" rows="2"><?= e($old['notes']??'') ?></textarea></div>
        <div class="col-12 d-flex gap-2">
          <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg me-1"></i>Save Supplier</button>
          <a href="/jeweltrack/modules/suppliers/index.php" class="btn btn-outline-secondary">Cancel</a>
        </div>
      </div>
    </form>
  </div>
</div>
</div></div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
