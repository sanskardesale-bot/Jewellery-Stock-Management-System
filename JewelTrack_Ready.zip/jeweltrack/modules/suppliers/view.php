<?php
/**
 * JewelTrack — Supplier Detail View
 */
$pageTitle  = 'Supplier Details';
$activePage = 'suppliers';
require_once __DIR__ . '/../../includes/header.php';
$db  = getDB(); $sym = currencySymbol();
$id  = (int)($_GET['id'] ?? 0);
if (!$id) redirect('/jeweltrack/modules/suppliers/index.php');
$sup = $db->prepare("SELECT * FROM suppliers WHERE id=?"); $sup->execute([$id]); $supplier = $sup->fetch();
if (!$supplier) { setFlash('error','Not found.'); redirect('/jeweltrack/modules/suppliers/index.php'); }
$purchases = $db->prepare(
    "SELECT p.ref_number, p.purchase_date, p.grand_total, p.payment_status FROM purchases p WHERE p.supplier_id=? ORDER BY p.created_at DESC LIMIT 10"
); $purchases->execute([$id]); $pos = $purchases->fetchAll();
$totalPurchased = $db->prepare("SELECT COALESCE(SUM(grand_total),0) FROM purchases WHERE supplier_id=?");
$totalPurchased->execute([$id]); $totalVal = (float)$totalPurchased->fetchColumn();
?>
<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div><h1><i class="bi bi-truck text-gold me-2"></i><?= e($supplier['name']) ?></h1>
    <nav aria-label="breadcrumb"><ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/jeweltrack/modules/suppliers/index.php">Suppliers</a></li>
      <li class="breadcrumb-item active"><?= e($supplier['name']) ?></li>
    </ol></nav>
  </div>
  <?php if(isAdmin()): ?><a href="/jeweltrack/modules/suppliers/edit.php?id=<?= $id ?>" class="btn btn-gold btn-sm"><i class="bi bi-pencil me-1"></i>Edit</a><?php endif; ?>
</div>
<div class="row g-4">
  <div class="col-lg-4">
    <div class="jt-card mb-3">
      <div class="jt-card-header"><h2>Contact Info</h2></div>
      <div class="jt-card-body">
        <?php foreach(['Phone'=>$supplier['phone'],'Email'=>$supplier['email'],'Address'=>$supplier['address'],'Notes'=>$supplier['notes'],'Status'=>$supplier['is_active']?'Active':'Inactive','Member Since'=>date('d M Y',strtotime($supplier['created_at']))] as $k=>$v): ?>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted fs-13"><?= $k ?></span><span class="fw-600 text-end"><?= e($v?:'—') ?></span>
        </div>
        <?php endforeach; ?>
        <div class="d-flex justify-content-between py-2">
          <span class="text-muted fs-13">Total Purchased</span>
          <span class="fw-700 text-emerald"><?= formatMoney($totalVal, $sym) ?></span>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="jt-card">
      <div class="jt-card-header"><h2><i class="bi bi-cart me-2 text-gold"></i>Recent Purchases</h2>
        <a href="/jeweltrack/modules/purchases/index.php?supplier=<?= $id ?>" class="btn btn-sm btn-outline-gold">All</a>
      </div>
      <div class="table-responsive">
        <?php if ($pos): ?>
        <table class="jt-table">
          <thead><tr><th>Ref #</th><th>Date</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>
          <?php foreach($pos as $po): ?>
          <tr>
            <td><a href="/jeweltrack/modules/purchases/view.php?id=<?= urlencode($po['ref_number']) ?>" class="fw-600 text-emerald"><?= e($po['ref_number']) ?></a></td>
            <td class="fs-13"><?= date('d M Y',strtotime($po['purchase_date'])) ?></td>
            <td class="fw-600"><?= formatMoney((float)$po['grand_total'],$sym) ?></td>
            <td><span class="badge bg-<?= match($po['payment_status']){'paid'=>'success','partial'=>'warning',default=>'secondary'} ?>"><?= ucfirst($po['payment_status']) ?></span></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        <?php else: ?><div class="empty-state"><i class="bi bi-cart d-block"></i><p>No purchases yet.</p></div><?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
