<?php
/**
 * JewelTrack — Categories Module (List + Add + Edit in one file)
 */

$pageTitle  = 'Categories';
$activePage = 'categories';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';

$db = getDB();

// ── Handle Actions ──────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAdmin();
    verifyCsrf();

    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $v = (new Validator($_POST))
              ->required('name', 'Category Name')
              ->maxLength('name', 100, 'Category Name')
              ->unique('name', 'Category Name', 'categories', 'name');
        if ($v->passes()) {
            $db->prepare("INSERT INTO categories (name, description) VALUES (?,?)")
               ->execute([trim($_POST['name']), trim($_POST['description'] ?? '')]);
            $newId = $db->lastInsertId();
            logActivity('category_created', 'categories', (int)$newId, "Category '{$_POST['name']}' created");
            setFlash('success', "Category '{$_POST['name']}' added.");
        } else {
            setFlash('error', $v->firstError());
        }
        redirect('/jeweltrack/modules/categories/index.php');
    }

    if ($action === 'edit') {
        $id = (int)($_POST['id'] ?? 0);
        $v  = (new Validator($_POST))
               ->required('name', 'Category Name')
               ->maxLength('name', 100, 'Category Name')
               ->unique('name', 'Category Name', 'categories', 'name', $id);
        if ($v->passes()) {
            $db->prepare("UPDATE categories SET name=?, description=? WHERE id=?")
               ->execute([trim($_POST['name']), trim($_POST['description'] ?? ''), $id]);
            logActivity('category_updated', 'categories', $id, "Category updated to '{$_POST['name']}'");
            setFlash('success', 'Category updated.');
        } else {
            setFlash('error', $v->firstError());
        }
        redirect('/jeweltrack/modules/categories/index.php');
    }

    if ($action === 'delete') {
        requireAdmin();
        $id = (int)($_POST['id'] ?? 0);
        // Check if in use
        $inUse = $db->prepare("SELECT COUNT(*) FROM products WHERE category_id=?");
        $inUse->execute([$id]);
        if ($inUse->fetchColumn() > 0) {
            setFlash('error', 'Cannot delete: this category has products associated with it.');
        } else {
            $name = $db->prepare("SELECT name FROM categories WHERE id=?");
            $name->execute([$id]);
            $catName = $name->fetchColumn();
            $db->prepare("DELETE FROM categories WHERE id=?")->execute([$id]);
            logActivity('category_deleted', 'categories', $id, "Category '$catName' deleted");
            setFlash('success', "Category '$catName' deleted.");
        }
        redirect('/jeweltrack/modules/categories/index.php');
    }
}

// ── Fetch edit target ────────────────────────────────────────────────────────
$editCategory = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM categories WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editCategory = $stmt->fetch();
}

// ── List with product counts ─────────────────────────────────────────────────
$categories = $db->query(
    "SELECT c.*, COUNT(p.id) AS product_count
     FROM categories c
     LEFT JOIN products p ON p.category_id=c.id AND p.is_active=1
     GROUP BY c.id ORDER BY c.name"
)->fetchAll();
?>

<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div>
    <h1><i class="bi bi-tag text-gold me-2"></i>Categories</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb"><li class="breadcrumb-item active">Categories</li></ol>
    </nav>
  </div>
</div>

<div class="row g-4">
  <!-- List -->
  <div class="col-lg-8">
    <div class="jt-card">
      <div class="jt-card-header">
        <h2>All Categories <span class="badge bg-secondary ms-1"><?= count($categories) ?></span></h2>
      </div>
      <div class="table-responsive">
        <?php if ($categories): ?>
        <table class="jt-table">
          <thead>
            <tr><th>#</th><th>Name</th><th>Description</th><th>Products</th><th>Created</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php foreach ($categories as $i => $cat): ?>
            <tr>
              <td class="text-muted fs-13"><?= $i+1 ?></td>
              <td class="fw-600"><?= e($cat['name']) ?></td>
              <td class="text-muted fs-13"><?= e($cat['description'] ?: '—') ?></td>
              <td><span class="badge bg-secondary"><?= (int)$cat['product_count'] ?></span></td>
              <td class="text-muted fs-13"><?= date('d M Y', strtotime($cat['created_at'])) ?></td>
              <td>
                <?php if (isAdmin()): ?>
                <div class="d-flex gap-1">
                  <a href="?edit=<?= $cat['id'] ?>" class="btn btn-sm btn-outline-gold"><i class="bi bi-pencil"></i></a>
                  <form method="POST" class="d-inline">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $cat['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger"
                            data-confirm="Delete category '<?= e(addslashes($cat['name'])) ?>'?"
                            <?= $cat['product_count'] > 0 ? 'disabled title="Has products"' : '' ?>>
                      <i class="bi bi-trash"></i>
                    </button>
                  </form>
                </div>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state"><i class="bi bi-tag d-block"></i><p>No categories yet.</p></div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Add / Edit Form -->
  <?php if (isAdmin()): ?>
  <div class="col-lg-4">
    <div class="jt-card">
      <div class="jt-card-header">
        <h2><?= $editCategory ? 'Edit Category' : 'Add Category' ?></h2>
      </div>
      <div class="jt-card-body">
        <form method="POST">
          <?= csrfField() ?>
          <input type="hidden" name="action" value="<?= $editCategory ? 'edit' : 'add' ?>">
          <?php if ($editCategory): ?>
          <input type="hidden" name="id" value="<?= $editCategory['id'] ?>">
          <?php endif; ?>
          <div class="mb-3">
            <label for="cat_name" class="form-label">Category Name <span class="text-danger">*</span></label>
            <input type="text" id="cat_name" name="name" class="form-control"
                   value="<?= e($editCategory['name'] ?? '') ?>" required maxlength="100">
          </div>
          <div class="mb-3">
            <label for="cat_desc" class="form-label">Description</label>
            <textarea id="cat_desc" name="description" class="form-control" rows="3"
                      placeholder="Optional…"><?= e($editCategory['description'] ?? '') ?></textarea>
          </div>
          <div class="d-grid gap-2">
            <button type="submit" class="btn btn-gold">
              <?= $editCategory ? '<i class="bi bi-check-lg me-1"></i>Update' : '<i class="bi bi-plus-lg me-1"></i>Add Category' ?>
            </button>
            <?php if ($editCategory): ?>
            <a href="/jeweltrack/modules/categories/index.php" class="btn btn-outline-secondary">Cancel</a>
            <?php endif; ?>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
