<?php
/**
 * JewelTrack — Sale Detail View
 */

$pageTitle  = 'Sale Details';
$activePage = 'sales';
require_once __DIR__ . '/../../includes/header.php';

$db  = getDB();
$sym = currencySymbol();
$id  = (int)($_GET['id'] ?? 0);
if (!$id) redirect('/jeweltrack/modules/sales/index.php');

$saleStmt = $db->prepare(
    "SELECT s.*, COALESCE(c.name,'Walk-in') AS customer_name,
            c.phone AS customer_phone, u.name AS user_name
     FROM sales s
     LEFT JOIN customers c ON c.id=s.customer_id
     JOIN users u ON u.id=s.user_id WHERE s.id=?"
);
$saleStmt->execute([$id]);
$sale = $saleStmt->fetch();
if (!$sale) { setFlash('error','Sale not found.'); redirect('/jeweltrack/modules/sales/index.php'); }

$itemStmt = $db->prepare(
    "SELECT si.*, p.name AS product_name, p.sku
     FROM sale_items si JOIN products p ON p.id=si.product_id WHERE si.sale_id=?"
);
$itemStmt->execute([$id]);
$items = $itemStmt->fetchAll();
?>

<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div>
    <h1><i class="bi bi-receipt text-gold me-2"></i><?= e($sale['invoice_number']) ?></h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/jeweltrack/modules/sales/index.php">Sales</a></li>
        <li class="breadcrumb-item active"><?= e($sale['invoice_number']) ?></li>
      </ol>
    </nav>
  </div>
  <a href="/jeweltrack/modules/sales/invoice.php?id=<?= $id ?>" target="_blank" class="btn btn-gold btn-sm">
    <i class="bi bi-printer me-1"></i>Print Invoice
  </a>
</div>

<div class="row g-4">
  <div class="col-lg-8">
    <div class="jt-card mb-3">
      <div class="jt-card-header"><h2>Items Sold</h2></div>
      <div class="table-responsive">
        <table class="jt-table">
          <thead>
            <tr><th>#</th><th>SKU</th><th>Product</th><th>Qty</th><th>Unit Price</th><th>Line Total</th></tr>
          </thead>
          <tbody>
            <?php foreach ($items as $i => $li): ?>
            <tr>
              <td class="text-muted"><?= $i+1 ?></td>
              <td><code class="fs-13"><?= e($li['sku']) ?></code></td>
              <td><a href="/jeweltrack/modules/products/view.php?id=<?= $li['product_id'] ?>"
                     class="fw-600 text-emerald"><?= e($li['product_name']) ?></a></td>
              <td><?= (int)$li['quantity'] ?></td>
              <td><?= formatMoney((float)$li['unit_price'], $sym) ?></td>
              <td class="fw-600"><?= formatMoney((float)$li['line_total'], $sym) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="jt-card mb-3">
      <div class="jt-card-header"><h2>Invoice Info</h2></div>
      <div class="jt-card-body">
        <?php
        $fields = [
          'Invoice #'        => $sale['invoice_number'],
          'Date'             => date('d M Y', strtotime($sale['sale_date'])),
          'Customer'         => $sale['customer_name'],
          'Phone'            => $sale['customer_phone'] ?: '—',
          'Payment Method'   => ucwords(str_replace('_',' ',$sale['payment_method'])),
          'Payment Status'   => ucfirst($sale['payment_status']),
          'Recorded By'      => $sale['user_name'],
        ];
        foreach ($fields as $label => $val): ?>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted fs-13"><?= $label ?></span>
          <span class="fw-600 text-end"><?= e($val) ?></span>
        </div>
        <?php endforeach; ?>
        <?php if ($sale['notes']): ?>
        <div class="mt-2 text-muted fs-13"><?= nl2br(e($sale['notes'])) ?></div>
        <?php endif; ?>
      </div>
    </div>

    <div class="jt-card">
      <div class="jt-card-header"><h2>Totals</h2></div>
      <div class="jt-card-body">
        <div class="d-flex justify-content-between py-2 border-bottom"><span class="text-muted">Subtotal</span><span><?= formatMoney((float)$sale['subtotal'], $sym) ?></span></div>
        <div class="d-flex justify-content-between py-2 border-bottom"><span class="text-muted">Discount</span><span>- <?= formatMoney((float)$sale['discount'], $sym) ?></span></div>
        <div class="d-flex justify-content-between py-2 border-bottom"><span class="text-muted">Tax (<?= number_format((float)$sale['tax_rate'],1) ?>%)</span><span><?= formatMoney((float)$sale['tax_amount'], $sym) ?></span></div>
        <div class="d-flex justify-content-between py-2">
          <span class="fw-700">Grand Total</span>
          <span class="fw-700 fs-5 text-emerald"><?= formatMoney((float)$sale['grand_total'], $sym) ?></span>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
