<?php
/**
 * JewelTrack — Create New Sale / Invoice
 * TRANSACTION-SAFE: stock deducted only once, server validates all totals.
 * POST/Redirect/GET pattern prevents double submission.
 */

$pageTitle  = 'New Sale';
$activePage = 'sales';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';

$db        = getDB();
$sym       = currencySymbol();
$customers = $db->query("SELECT id, name FROM customers WHERE is_active=1 ORDER BY name")->fetchAll();
$taxDefault = (float)getSetting('tax_rate', '3');
$formToken  = formToken();
$errors     = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    if (preventDoubleSubmit('sale')) {
        setFlash('warning', 'This sale was already recorded. Please create a new one.');
        redirect('/jeweltrack/modules/sales/index.php');
    }

    $v = (new Validator($_POST))
          ->required('sale_date', 'Sale Date')
          ->date('sale_date',     'Sale Date')
          ->numeric('discount',   'Discount', 0)
          ->numeric('tax_rate',   'Tax Rate', 0, 100);
    $errors = $v->errors();

    $items = $_POST['items'] ?? [];
    if (empty($items)) {
        $errors['items'] = 'At least one product line item is required.';
    } else {
        foreach ($items as $idx => $item) {
            if ((int)($item['product_id'] ?? 0) <= 0) { $errors["item_{$idx}_p"] = "Line ".($idx+1).": Select product."; }
            if ((int)($item['quantity']   ?? 0) <= 0)  { $errors["item_{$idx}_q"] = "Line ".($idx+1).": Qty ≥ 1."; }
            if ((float)($item['unit_price']?? 0) < 0)  { $errors["item_{$idx}_pr"]= "Line ".($idx+1).": Price cannot be negative."; }
        }
    }

    if (empty($errors)) {
        $db->beginTransaction();
        try {
            $customerId = (int)($_POST['customer_id'] ?? 0) ?: null;
            $date       = $_POST['sale_date'];
            $discount   = (float)$_POST['discount'];
            $taxRate    = (float)$_POST['tax_rate'];
            $payMethod  = $_POST['payment_method']  ?? 'cash';
            $payStatus  = $_POST['payment_status']  ?? 'paid';
            $notes      = trim($_POST['notes'] ?? '');

            // Server-side totals
            $subtotal = 0;
            foreach ($items as $item) {
                $subtotal += (int)$item['quantity'] * (float)$item['unit_price'];
            }
            $taxable   = max(0, $subtotal - $discount);
            $taxAmount = round($taxable * $taxRate / 100, 2);
            $grand     = $taxable + $taxAmount;

            $invoiceNo = generateInvoiceNumber();

            $db->prepare(
                "INSERT INTO sales
                   (invoice_number, customer_id, sale_date, subtotal, discount, tax_rate, tax_amount,
                    grand_total, payment_method, payment_status, notes, user_id)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
            )->execute([
                $invoiceNo, $customerId, $date, $subtotal, $discount, $taxRate,
                $taxAmount, $grand, $payMethod, $payStatus, $notes, $_SESSION['user_id']
            ]);
            $saleId = (int)$db->lastInsertId();

            foreach ($items as $item) {
                $pid   = (int)$item['product_id'];
                $qty   = (int)$item['quantity'];
                $price = (float)$item['unit_price'];
                $line  = $qty * $price;

                // Lock & check stock
                $prodStmt = $db->prepare("SELECT id, name, quantity FROM products WHERE id=? AND is_active=1 FOR UPDATE");
                $prodStmt->execute([$pid]);
                $prod = $prodStmt->fetch();
                if (!$prod) throw new RuntimeException("Product ID $pid not found.");
                $qtyBefore = (int)$prod['quantity'];
                if ($qtyBefore < $qty) {
                    throw new RuntimeException(
                        "Insufficient stock for '{$prod['name']}'. Available: {$qtyBefore}, Requested: {$qty}."
                    );
                }
                $qtyAfter = $qtyBefore - $qty;

                // Insert sale item
                $db->prepare(
                    "INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, line_total) VALUES (?,?,?,?,?)"
                )->execute([$saleId, $pid, $qty, $price, $line]);

                // Deduct stock
                $db->prepare("UPDATE products SET quantity=? WHERE id=?")
                   ->execute([$qtyAfter, $pid]);

                // Movement
                $db->prepare(
                    "INSERT INTO stock_movements
                       (product_id, movement_type, quantity, qty_before, qty_after, reference_id, reference_type, notes, user_id)
                     VALUES (?, 'sale_dispatched', ?, ?, ?, ?, 'sale', ?, ?)"
                )->execute([$pid, -$qty, $qtyBefore, $qtyAfter, $saleId, $invoiceNo, $_SESSION['user_id']]);
            }

            $db->commit();
            logActivity('sale_created', 'sales', $saleId, "Sale $invoiceNo created");
            setFlash('success', "Invoice $invoiceNo created. Stock updated.");
            redirect('/jeweltrack/modules/sales/view.php?id=' . $saleId);

        } catch (Throwable $e) {
            $db->rollBack();
            $errors['db'] = $e->getMessage();
        }
    }
}
?>

<div class="page-header">
  <h1><i class="bi bi-receipt-cutoff text-gold me-2"></i>New Sale / Invoice</h1>
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/jeweltrack/modules/sales/index.php">Sales</a></li>
      <li class="breadcrumb-item active">New</li>
    </ol>
  </nav>
</div>

<?php if ($errors): ?>
<div class="alert alert-danger">
  <i class="bi bi-x-circle-fill me-2"></i><strong>Errors:</strong>
  <ul class="mb-0 mt-1"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<form method="POST" novalidate>
  <?= csrfField() ?>
  <input type="hidden" name="form_token" value="<?= e($formToken) ?>">

  <div class="row g-4">
    <div class="col-lg-8">
      <!-- Header -->
      <div class="jt-card mb-3">
        <div class="jt-card-header"><h2>Sale Details</h2></div>
        <div class="jt-card-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label for="customer_id" class="form-label">Customer</label>
              <select id="customer_id" name="customer_id" class="form-select">
                <option value="">Walk-in Customer</option>
                <?php foreach ($customers as $c): ?>
                <option value="<?= $c['id'] ?>" <?= ($_POST['customer_id']??'')==$c['id']?'selected':'' ?>>
                  <?= e($c['name']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-3">
              <label for="sale_date" class="form-label">Date <span class="text-danger">*</span></label>
              <input type="date" id="sale_date" name="sale_date" class="form-control"
                     value="<?= e($_POST['sale_date'] ?? date('Y-m-d')) ?>" required>
            </div>
            <div class="col-md-3">
              <label for="payment_method" class="form-label">Payment Method</label>
              <select id="payment_method" name="payment_method" class="form-select">
                <?php foreach (['cash','card','upi','bank_transfer','other'] as $pm): ?>
                <option value="<?= $pm ?>" <?= ($_POST['payment_method']??'cash')===$pm?'selected':'' ?>>
                  <?= ucwords(str_replace('_',' ',$pm)) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-3">
              <label for="payment_status" class="form-label">Payment Status</label>
              <select id="payment_status" name="payment_status" class="form-select">
                <option value="paid"    <?= ($_POST['payment_status']??'paid')==='paid'   ?'selected':'' ?>>Paid</option>
                <option value="partial" <?= ($_POST['payment_status']??'')==='partial'?'selected':'' ?>>Partial</option>
                <option value="unpaid"  <?= ($_POST['payment_status']??'')==='unpaid' ?'selected':'' ?>>Unpaid</option>
              </select>
            </div>
            <div class="col-9">
              <label for="notes" class="form-label">Notes</label>
              <input type="text" id="notes" name="notes" class="form-control"
                     placeholder="Optional notes…" value="<?= e($_POST['notes'] ?? '') ?>">
            </div>
          </div>
        </div>
      </div>

      <!-- Line Items -->
      <div class="jt-card">
        <div class="jt-card-header">
          <h2>Products</h2>
          <button type="button" class="btn btn-sm btn-emerald"
                  onclick="JT.addLineItem(document.getElementById('lineItems'),'sale')">
            <i class="bi bi-plus-lg me-1"></i>Add Product
          </button>
        </div>
        <div class="jt-card-body">
          <div id="lineItems"></div>
        </div>
      </div>
    </div>

    <!-- Summary -->
    <div class="col-lg-4">
      <div class="jt-card position-sticky" style="top:80px;">
        <div class="jt-card-header"><h2>Invoice Summary</h2></div>
        <div class="jt-card-body">
          <div class="d-flex justify-content-between mb-2">
            <span class="text-muted">Subtotal</span>
            <span class="fw-600" id="preview_subtotal">₹ 0.00</span>
          </div>
          <div class="mb-2">
            <label for="discount" class="form-label fs-13">Discount (<?= $sym ?>)</label>
            <input type="number" id="discount" name="discount" class="form-control form-control-sm"
                   step="0.01" min="0" value="<?= e($_POST['discount'] ?? '0') ?>">
          </div>
          <div class="mb-3">
            <label for="tax_rate" class="form-label fs-13"><?= e(getSetting('tax_label','GST')) ?> Rate (%)</label>
            <input type="number" id="tax_rate" name="tax_rate" class="form-control form-control-sm"
                   step="0.01" min="0" max="100" value="<?= e($_POST['tax_rate'] ?? $taxDefault) ?>">
          </div>
          <div class="d-flex justify-content-between mb-1">
            <span class="text-muted fs-13">Tax Amount</span>
            <span id="preview_tax">₹ 0.00</span>
          </div>
          <hr>
          <div class="d-flex justify-content-between mb-3">
            <span class="fw-700">Grand Total</span>
            <span class="fw-700 fs-5 text-emerald" id="preview_grand">₹ 0.00</span>
          </div>
          <div class="alert alert-info fs-13 mb-3">
            <i class="bi bi-shield-check me-1"></i>
            Stock availability &amp; totals verified on the server. Overselling is prevented.
          </div>
          <div class="d-grid gap-2">
            <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg me-1"></i>Create Invoice &amp; Deduct Stock</button>
            <a href="/jeweltrack/modules/sales/index.php" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('lineItems');
  JT.addLineItem(container, 'sale');
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
