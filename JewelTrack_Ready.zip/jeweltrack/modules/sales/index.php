<?php
/**
 * JewelTrack — Sales List
 */

$pageTitle  = 'Sales & Billing';
$activePage = 'sales';
require_once __DIR__ . '/../../includes/header.php';

$db  = getDB();
$sym = currencySymbol();

$search      = trim($_GET['q']          ?? '');
$filterCust  = (int)($_GET['customer']  ?? 0);
$filterStatus= trim($_GET['status']     ?? '');
$dateFrom    = $_GET['date_from']       ?? date('Y-m-01');
$dateTo      = $_GET['date_to']         ?? date('Y-m-d');
$page        = max(1, (int)($_GET['page'] ?? 1));

$where  = ['s.sale_date BETWEEN ? AND ?'];
$params = [$dateFrom, $dateTo];

if ($search !== '') { $where[] = 's.invoice_number LIKE ?'; $params[] = "%$search%"; }
if ($filterCust > 0) { $where[] = 's.customer_id = ?'; $params[] = $filterCust; }
if ($filterStatus !== '') { $where[] = 's.payment_status = ?'; $params[] = $filterStatus; }

$wc    = 'WHERE ' . implode(' AND ', $where);
$count = $db->prepare("SELECT COUNT(*) FROM sales s $wc");
$count->execute($params);
$total = (int)$count->fetchColumn();
$pager = paginate($total, $page, PER_PAGE);

$stmt = $db->prepare(
    "SELECT s.id, s.invoice_number, s.sale_date, s.grand_total, s.payment_method, s.payment_status,
            COALESCE(c.name,'Walk-in') AS customer_name, u.name AS user_name
     FROM sales s
     LEFT JOIN customers c ON c.id=s.customer_id
     JOIN users u ON u.id=s.user_id
     $wc ORDER BY s.created_at DESC
     LIMIT {$pager['per_page']} OFFSET {$pager['offset']}"
);
$stmt->execute($params);
$sales = $stmt->fetchAll();

$customers = $db->query("SELECT id, name FROM customers WHERE is_active=1 ORDER BY name")->fetchAll();

$totStmt = $db->prepare("SELECT COALESCE(SUM(grand_total),0) FROM sales s $wc");
$totStmt->execute($params);
$filteredTotal = (float)$totStmt->fetchColumn();

$qStr = http_build_query(array_filter(['q'=>$search,'customer'=>$filterCust?:null,'status'=>$filterStatus,'date_from'=>$dateFrom,'date_to'=>$dateTo]));
$baseUrl = '/jeweltrack/modules/sales/index.php?' . $qStr;
?>

<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div>
    <h1><i class="bi bi-receipt-cutoff text-gold me-2"></i>Sales &amp; Billing</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb"><li class="breadcrumb-item active">Sales History</li></ol>
    </nav>
  </div>
  <a href="/jeweltrack/modules/sales/create.php" class="btn btn-gold">
    <i class="bi bi-plus-lg me-1"></i>New Sale
  </a>
</div>

<form method="GET">
  <div class="filter-bar">
    <div style="min-width:140px;">
      <label class="form-label mb-1 fs-13">Invoice #</label>
      <input type="text" name="q" class="form-control form-control-sm" placeholder="INV-2026-…" value="<?= e($search) ?>">
    </div>
    <div style="min-width:150px;">
      <label class="form-label mb-1 fs-13">Customer</label>
      <select name="customer" class="form-select form-select-sm">
        <option value="">All Customers</option>
        <?php foreach ($customers as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $filterCust==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="min-width:110px;">
      <label class="form-label mb-1 fs-13">Status</label>
      <select name="status" class="form-select form-select-sm">
        <option value="">All</option>
        <option value="paid" <?= $filterStatus==='paid'?'selected':'' ?>>Paid</option>
        <option value="partial" <?= $filterStatus==='partial'?'selected':'' ?>>Partial</option>
        <option value="unpaid" <?= $filterStatus==='unpaid'?'selected':'' ?>>Unpaid</option>
      </select>
    </div>
    <div><label class="form-label mb-1 fs-13">From</label>
      <input type="date" name="date_from" class="form-control form-control-sm" value="<?= $dateFrom ?>"></div>
    <div><label class="form-label mb-1 fs-13">To</label>
      <input type="date" name="date_to" class="form-control form-control-sm" value="<?= $dateTo ?>"></div>
    <div class="d-flex align-items-end gap-2">
      <button type="submit" class="btn btn-emerald btn-sm"><i class="bi bi-search me-1"></i>Filter</button>
      <a href="/jeweltrack/modules/sales/index.php" class="btn btn-sm btn-outline-secondary">Reset</a>
    </div>
  </div>
</form>

<div class="alert alert-info d-flex align-items-center gap-2 mb-3 fs-13">
  <i class="bi bi-info-circle-fill"></i>
  Showing <strong><?= number_format($total) ?></strong> invoice(s) &mdash;
  Total Revenue: <strong><?= formatMoney($filteredTotal, $sym) ?></strong>
</div>

<div class="jt-card">
  <div class="jt-card-header">
    <h2>Invoices <span class="badge bg-secondary ms-1"><?= number_format($total) ?></span></h2>
  </div>
  <div class="table-responsive">
    <?php if ($sales): ?>
    <table class="jt-table">
      <thead>
        <tr><th>Invoice #</th><th>Date</th><th>Customer</th><th>Payment</th><th>Total</th><th>Status</th><th>By</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($sales as $sale): ?>
        <tr>
          <td>
            <a href="/jeweltrack/modules/sales/view.php?id=<?= $sale['id'] ?>" class="fw-600 text-emerald">
              <?= e($sale['invoice_number']) ?>
            </a>
          </td>
          <td class="fs-13"><?= date('d M Y', strtotime($sale['sale_date'])) ?></td>
          <td><?= e($sale['customer_name']) ?></td>
          <td class="fs-13 text-muted"><?= ucfirst(str_replace('_',' ',$sale['payment_method'])) ?></td>
          <td class="fw-600"><?= formatMoney((float)$sale['grand_total'], $sym) ?></td>
          <td>
            <span class="badge bg-<?= match($sale['payment_status']){ 'paid'=>'success','partial'=>'warning',default=>'secondary' } ?>">
              <?= ucfirst(e($sale['payment_status'])) ?>
            </span>
          </td>
          <td class="fs-13 text-muted"><?= e($sale['user_name']) ?></td>
          <td>
            <div class="d-flex gap-1">
              <a href="/jeweltrack/modules/sales/view.php?id=<?= $sale['id'] ?>"
                 class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
              <a href="/jeweltrack/modules/sales/invoice.php?id=<?= $sale['id'] ?>"
                 class="btn btn-sm btn-outline-gold" target="_blank"><i class="bi bi-printer"></i></a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><i class="bi bi-receipt-cutoff d-block"></i><p>No sales found.</p></div>
    <?php endif; ?>
  </div>
  <?php if ($pager['total_pages'] > 1): ?>
  <div class="jt-card-body border-top d-flex justify-content-between align-items-center">
    <small class="text-muted">Showing <?= $pager['offset']+1 ?>–<?= min($pager['offset']+$pager['per_page'],$total) ?> of <?= $total ?></small>
    <?= renderPagination($pager, $baseUrl) ?>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
