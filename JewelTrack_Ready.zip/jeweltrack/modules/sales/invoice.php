<?php
/**
 * JewelTrack — Printable Invoice
 * Opens in a new tab; use browser print (Ctrl+P).
 */
require_once __DIR__ . '/../../config/app.php';
requireLogin();

$db  = getDB();
$sym = currencySymbol();
$id  = (int)($_GET['id'] ?? 0);
if (!$id) die('Invalid invoice.');

$saleStmt = $db->prepare(
    "SELECT s.*, COALESCE(c.name,'Walk-in Customer') AS customer_name,
            c.phone AS customer_phone, c.email AS customer_email,
            c.address AS customer_address,
            u.name AS user_name
     FROM sales s LEFT JOIN customers c ON c.id=s.customer_id
     JOIN users u ON u.id=s.user_id WHERE s.id=?"
);
$saleStmt->execute([$id]);
$sale = $saleStmt->fetch();
if (!$sale) die('Invoice not found.');

$itemStmt = $db->prepare(
    "SELECT si.*, p.name AS product_name, p.sku, p.metal_type, p.purity
     FROM sale_items si JOIN products p ON p.id=si.product_id WHERE si.sale_id=?"
);
$itemStmt->execute([$id]);
$items = $itemStmt->fetchAll();

$shopName    = getSetting('shop_name','JewelTrack Store');
$shopPhone   = getSetting('shop_phone','');
$shopEmail   = getSetting('shop_email','');
$shopAddress = getSetting('shop_address','');
$invFooter   = getSetting('invoice_footer','Thank you for your purchase!');
$taxLabel    = getSetting('tax_label','GST');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Invoice <?= e($sale['invoice_number']) ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * { box-sizing:border-box; margin:0; padding:0; }
    body { font-family:'Inter',sans-serif; font-size:13px; color:#252923; background:#fff; padding:32px; }
    .invoice-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:28px; }
    .shop-name { font-size:22px; font-weight:700; color:#123D32; }
    .shop-detail { font-size:11px; color:#777D78; line-height:1.7; }
    .invoice-title { text-align:right; }
    .invoice-title h2 { font-size:26px; font-weight:700; color:#C9A45C; text-transform:uppercase; letter-spacing:2px; }
    .invoice-title p { font-size:11px; color:#777; }
    .divider { border:none; border-top:2px solid #C9A45C; margin:16px 0; }
    .info-row { display:flex; justify-content:space-between; margin-bottom:20px; }
    .info-col { flex:1; }
    .info-col h3 { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:#777D78; margin-bottom:6px; }
    table { width:100%; border-collapse:collapse; margin-bottom:20px; }
    thead th { background:#123D32; color:#fff; padding:9px 12px; font-size:11px; text-align:left; }
    tbody td { padding:9px 12px; border-bottom:1px solid #E7E7E1; font-size:12px; }
    tbody tr:nth-child(even) { background:#F8F6F0; }
    .totals { width:260px; margin-left:auto; }
    .totals .row { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #E7E7E1; font-size:12px; }
    .totals .grand { font-size:15px; font-weight:700; color:#123D32; }
    .footer-note { margin-top:32px; padding-top:12px; border-top:1px solid #E7E7E1; font-size:10px; color:#777D78; text-align:center; }
    .badge { display:inline-block; padding:2px 8px; border-radius:4px; font-size:10px; font-weight:600; }
    .badge-success { background:#d1fae5; color:#065f46; }
    @media print {
      body { padding:16px; }
      .no-print { display:none; }
    }
  </style>
</head>
<body>

<div class="no-print" style="margin-bottom:16px;">
  <button onclick="window.print()"
          style="background:#C9A45C;border:none;color:#0B2923;padding:8px 20px;border-radius:6px;font-weight:600;cursor:pointer;font-size:13px;">
    🖨 Print Invoice
  </button>
  <a href="/jeweltrack/modules/sales/view.php?id=<?= $id ?>"
     style="margin-left:12px;color:#123D32;font-size:13px;">← Back</a>
</div>

<!-- Header -->
<div class="invoice-header">
  <div>
    <div class="shop-name">💎 <?= e($shopName) ?></div>
    <div class="shop-detail">
      <?= e($shopAddress) ?><br>
      <?php if ($shopPhone): ?>📞 <?= e($shopPhone) ?><?php endif; ?>
      <?php if ($shopEmail): ?> &nbsp;|&nbsp; ✉ <?= e($shopEmail) ?><?php endif; ?>
    </div>
  </div>
  <div class="invoice-title">
    <h2>Invoice</h2>
    <p><strong>#<?= e($sale['invoice_number']) ?></strong></p>
    <p>Date: <?= date('d M Y', strtotime($sale['sale_date'])) ?></p>
    <p><span class="badge badge-success"><?= ucfirst($sale['payment_status']) ?></span></p>
  </div>
</div>

<hr class="divider">

<!-- Bill To / Payment -->
<div class="info-row">
  <div class="info-col">
    <h3>Bill To</h3>
    <strong><?= e($sale['customer_name']) ?></strong><br>
    <?php if ($sale['customer_phone']): ?><?= e($sale['customer_phone']) ?><br><?php endif; ?>
    <?php if ($sale['customer_email']): ?><?= e($sale['customer_email']) ?><br><?php endif; ?>
    <?php if ($sale['customer_address']): ?><?= nl2br(e($sale['customer_address'])) ?><?php endif; ?>
  </div>
  <div class="info-col" style="text-align:right;">
    <h3>Payment</h3>
    <p><?= ucwords(str_replace('_',' ',$sale['payment_method'])) ?></p>
    <p style="color:#777;">Served by: <?= e($sale['user_name']) ?></p>
  </div>
</div>

<!-- Items Table -->
<table>
  <thead>
    <tr>
      <th>#</th>
      <th>SKU</th>
      <th>Description</th>
      <th>Metal / Purity</th>
      <th style="text-align:right;">Qty</th>
      <th style="text-align:right;">Unit Price</th>
      <th style="text-align:right;">Total</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($items as $i => $item): ?>
    <tr>
      <td><?= $i+1 ?></td>
      <td><?= e($item['sku']) ?></td>
      <td><?= e($item['product_name']) ?></td>
      <td><?= e($item['metal_type']) ?><?= $item['purity'] ? ' / ' . e($item['purity']) : '' ?></td>
      <td style="text-align:right;"><?= (int)$item['quantity'] ?></td>
      <td style="text-align:right;"><?= $sym ?> <?= number_format((float)$item['unit_price'], 2) ?></td>
      <td style="text-align:right;font-weight:600;"><?= $sym ?> <?= number_format((float)$item['line_total'], 2) ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<!-- Totals -->
<div class="totals">
  <div class="row"><span>Subtotal</span><span><?= $sym ?> <?= number_format((float)$sale['subtotal'],2) ?></span></div>
  <?php if ($sale['discount'] > 0): ?>
  <div class="row"><span>Discount</span><span>- <?= $sym ?> <?= number_format((float)$sale['discount'],2) ?></span></div>
  <?php endif; ?>
  <div class="row">
    <span><?= e($taxLabel) ?> (<?= number_format((float)$sale['tax_rate'],1) ?>%)</span>
    <span><?= $sym ?> <?= number_format((float)$sale['tax_amount'],2) ?></span>
  </div>
  <div class="row grand">
    <span>Grand Total</span>
    <span><?= $sym ?> <?= number_format((float)$sale['grand_total'],2) ?></span>
  </div>
</div>

<!-- Footer -->
<div class="footer-note">
  <?= e($invFooter) ?><br>
  <small style="color:#aaa;">This is a computer-generated invoice. No signature required. JewelTrack v1.0</small>
</div>

</body>
</html>
