<?php
/**
 * JewelTrack — Reports & Analytics
 */
$pageTitle = 'Reports & Analytics';
$activePage = 'reports';
require_once __DIR__ . '/../../includes/header.php';

$db = getDB();
$sym = currencySymbol();

// Date range filters
$startDate = trim($_GET['start_date'] ?? date('Y-m-01'));
$endDate   = trim($_GET['end_date'] ?? date('Y-m-d'));
$tab       = trim($_GET['tab'] ?? 'overview');

// Validate dates
if (!strtotime($startDate)) $startDate = date('Y-m-01');
if (!strtotime($endDate))   $endDate   = date('Y-m-d');

// --- 1. OVERVIEW KPIS ---
// Total Sales & Profit within range
$stmtSales = $db->prepare(
    "SELECT COUNT(*) AS total_invoices,
            COALESCE(SUM(grand_total), 0) AS total_revenue,
            COALESCE(SUM(tax_amount), 0) AS total_tax,
            COALESCE(SUM(discount), 0) AS total_discount
     FROM sales
     WHERE sale_date BETWEEN ? AND ?"
);
$stmtSales->execute([$startDate, $endDate]);
$salesKpi = $stmtSales->fetch();

// Total Purchases within range
$stmtPurch = $db->prepare(
    "SELECT COUNT(*) AS total_orders,
            COALESCE(SUM(grand_total), 0) AS total_purchases
     FROM purchases
     WHERE purchase_date BETWEEN ? AND ?"
);
$stmtPurch->execute([$startDate, $endDate]);
$purchKpi = $stmtPurch->fetch();

// Total Items sold & Cost of Goods Sold (approx based on product purchase_cost)
$stmtCogs = $db->prepare(
    "SELECT COALESCE(SUM(si.quantity), 0) AS units_sold,
            COALESCE(SUM(si.quantity * p.purchase_cost), 0) AS est_cogs
     FROM sale_items si
     JOIN sales s ON si.sale_id = s.id
     JOIN products p ON si.product_id = p.id
     WHERE s.sale_date BETWEEN ? AND ?"
);
$stmtCogs->execute([$startDate, $endDate]);
$cogsKpi = $stmtCogs->fetch();

$estProfit = $salesKpi['total_revenue'] - $cogsKpi['est_cogs'];
$marginPct = ($salesKpi['total_revenue'] > 0) ? ($estProfit / $salesKpi['total_revenue']) * 100 : 0;

// Current Total Inventory Stats
$stmtInv = $db->query(
    "SELECT COUNT(*) AS total_skus,
            COALESCE(SUM(quantity), 0) AS total_qty,
            COALESCE(SUM(quantity * purchase_cost), 0) AS cost_value,
            COALESCE(SUM(quantity * selling_price), 0) AS retail_value,
            SUM(CASE WHEN quantity <= reorder_level THEN 1 ELSE 0 END) AS low_stock_count
     FROM products WHERE is_active = 1"
);
$invKpi = $stmtInv->fetch();

// --- 2. SALES DETAILS ---
$salesDetails = [];
if ($tab === 'sales' || $tab === 'overview') {
    $stmt = $db->prepare(
        "SELECT s.*, c.name AS customer_name, u.name AS staff_name,
                (SELECT COUNT(*) FROM sale_items WHERE sale_id = s.id) AS item_count
         FROM sales s
         LEFT JOIN customers c ON s.customer_id = c.id
         JOIN users u ON s.user_id = u.id
         WHERE s.sale_date BETWEEN ? AND ?
         ORDER BY s.sale_date DESC, s.id DESC
         LIMIT 50"
    );
    $stmt->execute([$startDate, $endDate]);
    $salesDetails = $stmt->fetchAll();
}

// Payment method breakdown
$stmtPay = $db->prepare(
    "SELECT payment_method, COUNT(*) AS count, SUM(grand_total) AS total
     FROM sales
     WHERE sale_date BETWEEN ? AND ?
     GROUP BY payment_method"
);
$stmtPay->execute([$startDate, $endDate]);
$paymentBreakdown = $stmtPay->fetchAll();

// --- 3. TOP SELLING PRODUCTS ---
$topProducts = [];
if ($tab === 'top_products' || $tab === 'overview') {
    $stmtTop = $db->prepare(
        "SELECT p.id, p.sku, p.name, p.metal_type, p.purity,
                SUM(si.quantity) AS total_qty_sold,
                SUM(si.line_total) AS total_revenue
         FROM sale_items si
         JOIN sales s ON si.sale_id = s.id
         JOIN products p ON si.product_id = p.id
         WHERE s.sale_date BETWEEN ? AND ?
         GROUP BY p.id, p.sku, p.name, p.metal_type, p.purity
         ORDER BY total_qty_sold DESC
         LIMIT 10"
    );
    $stmtTop->execute([$startDate, $endDate]);
    $topProducts = $stmtTop->fetchAll();
}

// --- 4. CATEGORY BREAKDOWN ---
$catReport = [];
if ($tab === 'categories' || $tab === 'overview') {
    $stmtCat = $db->prepare(
        "SELECT c.name AS category_name,
                COUNT(DISTINCT p.id) AS product_count,
                COALESCE(SUM(si.quantity), 0) AS units_sold,
                COALESCE(SUM(si.line_total), 0) AS total_sales
         FROM categories c
         LEFT JOIN products p ON c.id = p.category_id
         LEFT JOIN sale_items si ON p.id = si.product_id
         LEFT JOIN sales s ON si.sale_id = s.id AND s.sale_date BETWEEN ? AND ?
         GROUP BY c.id, c.name
         ORDER BY total_sales DESC"
    );
    $stmtCat->execute([$startDate, $endDate]);
    $catReport = $stmtCat->fetchAll();
}

// --- 5. LOW STOCK & INVENTORY VALUATION ---
$lowStockItems = [];
if ($tab === 'inventory') {
    $stmtLow = $db->query(
        "SELECT p.*, c.name AS category_name
         FROM products p
         JOIN categories c ON p.category_id = c.id
         WHERE p.is_active = 1 AND p.quantity <= p.reorder_level
         ORDER BY p.quantity ASC"
    );
    $lowStockItems = $stmtLow->fetchAll();
}
?>

<div class="page-header d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
  <div>
    <h1><i class="bi bi-bar-chart-line text-gold me-2"></i>Reports &amp; Analytics</h1>
    <p class="text-muted mb-0">Business performance metrics, sales breakdown, and inventory audit.</p>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary">
      <i class="bi bi-printer me-1"></i>Print Report
    </button>
  </div>
</div>

<!-- Date Filter Form -->
<div class="jt-card mb-4 no-print">
  <div class="jt-card-body p-3">
    <form method="GET" class="row g-2 align-items-end">
      <input type="hidden" name="tab" value="<?= e($tab) ?>">
      <div class="col-sm-4 col-md-3">
        <label class="form-label small text-muted mb-1">From Date</label>
        <input type="date" name="start_date" class="form-control form-control-sm" value="<?= e($startDate) ?>" required>
      </div>
      <div class="col-sm-4 col-md-3">
        <label class="form-label small text-muted mb-1">To Date</label>
        <input type="date" name="end_date" class="form-control form-control-sm" value="<?= e($endDate) ?>" required>
      </div>
      <div class="col-sm-4 col-md-3 d-flex gap-2">
        <button type="submit" class="btn btn-gold btn-sm w-100">
          <i class="bi bi-filter me-1"></i>Apply Filter
        </button>
        <a href="?tab=<?= e($tab) ?>" class="btn btn-outline-secondary btn-sm" title="Reset to current month">
          <i class="bi bi-arrow-counterclockwise"></i>
        </a>
      </div>
      <div class="col-12 col-md-3 text-md-end text-muted small">
        Period: <strong><?= date('d M Y', strtotime($startDate)) ?></strong> to <strong><?= date('d M Y', strtotime($endDate)) ?></strong>
      </div>
    </form>
  </div>
</div>

<!-- KPI Summary Cards -->
<div class="row g-3 mb-4">
  <div class="col-sm-6 col-lg-3">
    <div class="kpi-card">
      <div class="kpi-icon bg-gold-light text-gold"><i class="bi bi-cash-stack"></i></div>
      <div class="kpi-body">
        <div class="kpi-label">Sales Revenue</div>
        <div class="kpi-value"><?= $sym . number_format($salesKpi['total_revenue'], 2) ?></div>
        <div class="kpi-sub text-muted"><?= (int)$salesKpi['total_invoices'] ?> invoices generated</div>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-lg-3">
    <div class="kpi-card">
      <div class="kpi-icon bg-success-light text-success"><i class="bi bi-graph-up-arrow"></i></div>
      <div class="kpi-body">
        <div class="kpi-label">Estimated Gross Profit</div>
        <div class="kpi-value text-success"><?= $sym . number_format($estProfit, 2) ?></div>
        <div class="kpi-sub text-muted">Margin: <?= number_format($marginPct, 1) ?>%</div>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-lg-3">
    <div class="kpi-card">
      <div class="kpi-icon bg-primary-light text-primary"><i class="bi bi-cart-check"></i></div>
      <div class="kpi-body">
        <div class="kpi-label">Purchases Cost</div>
        <div class="kpi-value"><?= $sym . number_format($purchKpi['total_purchases'], 2) ?></div>
        <div class="kpi-sub text-muted"><?= (int)$purchKpi['total_orders'] ?> purchase orders</div>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-lg-3">
    <div class="kpi-card">
      <div class="kpi-icon bg-warning-light text-warning"><i class="bi bi-gem"></i></div>
      <div class="kpi-body">
        <div class="kpi-label">Current Stock Value</div>
        <div class="kpi-value"><?= $sym . number_format($invKpi['retail_value'], 2) ?></div>
        <div class="kpi-sub text-muted">Cost: <?= $sym . number_format($invKpi['cost_value'], 2) ?> (<?= (int)$invKpi['total_qty'] ?> pcs)</div>
      </div>
    </div>
  </div>
</div>

<!-- Navigation Tabs -->
<ul class="nav nav-tabs mb-4 no-print">
  <li class="nav-item">
    <a class="nav-link <?= $tab === 'overview' ? 'active' : '' ?>" href="?tab=overview&start_date=<?= urlencode($startDate) ?>&end_date=<?= urlencode($endDate) ?>">
      <i class="bi bi-grid me-1"></i>Overview
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?= $tab === 'sales' ? 'active' : '' ?>" href="?tab=sales&start_date=<?= urlencode($startDate) ?>&end_date=<?= urlencode($endDate) ?>">
      <i class="bi bi-receipt me-1"></i>Sales Report
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?= $tab === 'top_products' ? 'active' : '' ?>" href="?tab=top_products&start_date=<?= urlencode($startDate) ?>&end_date=<?= urlencode($endDate) ?>">
      <i class="bi bi-star me-1"></i>Top Products
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?= $tab === 'categories' ? 'active' : '' ?>" href="?tab=categories&start_date=<?= urlencode($startDate) ?>&end_date=<?= urlencode($endDate) ?>">
      <i class="bi bi-tags me-1"></i>Category Sales
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?= $tab === 'inventory' ? 'active' : '' ?>" href="?tab=inventory&start_date=<?= urlencode($startDate) ?>&end_date=<?= urlencode($endDate) ?>">
      <i class="bi bi-exclamation-triangle me-1"></i>Inventory &amp; Low Stock
      <?php if ($invKpi['low_stock_count'] > 0): ?>
        <span class="badge bg-danger rounded-pill ms-1"><?= (int)$invKpi['low_stock_count'] ?></span>
      <?php endif; ?>
    </a>
  </li>
</ul>

<?php if ($tab === 'overview' || $tab === 'sales'): ?>
<div class="row g-4 mb-4">
  <!-- Payment Method Distribution -->
  <div class="col-lg-4">
    <div class="jt-card h-100">
      <div class="jt-card-header">
        <h5 class="mb-0"><i class="bi bi-pie-chart text-gold me-2"></i>Payment Breakdown</h5>
      </div>
      <div class="jt-card-body p-0">
        <?php if (empty($paymentBreakdown)): ?>
          <p class="text-muted p-4 text-center mb-0">No sales recorded in this period.</p>
        <?php else: ?>
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr><th>Method</th><th class="text-center">Count</th><th class="text-end">Amount</th></tr>
            </thead>
            <tbody>
              <?php foreach ($paymentBreakdown as $pay): ?>
                <tr>
                  <td>
                    <span class="badge bg-secondary text-uppercase"><?= e($pay['payment_method']) ?></span>
                  </td>
                  <td class="text-center"><?= (int)$pay['count'] ?></td>
                  <td class="text-end fw-semibold"><?= $sym . number_format($pay['total'], 2) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Recent Sales List -->
  <div class="col-lg-8">
    <div class="jt-card h-100">
      <div class="jt-card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="bi bi-receipt-cutoff text-gold me-2"></i>Sales in Selected Period</h5>
        <a href="/jeweltrack/modules/sales/create.php" class="btn btn-sm btn-gold no-print">New Sale</a>
      </div>
      <div class="jt-card-body p-0">
        <?php if (empty($salesDetails)): ?>
          <p class="text-muted p-4 text-center mb-0">No sales found for the selected date range.</p>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th>Invoice #</th>
                  <th>Date</th>
                  <th>Customer</th>
                  <th class="text-center">Items</th>
                  <th class="text-end">Amount</th>
                  <th class="text-center no-print">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($salesDetails as $s): ?>
                  <tr>
                    <td>
                      <a href="/jeweltrack/modules/sales/view.php?id=<?= $s['id'] ?>" class="fw-semibold text-primary">
                        <?= e($s['invoice_number']) ?>
                      </a>
                    </td>
                    <td><?= date('d M Y', strtotime($s['sale_date'])) ?></td>
                    <td><?= e($s['customer_name'] ?? 'Walk-in Customer') ?></td>
                    <td class="text-center"><span class="badge bg-light text-dark border"><?= (int)$s['item_count'] ?></span></td>
                    <td class="text-end fw-semibold text-gold"><?= $sym . number_format($s['grand_total'], 2) ?></td>
                    <td class="text-center no-print">
                      <a href="/jeweltrack/modules/sales/invoice.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-secondary py-0 px-2" title="Invoice" target="_blank">
                        <i class="bi bi-printer"></i>
                      </a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($tab === 'overview' || $tab === 'top_products'): ?>
<!-- Top Selling Products -->
<div class="jt-card mb-4">
  <div class="jt-card-header">
    <h5 class="mb-0"><i class="bi bi-trophy text-gold me-2"></i>Best Selling Jewellery (By Quantity)</h5>
  </div>
  <div class="jt-card-body p-0">
    <?php if (empty($topProducts)): ?>
      <p class="text-muted p-4 text-center mb-0">No product sales recorded in this date range.</p>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
            <tr>
              <th>SKU</th>
              <th>Product Name</th>
              <th>Metal / Purity</th>
              <th class="text-center">Units Sold</th>
              <th class="text-end">Total Revenue</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($topProducts as $idx => $p): ?>
              <tr>
                <td><span class="badge bg-dark"><?= e($p['sku']) ?></span></td>
                <td>
                  <a href="/jeweltrack/modules/products/view.php?id=<?= $p['id'] ?>" class="fw-semibold text-decoration-none">
                    <?= e($p['name']) ?>
                  </a>
                </td>
                <td><span class="badge bg-warning text-dark"><?= e($p['metal_type']) ?></span> <?= e($p['purity'] ?? '') ?></td>
                <td class="text-center fw-bold text-success"><?= (int)$p['total_qty_sold'] ?></td>
                <td class="text-end fw-bold text-gold"><?= $sym . number_format($p['total_revenue'], 2) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php if ($tab === 'categories'): ?>
<!-- Category Performance -->
<div class="jt-card mb-4">
  <div class="jt-card-header">
    <h5 class="mb-0"><i class="bi bi-tags text-gold me-2"></i>Category Sales Performance</h5>
  </div>
  <div class="jt-card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr>
            <th>Category Name</th>
            <th class="text-center">Available SKUs</th>
            <th class="text-center">Units Sold</th>
            <th class="text-end">Revenue</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($catReport as $cat): ?>
            <tr>
              <td class="fw-semibold"><?= e($cat['category_name']) ?></td>
              <td class="text-center"><?= (int)$cat['product_count'] ?></td>
              <td class="text-center"><?= (int)$cat['units_sold'] ?></td>
              <td class="text-end fw-bold text-gold"><?= $sym . number_format($cat['total_sales'], 2) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($tab === 'inventory'): ?>
<!-- Low Stock Alert and Inventory Valuation -->
<div class="row g-4 mb-4">
  <div class="col-12">
    <div class="jt-card border-danger">
      <div class="jt-card-header bg-danger text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="bi bi-exclamation-triangle-fill me-2"></i>Items At or Below Reorder Level</h5>
        <span class="badge bg-white text-danger fw-bold"><?= count($lowStockItems) ?> items alert</span>
      </div>
      <div class="jt-card-body p-0">
        <?php if (empty($lowStockItems)): ?>
          <p class="text-success p-4 text-center mb-0"><i class="bi bi-check-circle me-1"></i>All product stock quantities are currently healthy.</p>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th>SKU</th>
                  <th>Item Name</th>
                  <th>Category</th>
                  <th class="text-center">Current Qty</th>
                  <th class="text-center">Reorder Level</th>
                  <th class="text-end">Unit Cost</th>
                  <th class="text-center no-print">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($lowStockItems as $item): ?>
                  <tr>
                    <td><code><?= e($item['sku']) ?></code></td>
                    <td class="fw-semibold"><?= e($item['name']) ?></td>
                    <td><?= e($item['category_name']) ?></td>
                    <td class="text-center">
                      <span class="badge <?= $item['quantity'] <= 0 ? 'bg-danger' : 'bg-warning text-dark' ?>">
                        <?= (int)$item['quantity'] ?> pcs
                      </span>
                    </td>
                    <td class="text-center text-muted"><?= (int)$item['reorder_level'] ?></td>
                    <td class="text-end"><?= $sym . number_format($item['purchase_cost'], 2) ?></td>
                    <td class="text-center no-print">
                      <a href="/jeweltrack/modules/purchases/create.php" class="btn btn-sm btn-gold py-0 px-2">Order Stock</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
