<?php
/**
 * JewelTrack — User Management (Admin Only)
 */
$pageTitle = 'User Management';
$activePage = 'users';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';

requireAdmin();

$db = getDB();
$errors = [];
$success = '';

// Handle Add User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_user') {
    verifyCsrf();
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $role     = trim($_POST['role'] ?? 'staff');
    $password = $_POST['password'] ?? '';

    if (empty($name)) {
        $errors[] = 'Full Name is required.';
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email address is required.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if (!in_array($role, ['admin', 'staff'])) {
        $role = 'staff';
    }

    if (empty($errors)) {
        // Check duplicate email
        $chk = $db->prepare("SELECT id FROM users WHERE email = ?");
        $chk->execute([$email]);
        if ($chk->fetch()) {
            $errors[] = 'A user with this email address already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (name, email, password_hash, role, is_active) VALUES (?, ?, ?, ?, 1)");
            $stmt->execute([$name, $email, $hash, $role]);
            $newId = $db->lastInsertId();
            logActivity('user_created', 'users', (int)$newId, "Created user '{$name}' with role '{$role}'");
            setFlash('success', "User '{$name}' created successfully.");
            redirect('/jeweltrack/modules/users/index.php');
        }
    }
}

// Handle Status Toggle (activate / deactivate)
if (isset($_GET['toggle_id'])) {
    $toggleId = (int)$_GET['toggle_id'];
    if ($toggleId === (int)$_SESSION['user_id']) {
        setFlash('danger', 'You cannot deactivate your own account.');
    } else {
        $stmt = $db->prepare("UPDATE users SET is_active = IF(is_active=1, 0, 1) WHERE id = ?");
        $stmt->execute([$toggleId]);
        logActivity('user_status_toggled', 'users', $toggleId, "Toggled status for user ID {$toggleId}");
        setFlash('success', 'User account status updated.');
    }
    redirect('/jeweltrack/modules/users/index.php');
}

// Fetch all users
$users = $db->query("SELECT id, name, email, role, is_active, last_login_at, created_at FROM users ORDER BY id ASC")->fetchAll();
?>

<div class="page-header d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
  <div>
    <h1><i class="bi bi-person-lock text-gold me-2"></i>User Management</h1>
    <p class="text-muted mb-0">Control staff access, authentication roles, and account permissions.</p>
  </div>
  <div>
    <button type="button" class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addUserModal">
      <i class="bi bi-person-plus-fill me-1"></i>Add New User
    </button>
  </div>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0">
      <?php foreach ($errors as $err): ?>
        <li><?= e($err) ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="jt-card">
  <div class="jt-card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Last Login</th>
            <th>Created</th>
            <th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $u): ?>
            <tr>
              <td><?= (int)$u['id'] ?></td>
              <td class="fw-semibold">
                <?= e($u['name']) ?>
                <?php if ($u['id'] === (int)$_SESSION['user_id']): ?>
                  <span class="badge bg-primary-light text-primary ms-1">You</span>
                <?php endif; ?>
              </td>
              <td><?= e($u['email']) ?></td>
              <td>
                <span class="badge <?= $u['role'] === 'admin' ? 'bg-gold text-dark' : 'bg-info text-dark' ?> text-uppercase">
                  <?= e($u['role']) ?>
                </span>
              </td>
              <td>
                <span class="badge <?= $u['is_active'] ? 'bg-success' : 'bg-danger' ?>">
                  <?= $u['is_active'] ? 'Active' : 'Inactive' ?>
                </span>
              </td>
              <td class="text-muted small">
                <?= $u['last_login_at'] ? date('d M Y, h:i A', strtotime($u['last_login_at'])) : 'Never' ?>
              </td>
              <td class="text-muted small"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
              <td class="text-end">
                <?php if ($u['id'] !== (int)$_SESSION['user_id']): ?>
                  <a href="?toggle_id=<?= $u['id'] ?>" class="btn btn-sm <?= $u['is_active'] ? 'btn-outline-danger' : 'btn-outline-success' ?>"
                     onclick="return confirm('Change status for this user?');">
                    <i class="bi <?= $u['is_active'] ? 'bi-person-x' : 'bi-person-check' ?> me-1"></i>
                    <?= $u['is_active'] ? 'Deactivate' : 'Activate' ?>
                  </a>
                <?php else: ?>
                  <span class="text-muted small">Current User</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal: Add New User -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" novalidate>
        <?= csrfField() ?>
        <input type="hidden" name="action" value="add_user">
        <div class="modal-header">
          <h5 class="modal-title" id="addUserModalLabel"><i class="bi bi-person-plus text-gold me-2"></i>Create New User</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Full Name <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" required placeholder="e.g. Rahul Sharma">
          </div>
          <div class="mb-3">
            <label class="form-label">Email Address <span class="text-danger">*</span></label>
            <input type="email" name="email" class="form-control" required placeholder="user@jeweltrack.com">
          </div>
          <div class="mb-3">
            <label class="form-label">Temporary Password <span class="text-danger">*</span></label>
            <input type="password" name="password" class="form-control" required minlength="6" placeholder="Min 6 characters">
          </div>
          <div class="mb-3">
            <label class="form-label">Role <span class="text-danger">*</span></label>
            <select name="role" class="form-select">
              <option value="staff" selected>Staff (Sales &amp; Stock)</option>
              <option value="admin">Administrator (Full Access)</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg me-1"></i>Save User</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
