<?php
/**
 * JewelTrack — Purchases List
 */

$pageTitle  = 'Purchases';
$activePage = 'purchases';
require_once __DIR__ . '/../../includes/header.php';

$db  = getDB();
$sym = currencySymbol();

$search      = trim($_GET['q']          ?? '');
$filterSup   = (int)($_GET['supplier']  ?? 0);
$filterStatus= trim($_GET['status']     ?? '');
$dateFrom    = $_GET['date_from']       ?? date('Y-m-01');
$dateTo      = $_GET['date_to']         ?? date('Y-m-d');
$page        = max(1, (int)($_GET['page'] ?? 1));

$where  = ['p.purchase_date BETWEEN ? AND ?'];
$params = [$dateFrom, $dateTo];

if ($search !== '') { $where[] = 'p.ref_number LIKE ?'; $params[] = "%$search%"; }
if ($filterSup > 0) { $where[] = 'p.supplier_id = ?'; $params[] = $filterSup; }
if ($filterStatus !== '') { $where[] = 'p.payment_status = ?'; $params[] = $filterStatus; }

$wc    = 'WHERE ' . implode(' AND ', $where);
$count = $db->prepare("SELECT COUNT(*) FROM purchases p $wc");
$count->execute($params);
$total = (int)$count->fetchColumn();
$pager = paginate($total, $page, PER_PAGE);

$stmt = $db->prepare(
    "SELECT p.id, p.ref_number, p.purchase_date, p.grand_total, p.payment_status,
            s.name AS supplier_name, u.name AS user_name
     FROM purchases p
     JOIN suppliers s ON s.id=p.supplier_id
     JOIN users u ON u.id=p.user_id
     $wc ORDER BY p.created_at DESC
     LIMIT {$pager['per_page']} OFFSET {$pager['offset']}"
);
$stmt->execute($params);
$purchases = $stmt->fetchAll();

$suppliers = $db->query("SELECT id, name FROM suppliers WHERE is_active=1 ORDER BY name")->fetchAll();

// Grand total for filtered set
$totStmt = $db->prepare("SELECT COALESCE(SUM(grand_total),0) FROM purchases p $wc");
$totStmt->execute($params);
$filteredTotal = (float)$totStmt->fetchColumn();

$qStr = http_build_query(array_filter(['q'=>$search,'supplier'=>$filterSup?:null,'status'=>$filterStatus,'date_from'=>$dateFrom,'date_to'=>$dateTo]));
$baseUrl = '/jeweltrack/modules/purchases/index.php?' . $qStr;
?>

<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div>
    <h1><i class="bi bi-cart-plus text-gold me-2"></i>Purchases</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb"><li class="breadcrumb-item active">Purchase History</li></ol>
    </nav>
  </div>
  <a href="/jeweltrack/modules/purchases/create.php" class="btn btn-gold">
    <i class="bi bi-plus-lg me-1"></i>Record Purchase
  </a>
</div>

<!-- Filters -->
<form method="GET">
  <div class="filter-bar">
    <div style="min-width:140px;">
      <label class="form-label mb-1 fs-13">Ref #</label>
      <input type="text" name="q" class="form-control form-control-sm" placeholder="PO-2026-…" value="<?= e($search) ?>">
    </div>
    <div style="min-width:150px;">
      <label class="form-label mb-1 fs-13">Supplier</label>
      <select name="supplier" class="form-select form-select-sm">
        <option value="">All Suppliers</option>
        <?php foreach ($suppliers as $s): ?>
        <option value="<?= $s['id'] ?>" <?= $filterSup==$s['id']?'selected':'' ?>><?= e($s['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="min-width:120px;">
      <label class="form-label mb-1 fs-13">Status</label>
      <select name="status" class="form-select form-select-sm">
        <option value="">All</option>
        <option value="paid" <?= $filterStatus==='paid'?'selected':'' ?>>Paid</option>
        <option value="partial" <?= $filterStatus==='partial'?'selected':'' ?>>Partial</option>
        <option value="unpaid" <?= $filterStatus==='unpaid'?'selected':'' ?>>Unpaid</option>
      </select>
    </div>
    <div>
      <label class="form-label mb-1 fs-13">From</label>
      <input type="date" name="date_from" class="form-control form-control-sm" value="<?= $dateFrom ?>">
    </div>
    <div>
      <label class="form-label mb-1 fs-13">To</label>
      <input type="date" name="date_to" class="form-control form-control-sm" value="<?= $dateTo ?>">
    </div>
    <div class="d-flex align-items-end gap-2">
      <button type="submit" class="btn btn-emerald btn-sm"><i class="bi bi-search me-1"></i>Filter</button>
      <a href="/jeweltrack/modules/purchases/index.php" class="btn btn-sm btn-outline-secondary">Reset</a>
    </div>
  </div>
</form>

<!-- Summary Card -->
<div class="alert alert-info d-flex align-items-center gap-2 mb-3 fs-13">
  <i class="bi bi-info-circle-fill"></i>
  Showing <strong><?= number_format($total) ?></strong> purchase(s) &mdash;
  Total Amount: <strong><?= formatMoney($filteredTotal, $sym) ?></strong>
</div>

<div class="jt-card">
  <div class="jt-card-header">
    <h2>Purchase Orders <span class="badge bg-secondary ms-1"><?= number_format($total) ?></span></h2>
  </div>
  <div class="table-responsive">
    <?php if ($purchases): ?>
    <table class="jt-table">
      <thead>
        <tr><th>Ref #</th><th>Date</th><th>Supplier</th><th>Grand Total</th><th>Status</th><th>By</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($purchases as $po): ?>
        <tr>
          <td>
            <a href="/jeweltrack/modules/purchases/view.php?id=<?= $po['id'] ?>" class="fw-600 text-emerald">
              <?= e($po['ref_number']) ?>
            </a>
          </td>
          <td class="fs-13"><?= date('d M Y', strtotime($po['purchase_date'])) ?></td>
          <td><?= e($po['supplier_name']) ?></td>
          <td class="fw-600"><?= formatMoney((float)$po['grand_total'], $sym) ?></td>
          <td>
            <span class="badge bg-<?= match($po['payment_status']){ 'paid'=>'success','partial'=>'warning',default=>'secondary' } ?>">
              <?= ucfirst(e($po['payment_status'])) ?>
            </span>
          </td>
          <td class="fs-13 text-muted"><?= e($po['user_name']) ?></td>
          <td>
            <a href="/jeweltrack/modules/purchases/view.php?id=<?= $po['id'] ?>" class="btn btn-sm btn-outline-secondary">
              <i class="bi bi-eye"></i>
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><i class="bi bi-cart d-block"></i><p>No purchases found.</p></div>
    <?php endif; ?>
  </div>
  <?php if ($pager['total_pages'] > 1): ?>
  <div class="jt-card-body border-top d-flex justify-content-between align-items-center">
    <small class="text-muted">Showing <?= $pager['offset']+1 ?>–<?= min($pager['offset']+$pager['per_page'],$total) ?> of <?= $total ?></small>
    <?= renderPagination($pager, $baseUrl) ?>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
