<?php
/**
 * JewelTrack — Create Purchase Order
 * TRANSACTION-SAFE: all DB changes committed or rolled back together.
 * POST/Redirect/GET to prevent double submission.
 */

$pageTitle  = 'Record Purchase';
$activePage = 'purchases';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';

$db        = getDB();
$sym       = currencySymbol();
$suppliers = $db->query("SELECT id, name FROM suppliers WHERE is_active=1 ORDER BY name")->fetchAll();
$taxRateDefault = (float)getSetting('tax_rate', '3');
$formToken = formToken();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    // Prevent double submission
    if (preventDoubleSubmit('purchase')) {
        setFlash('warning', 'This purchase was already recorded. Please create a new one.');
        redirect('/jeweltrack/modules/purchases/index.php');
    }

    // Validate header
    $v = (new Validator($_POST))
          ->required('supplier_id',   'Supplier')
          ->required('purchase_date', 'Purchase Date')
          ->date('purchase_date',     'Purchase Date')
          ->numeric('discount',       'Discount',  0)
          ->numeric('tax_rate',       'Tax Rate',  0, 100);
    $errors = $v->errors();

    // Validate line items
    $items = $_POST['items'] ?? [];
    if (empty($items)) {
        $errors['items'] = 'At least one product line item is required.';
    } else {
        foreach ($items as $idx => $item) {
            $pid = (int)($item['product_id'] ?? 0);
            $qty = (int)($item['quantity']   ?? 0);
            $uc  = (float)($item['unit_cost'] ?? 0);
            if ($pid <= 0) { $errors["item_{$idx}_product"] = "Line " . ($idx+1) . ": Select a product."; }
            if ($qty <= 0) { $errors["item_{$idx}_qty"]     = "Line " . ($idx+1) . ": Quantity must be ≥ 1."; }
            if ($uc  < 0)  { $errors["item_{$idx}_cost"]    = "Line " . ($idx+1) . ": Cost cannot be negative."; }
        }
    }

    if (empty($errors)) {
        $db->beginTransaction();
        try {
            $supplierId  = (int)$_POST['supplier_id'];
            $date        = $_POST['purchase_date'];
            $discount    = (float)$_POST['discount'];
            $taxRate     = (float)$_POST['tax_rate'];
            $notes       = trim($_POST['notes'] ?? '');

            // Compute totals server-side
            $subtotal = 0;
            foreach ($items as $item) {
                $subtotal += (int)$item['quantity'] * (float)$item['unit_cost'];
            }
            $taxable   = max(0, $subtotal - $discount);
            $taxAmount = round($taxable * $taxRate / 100, 2);
            $grandTotal = $taxable + $taxAmount;

            $refNumber = generatePurchaseRef();

            // Insert purchase header
            $db->prepare(
                "INSERT INTO purchases
                   (ref_number, supplier_id, purchase_date, subtotal, discount, tax_rate, tax_amount, grand_total, payment_status, notes, user_id)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)"
            )->execute([
                $refNumber, $supplierId, $date, $subtotal, $discount, $taxRate,
                $taxAmount, $grandTotal, $_POST['payment_status'], $notes, $_SESSION['user_id']
            ]);
            $purchaseId = (int)$db->lastInsertId();

            // Insert line items, update stock, record movements
            foreach ($items as $item) {
                $pid     = (int)$item['product_id'];
                $qty     = (int)$item['quantity'];
                $uc      = (float)$item['unit_cost'];
                $lineTot = $qty * $uc;

                // Lock product
                $prodStmt = $db->prepare("SELECT id, name, quantity FROM products WHERE id=? AND is_active=1 FOR UPDATE");
                $prodStmt->execute([$pid]);
                $prod = $prodStmt->fetch();
                if (!$prod) throw new RuntimeException("Product ID $pid not found.");

                $qtyBefore = (int)$prod['quantity'];
                $qtyAfter  = $qtyBefore + $qty;

                // Insert purchase item
                $db->prepare(
                    "INSERT INTO purchase_items (purchase_id, product_id, quantity, unit_cost, line_total)
                     VALUES (?,?,?,?,?)"
                )->execute([$purchaseId, $pid, $qty, $uc, $lineTot]);

                // Update product stock
                $db->prepare("UPDATE products SET quantity=?, purchase_cost=? WHERE id=?")
                   ->execute([$qtyAfter, $uc, $pid]);

                // Record stock movement
                $db->prepare(
                    "INSERT INTO stock_movements
                       (product_id, movement_type, quantity, qty_before, qty_after, reference_id, reference_type, notes, user_id)
                     VALUES (?, 'purchase_received', ?, ?, ?, ?, 'purchase', ?, ?)"
                )->execute([$pid, $qty, $qtyBefore, $qtyAfter, $purchaseId, $refNumber, $_SESSION['user_id']]);
            }

            $db->commit();
            logActivity('purchase_created', 'purchases', $purchaseId, "Purchase $refNumber recorded");
            setFlash('success', "Purchase $refNumber recorded. Stock has been updated.");
            redirect('/jeweltrack/modules/purchases/view.php?id=' . $purchaseId);

        } catch (Throwable $e) {
            $db->rollBack();
            $errors['db'] = 'Transaction failed: ' . $e->getMessage();
        }
    }
}
?>

<div class="page-header">
  <h1><i class="bi bi-cart-plus text-gold me-2"></i>Record New Purchase</h1>
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/jeweltrack/modules/purchases/index.php">Purchases</a></li>
      <li class="breadcrumb-item active">New</li>
    </ol>
  </nav>
</div>

<?php if ($errors): ?>
<div class="alert alert-danger">
  <i class="bi bi-x-circle-fill me-2"></i><strong>Please fix errors:</strong>
  <ul class="mb-0 mt-1"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<form method="POST" novalidate>
  <?= csrfField() ?>
  <input type="hidden" name="form_token" value="<?= e($formToken) ?>">

  <div class="row g-4">
    <!-- Header -->
    <div class="col-lg-8">
      <div class="jt-card mb-3">
        <div class="jt-card-header"><h2>Purchase Details</h2></div>
        <div class="jt-card-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label for="supplier_id" class="form-label">Supplier <span class="text-danger">*</span></label>
              <select id="supplier_id" name="supplier_id" class="form-select" required>
                <option value="">— Select Supplier —</option>
                <?php foreach ($suppliers as $s): ?>
                <option value="<?= $s['id'] ?>" <?= ($_POST['supplier_id'] ?? '')==$s['id']?'selected':'' ?>>
                  <?= e($s['name']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-3">
              <label for="purchase_date" class="form-label">Date <span class="text-danger">*</span></label>
              <input type="date" id="purchase_date" name="purchase_date" class="form-control"
                     value="<?= e($_POST['purchase_date'] ?? date('Y-m-d')) ?>" required>
            </div>
            <div class="col-md-3">
              <label for="payment_status" class="form-label">Payment Status</label>
              <select id="payment_status" name="payment_status" class="form-select">
                <option value="unpaid"  <?= ($_POST['payment_status']??'') ==='unpaid' ?'selected':'' ?>>Unpaid</option>
                <option value="partial" <?= ($_POST['payment_status']??'') ==='partial'?'selected':'' ?>>Partial</option>
                <option value="paid"    <?= ($_POST['payment_status']??'paid')==='paid' ?'selected':'' ?>>Paid</option>
              </select>
            </div>
            <div class="col-12">
              <label for="notes" class="form-label">Notes</label>
              <textarea id="notes" name="notes" class="form-control" rows="2"><?= e($_POST['notes'] ?? '') ?></textarea>
            </div>
          </div>
        </div>
      </div>

      <!-- Line Items -->
      <div class="jt-card">
        <div class="jt-card-header">
          <h2>Product Line Items</h2>
          <button type="button" class="btn btn-sm btn-emerald"
                  onclick="JT.addLineItem(document.getElementById('lineItems'),'purchase')">
            <i class="bi bi-plus-lg me-1"></i>Add Product
          </button>
        </div>
        <div class="jt-card-body">
          <div id="lineItems"></div>
          <p id="noItemsMsg" class="text-muted fs-13 text-center py-3">
            Click "Add Product" to add items to this purchase.
          </p>
        </div>
      </div>
    </div>

    <!-- Summary -->
    <div class="col-lg-4">
      <div class="jt-card position-sticky" style="top:80px;">
        <div class="jt-card-header"><h2>Purchase Summary</h2></div>
        <div class="jt-card-body">
          <div class="d-flex justify-content-between mb-2">
            <span class="text-muted">Subtotal</span>
            <span class="fw-600" id="preview_subtotal">₹ 0.00</span>
          </div>
          <div class="mb-2">
            <label for="discount" class="form-label fs-13">Discount (<?= $sym ?>)</label>
            <input type="number" id="discount" name="discount" class="form-control form-control-sm"
                   step="0.01" min="0" value="<?= e($_POST['discount'] ?? '0') ?>">
          </div>
          <div class="mb-3">
            <label for="tax_rate" class="form-label fs-13"><?= e(getSetting('tax_label','GST')) ?> Rate (%)</label>
            <input type="number" id="tax_rate" name="tax_rate" class="form-control form-control-sm"
                   step="0.01" min="0" max="100" value="<?= e($_POST['tax_rate'] ?? $taxRateDefault) ?>">
          </div>
          <div class="d-flex justify-content-between mb-1">
            <span class="text-muted fs-13">Tax Amount</span>
            <span id="preview_tax">₹ 0.00</span>
          </div>
          <hr>
          <div class="d-flex justify-content-between mb-3">
            <span class="fw-700">Grand Total</span>
            <span class="fw-700 fs-5 text-emerald" id="preview_grand">₹ 0.00</span>
          </div>
          <div class="alert alert-warning fs-13 mb-3">
            <i class="bi bi-info-circle me-1"></i>
            Server recalculates all totals on submit. Preview is approximate.
          </div>
          <div class="d-grid gap-2">
            <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg me-1"></i>Save Purchase &amp; Update Stock</button>
            <a href="/jeweltrack/modules/purchases/index.php" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>

<script>
// Add first row automatically
document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('lineItems');
  JT.addLineItem(container, 'purchase');
  document.getElementById('noItemsMsg')?.remove();
  // Observe to hide/show placeholder
  const obs = new MutationObserver(() => {
    const msg = document.getElementById('noItemsMsg');
    if (msg) msg.style.display = container.children.length > 0 ? 'none' : 'block';
  });
  obs.observe(container, { childList: true });
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
