<?php
/**
 * JewelTrack — View Purchase Order
 */

$pageTitle  = 'Purchase Details';
$activePage = 'purchases';
require_once __DIR__ . '/../../includes/header.php';

$db  = getDB();
$sym = currencySymbol();
$id  = (int)($_GET['id'] ?? 0);
if (!$id) redirect('/jeweltrack/modules/purchases/index.php');

$po = $db->prepare(
    "SELECT p.*, s.name AS supplier_name, s.phone AS supplier_phone,
            u.name AS user_name
     FROM purchases p
     JOIN suppliers s ON s.id=p.supplier_id
     JOIN users u ON u.id=p.user_id
     WHERE p.id=?"
);
$po->execute([$id]);
$purchase = $po->fetch();
if (!$purchase) { setFlash('error','Purchase not found.'); redirect('/jeweltrack/modules/purchases/index.php'); }

$items = $db->prepare(
    "SELECT pi.*, pr.name AS product_name, pr.sku
     FROM purchase_items pi
     JOIN products pr ON pr.id=pi.product_id
     WHERE pi.purchase_id=?"
);
$items->execute([$id]);
$lineItems = $items->fetchAll();
?>

<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div>
    <h1><i class="bi bi-receipt text-gold me-2"></i><?= e($purchase['ref_number']) ?></h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/jeweltrack/modules/purchases/index.php">Purchases</a></li>
        <li class="breadcrumb-item active"><?= e($purchase['ref_number']) ?></li>
      </ol>
    </nav>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-8">
    <!-- Items -->
    <div class="jt-card mb-3">
      <div class="jt-card-header"><h2>Line Items</h2></div>
      <div class="table-responsive">
        <table class="jt-table">
          <thead>
            <tr><th>#</th><th>SKU</th><th>Product</th><th>Qty</th><th>Unit Cost</th><th>Line Total</th></tr>
          </thead>
          <tbody>
            <?php foreach ($lineItems as $i => $li): ?>
            <tr>
              <td class="text-muted"><?= $i+1 ?></td>
              <td><code class="fs-13"><?= e($li['sku']) ?></code></td>
              <td><a href="/jeweltrack/modules/products/view.php?id=<?= $li['product_id'] ?>"
                     class="fw-600 text-emerald"><?= e($li['product_name']) ?></a></td>
              <td><?= (int)$li['quantity'] ?></td>
              <td><?= formatMoney((float)$li['unit_cost'], $sym) ?></td>
              <td class="fw-600"><?= formatMoney((float)$li['line_total'], $sym) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <!-- Header Info -->
    <div class="jt-card mb-3">
      <div class="jt-card-header"><h2>Purchase Info</h2></div>
      <div class="jt-card-body">
        <?php
        $fields = [
          'Ref #'            => $purchase['ref_number'],
          'Date'             => date('d M Y', strtotime($purchase['purchase_date'])),
          'Supplier'         => $purchase['supplier_name'],
          'Phone'            => $purchase['supplier_phone'] ?: '—',
          'Recorded By'      => $purchase['user_name'],
          'Payment Status'   => ucfirst($purchase['payment_status']),
        ];
        foreach ($fields as $label => $val): ?>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted fs-13"><?= $label ?></span>
          <span class="fw-600 text-end"><?= e($val) ?></span>
        </div>
        <?php endforeach; ?>
        <?php if ($purchase['notes']): ?>
        <div class="mt-2 text-muted fs-13"><?= nl2br(e($purchase['notes'])) ?></div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Totals -->
    <div class="jt-card">
      <div class="jt-card-header"><h2>Totals</h2></div>
      <div class="jt-card-body">
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted">Subtotal</span>
          <span><?= formatMoney((float)$purchase['subtotal'], $sym) ?></span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted">Discount</span>
          <span>- <?= formatMoney((float)$purchase['discount'], $sym) ?></span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted">Tax (<?= number_format((float)$purchase['tax_rate'],1) ?>%)</span>
          <span><?= formatMoney((float)$purchase['tax_amount'], $sym) ?></span>
        </div>
        <div class="d-flex justify-content-between py-2">
          <span class="fw-700">Grand Total</span>
          <span class="fw-700 fs-5 text-emerald"><?= formatMoney((float)$purchase['grand_total'], $sym) ?></span>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
