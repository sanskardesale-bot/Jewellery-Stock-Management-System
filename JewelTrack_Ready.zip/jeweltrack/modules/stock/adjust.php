<?php
/**
 * JewelTrack — Manual Stock Adjustment
 * Creates a stock_movements record of type 'manual_correction'.
 * This is the ONLY way to change quantity outside of purchases/sales.
 */

$pageTitle  = 'Manual Stock Adjustment';
$activePage = 'stock';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';
requireAdmin();

$db         = getDB();
$preProduct = (int)($_GET['product_id'] ?? 0);
$products   = $db->query("SELECT id, sku, name, quantity FROM products WHERE is_active=1 ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $v = (new Validator($_POST))
          ->required('product_id', 'Product')
          ->required('new_quantity','New Quantity')
          ->required('notes',       'Reason / Notes')
          ->integer('new_quantity', 'New Quantity', 0)
          ->maxLength('notes', 500, 'Reason');

    if (!$v->passes()) {
        setFlash('error', $v->firstError());
    } else {
        $productId   = (int)$_POST['product_id'];
        $newQty      = (int)$_POST['new_quantity'];

        // Lock product row
        $db->beginTransaction();
        try {
            $prod = $db->prepare("SELECT id, name, quantity FROM products WHERE id=? FOR UPDATE");
            $prod->execute([$productId]);
            $p = $prod->fetch();

            if (!$p) throw new RuntimeException('Product not found.');

            $oldQty  = (int)$p['quantity'];
            $change  = $newQty - $oldQty;

            // Record movement
            $db->prepare(
                "INSERT INTO stock_movements
                   (product_id, movement_type, quantity, qty_before, qty_after, notes, user_id)
                 VALUES (?, 'manual_correction', ?, ?, ?, ?, ?)"
            )->execute([$productId, $change, $oldQty, $newQty, trim($_POST['notes']), $_SESSION['user_id']]);

            // Update product quantity
            $db->prepare("UPDATE products SET quantity=? WHERE id=?")
               ->execute([$newQty, $productId]);

            $db->commit();

            logActivity('stock_adjusted', 'products', $productId,
                "Manual adj: {$p['name']} from $oldQty to $newQty");
            setFlash('success', "Stock for '{$p['name']}' adjusted from {$oldQty} to {$newQty} pieces.");
            redirect('/jeweltrack/modules/stock/index.php');

        } catch (Throwable $e) {
            $db->rollBack();
            setFlash('error', 'Adjustment failed: ' . $e->getMessage());
        }
    }
}
?>

<div class="page-header">
  <h1><i class="bi bi-sliders text-gold me-2"></i>Manual Stock Adjustment</h1>
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/jeweltrack/modules/stock/index.php">Stock Movements</a></li>
      <li class="breadcrumb-item active">Adjust</li>
    </ol>
  </nav>
</div>

<div class="row justify-content-center">
  <div class="col-lg-6">
    <div class="jt-card">
      <div class="jt-card-header"><h2>Adjust Stock Quantity</h2></div>
      <div class="jt-card-body">

        <div class="alert alert-warning fs-13 mb-4">
          <i class="bi bi-exclamation-triangle-fill me-1"></i>
          <strong>Important:</strong> This creates a permanent stock movement record. All adjustments are logged.
          Use only for physical count corrections, damaged goods, etc.
        </div>

        <form method="POST" novalidate>
          <?= csrfField() ?>

          <div class="mb-3">
            <label for="product_id" class="form-label">Product <span class="text-danger">*</span></label>
            <select id="product_id" name="product_id" class="form-select" required onchange="showCurrentStock(this)">
              <option value="">— Select Product —</option>
              <?php foreach ($products as $pr): ?>
              <option value="<?= $pr['id'] ?>"
                      data-qty="<?= (int)$pr['quantity'] ?>"
                      <?= $preProduct == $pr['id'] ? 'selected' : '' ?>>
                <?= e($pr['name']) ?> (<?= e($pr['sku']) ?>) — <?= (int)$pr['quantity'] ?> pcs
              </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3" id="currentQtyRow" style="display:none;">
            <div class="p-3 rounded" style="background:var(--clr-ivory);border:1px solid var(--clr-border);">
              <span class="text-muted fs-13">Current Stock: </span>
              <strong id="currentQtyDisplay">—</strong> pieces
            </div>
          </div>

          <div class="mb-3">
            <label for="new_quantity" class="form-label">New Quantity (pieces) <span class="text-danger">*</span></label>
            <input type="number" id="new_quantity" name="new_quantity" class="form-control"
                   min="0" required placeholder="Enter the corrected stock count">
            <small class="text-muted">Enter the actual physical count. The system will calculate the difference automatically.</small>
          </div>

          <div class="mb-4">
            <label for="notes" class="form-label">Reason / Notes <span class="text-danger">*</span></label>
            <textarea id="notes" name="notes" class="form-control" rows="3" required
                      placeholder="e.g. Physical stock count correction, damaged goods written off…"></textarea>
          </div>

          <div class="d-grid gap-2">
            <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg me-1"></i>Record Adjustment</button>
            <a href="/jeweltrack/modules/stock/index.php" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<script>
function showCurrentStock(sel) {
  const opt = sel.options[sel.selectedIndex];
  const row = document.getElementById('currentQtyRow');
  const disp = document.getElementById('currentQtyDisplay');
  if (opt.value) {
    disp.textContent = opt.dataset.qty + ' pcs';
    row.style.display = 'block';
    document.getElementById('new_quantity').value = opt.dataset.qty;
  } else {
    row.style.display = 'none';
  }
}
// Show current stock if pre-selected
document.addEventListener('DOMContentLoaded', () => {
  const sel = document.getElementById('product_id');
  if (sel.value) showCurrentStock(sel);
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
