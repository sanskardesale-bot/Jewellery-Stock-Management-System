<?php
/**
 * JewelTrack — Stock Movements Ledger
 */

$pageTitle  = 'Stock Movements';
$activePage = 'stock';
require_once __DIR__ . '/../../includes/header.php';

$db = getDB();

// ── Filters ─────────────────────────────────────────────────────────────────
$filterProduct = (int)($_GET['product_id'] ?? 0);
$filterType    = trim($_GET['type']        ?? '');
$filterUser    = (int)($_GET['user_id']    ?? 0);
$dateFrom      = $_GET['date_from'] ?? date('Y-m-01');
$dateTo        = $_GET['date_to']   ?? date('Y-m-d');
$page          = max(1, (int)($_GET['page'] ?? 1));

$where  = ['sm.created_at BETWEEN ? AND ?'];
$params = [$dateFrom . ' 00:00:00', $dateTo . ' 23:59:59'];

if ($filterProduct > 0) { $where[] = 'sm.product_id = ?'; $params[] = $filterProduct; }
if ($filterType !== '')  { $where[] = 'sm.movement_type = ?'; $params[] = $filterType; }
if ($filterUser  > 0)   { $where[] = 'sm.user_id = ?'; $params[] = $filterUser; }

$whereClause = 'WHERE ' . implode(' AND ', $where);

$countStmt = $db->prepare("SELECT COUNT(*) FROM stock_movements sm $whereClause");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();

$pager = paginate($total, $page, PER_PAGE);

$stmt = $db->prepare(
    "SELECT sm.*, p.name AS product_name, p.sku, u.name AS user_name
     FROM stock_movements sm
     JOIN products p ON p.id=sm.product_id
     JOIN users u ON u.id=sm.user_id
     $whereClause
     ORDER BY sm.created_at DESC
     LIMIT {$pager['per_page']} OFFSET {$pager['offset']}"
);
$stmt->execute($params);
$movements = $stmt->fetchAll();

$products = $db->query("SELECT id, name, sku FROM products ORDER BY name")->fetchAll();
$users    = $db->query("SELECT id, name FROM users ORDER BY name")->fetchAll();

$movTypes = ['opening_stock','purchase_received','sale_dispatched','customer_return','supplier_return','manual_correction'];

$qStr    = http_build_query(array_filter(['product_id'=>$filterProduct?:null,'type'=>$filterType,'user_id'=>$filterUser?:null,'date_from'=>$dateFrom,'date_to'=>$dateTo]));
$baseUrl = '/jeweltrack/modules/stock/index.php?' . $qStr;
?>

<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div>
    <h1><i class="bi bi-arrow-left-right text-gold me-2"></i>Stock Movements</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb"><li class="breadcrumb-item active">Stock Ledger</li></ol>
    </nav>
  </div>
  <?php if (isAdmin()): ?>
  <a href="/jeweltrack/modules/stock/adjust.php" class="btn btn-gold btn-sm">
    <i class="bi bi-sliders me-1"></i>Manual Adjustment
  </a>
  <?php endif; ?>
</div>

<!-- Filters -->
<form method="GET">
  <div class="filter-bar">
    <div style="min-width:160px;">
      <label class="form-label mb-1 fs-13">Product</label>
      <select name="product_id" class="form-select form-select-sm">
        <option value="">All Products</option>
        <?php foreach ($products as $pr): ?>
        <option value="<?= $pr['id'] ?>" <?= $filterProduct==$pr['id']?'selected':'' ?>>
          <?= e($pr['name']) ?> (<?= e($pr['sku']) ?>)
        </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="min-width:150px;">
      <label class="form-label mb-1 fs-13">Type</label>
      <select name="type" class="form-select form-select-sm">
        <option value="">All Types</option>
        <?php foreach ($movTypes as $mt): ?>
        <option value="<?= $mt ?>" <?= $filterType===$mt?'selected':'' ?>>
          <?= ucwords(str_replace('_',' ',$mt)) ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label class="form-label mb-1 fs-13">From</label>
      <input type="date" name="date_from" class="form-control form-control-sm" value="<?= $dateFrom ?>">
    </div>
    <div>
      <label class="form-label mb-1 fs-13">To</label>
      <input type="date" name="date_to" class="form-control form-control-sm" value="<?= $dateTo ?>">
    </div>
    <div class="d-flex align-items-end gap-2">
      <button type="submit" class="btn btn-emerald btn-sm"><i class="bi bi-search me-1"></i>Filter</button>
      <a href="/jeweltrack/modules/stock/index.php" class="btn btn-sm btn-outline-secondary">Reset</a>
    </div>
  </div>
</form>

<div class="jt-card">
  <div class="jt-card-header">
    <h2>Ledger Entries <span class="badge bg-secondary ms-1"><?= number_format($total) ?></span></h2>
  </div>
  <div class="table-responsive">
    <?php if ($movements): ?>
    <table class="jt-table">
      <thead>
        <tr>
          <th>Date &amp; Time</th>
          <th>Product</th>
          <th>Type</th>
          <th>Qty Change</th>
          <th>Before</th>
          <th>After</th>
          <th>Reference</th>
          <th>User</th>
          <th>Notes</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($movements as $m):
          $typeMap = [
            'opening_stock'     => ['Opening Stock',   'secondary'],
            'purchase_received' => ['Purchase In',     'success'],
            'sale_dispatched'   => ['Sale Out',        'danger'],
            'customer_return'   => ['Customer Return', 'info'],
            'supplier_return'   => ['Supplier Return', 'warning'],
            'manual_correction' => ['Manual Adj.',     'primary'],
          ];
          [$typeLabel, $typeBadge] = $typeMap[$m['movement_type']] ?? [$m['movement_type'], 'secondary'];
        ?>
        <tr>
          <td class="text-muted fs-13 text-nowrap"><?= date('d M Y H:i', strtotime($m['created_at'])) ?></td>
          <td>
            <a href="/jeweltrack/modules/products/view.php?id=<?= $m['product_id'] ?>" class="fw-600 text-emerald">
              <?= e($m['product_name']) ?>
            </a>
            <div class="text-muted fs-13"><code><?= e($m['sku']) ?></code></div>
          </td>
          <td><span class="badge bg-<?= $typeBadge ?>"><?= $typeLabel ?></span></td>
          <td>
            <span class="fw-700 <?= $m['quantity'] > 0 ? 'text-success' : 'text-danger' ?>">
              <?= $m['quantity'] > 0 ? '+' : '' ?><?= (int)$m['quantity'] ?>
            </span>
          </td>
          <td class="text-muted"><?= (int)$m['qty_before'] ?></td>
          <td class="fw-600"><?= (int)$m['qty_after'] ?></td>
          <td class="fs-13 text-muted"><?= e($m['reference_type'] ? ucfirst($m['reference_type']) . ' #' . $m['reference_id'] : '—') ?></td>
          <td class="fs-13"><?= e($m['user_name']) ?></td>
          <td class="fs-13 text-muted"><?= e($m['notes'] ?: '—') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><i class="bi bi-arrow-left-right d-block"></i><p>No movements found for the selected filters.</p></div>
    <?php endif; ?>
  </div>
  <?php if ($pager['total_pages'] > 1): ?>
  <div class="jt-card-body border-top d-flex justify-content-between align-items-center">
    <small class="text-muted">Showing <?= $pager['offset']+1 ?>–<?= min($pager['offset']+$pager['per_page'],$total) ?> of <?= $total ?></small>
    <?= renderPagination($pager, $baseUrl) ?>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
