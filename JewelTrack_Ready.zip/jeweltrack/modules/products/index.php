<?php
/**
 * JewelTrack — Jewellery Inventory List
 */

$pageTitle  = 'Jewellery Inventory';
$activePage = 'products';
require_once __DIR__ . '/../../includes/header.php';

$db  = getDB();
$sym = currencySymbol();

// ── Filters ─────────────────────────────────────────────────────────────────
$search      = trim($_GET['q']           ?? '');
$filterCat   = (int)($_GET['category']   ?? 0);
$filterMetal = trim($_GET['metal']       ?? '');
$filterStock = trim($_GET['filter']      ?? '');
$page        = max(1, (int)($_GET['page'] ?? 1));

$where  = ['p.is_active = 1'];
$params = [];

if ($search !== '') {
    $where[]  = '(p.name LIKE ? OR p.sku LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($filterCat > 0) {
    $where[]  = 'p.category_id = ?';
    $params[] = $filterCat;
}
if ($filterMetal !== '') {
    $where[]  = 'p.metal_type = ?';
    $params[] = $filterMetal;
}
if ($filterStock === 'low_stock') {
    $where[] = 'p.quantity <= p.reorder_level AND p.quantity > 0';
} elseif ($filterStock === 'out_of_stock') {
    $where[] = 'p.quantity = 0';
} elseif ($filterStock === 'in_stock') {
    $where[] = 'p.quantity > p.reorder_level';
}
// Also show inactive if admin explicitly requests
if (isset($_GET['show_inactive']) && isAdmin()) {
    array_shift($where); // remove is_active=1
}

$whereClause = 'WHERE ' . implode(' AND ', $where);

// Count
$countStmt = $db->prepare("SELECT COUNT(*) FROM products p $whereClause");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();

$pager = paginate($total, $page, PER_PAGE);

// Fetch
$sort      = in_array($_GET['sort'] ?? '', ['name','sku','quantity','selling_price','purchase_cost']) ? $_GET['sort'] : 'p.name';
$sortOrder = ($_GET['order'] ?? '') === 'desc' ? 'DESC' : 'ASC';
if (!str_contains($sort, '.')) $sort = 'p.' . $sort;

$stmt = $db->prepare(
    "SELECT p.id, p.sku, p.name, p.metal_type, p.purity, p.quantity, p.reorder_level,
            p.purchase_cost, p.selling_price, p.image, p.is_active,
            c.name AS category
     FROM products p
     JOIN categories c ON c.id = p.category_id
     $whereClause
     ORDER BY $sort $sortOrder
     LIMIT {$pager['per_page']} OFFSET {$pager['offset']}"
);
$stmt->execute($params);
$products = $stmt->fetchAll();

// Categories for filter
$categories = $db->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();

// Build base URL for pagination
$qStr = http_build_query(array_filter([
    'q'        => $search,
    'category' => $filterCat ?: null,
    'metal'    => $filterMetal,
    'filter'   => $filterStock,
    'sort'     => $_GET['sort'] ?? null,
    'order'    => $_GET['order'] ?? null,
]));
$baseUrl = '/jeweltrack/modules/products/index.php?' . $qStr;
?>

<!-- Page Header -->
<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div>
    <h1><i class="bi bi-grid-3x3-gap text-gold me-2"></i>Jewellery Inventory</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb"><li class="breadcrumb-item active">Inventory</li></ol>
    </nav>
  </div>
  <?php if (isAdmin()): ?>
  <a href="/jeweltrack/modules/products/create.php" class="btn btn-gold">
    <i class="bi bi-plus-lg me-1"></i>Add Product
  </a>
  <?php endif; ?>
</div>

<!-- Filter Bar -->
<form method="GET" action="/jeweltrack/modules/products/index.php">
  <div class="filter-bar">
    <div class="flex-fill" style="min-width:180px;">
      <label class="form-label mb-1 fs-13">Search</label>
      <input type="text" name="q" class="form-control form-control-sm"
             placeholder="Name or SKU…" value="<?= e($search) ?>">
    </div>
    <div style="min-width:140px;">
      <label class="form-label mb-1 fs-13">Category</label>
      <select name="category" class="form-select form-select-sm">
        <option value="">All Categories</option>
        <?php foreach ($categories as $cat): ?>
          <option value="<?= $cat['id'] ?>" <?= $filterCat == $cat['id'] ? 'selected' : '' ?>>
            <?= e($cat['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="min-width:120px;">
      <label class="form-label mb-1 fs-13">Metal</label>
      <select name="metal" class="form-select form-select-sm">
        <option value="">All Metals</option>
        <?php foreach (['Gold','Silver','Platinum','Rhodium','Other'] as $m): ?>
          <option value="<?= $m ?>" <?= $filterMetal === $m ? 'selected' : '' ?>><?= $m ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="min-width:130px;">
      <label class="form-label mb-1 fs-13">Stock Status</label>
      <select name="filter" class="form-select form-select-sm">
        <option value="">All Stock</option>
        <option value="in_stock"    <?= $filterStock==='in_stock'    ? 'selected':'' ?>>In Stock</option>
        <option value="low_stock"   <?= $filterStock==='low_stock'   ? 'selected':'' ?>>Low Stock</option>
        <option value="out_of_stock"<?= $filterStock==='out_of_stock'? 'selected':'' ?>>Out of Stock</option>
      </select>
    </div>
    <div class="d-flex align-items-end gap-2">
      <button type="submit" class="btn btn-emerald btn-sm"><i class="bi bi-search me-1"></i>Filter</button>
      <a href="/jeweltrack/modules/products/index.php" class="btn btn-sm btn-outline-secondary">Reset</a>
    </div>
  </div>
</form>

<!-- Table -->
<div class="jt-card">
  <div class="jt-card-header">
    <h2>
      Products
      <span class="badge bg-secondary ms-1"><?= number_format($total) ?></span>
    </h2>
    <div class="d-flex gap-2">
      <a href="/jeweltrack/modules/reports/index.php?report=inventory" class="btn btn-sm btn-outline-secondary">
        <i class="bi bi-download me-1"></i>Export CSV
      </a>
    </div>
  </div>
  <div class="table-responsive">
    <?php if ($products): ?>
    <table class="jt-table">
      <thead>
        <tr>
          <th>#</th>
          <th>
            <a href="?q=<?=urlencode($search)?>&sort=sku&order=<?=$sortOrder==='ASC'?'desc':'asc'?>" class="text-muted text-decoration-none">
              SKU <i class="bi bi-chevron-expand fs-13"></i>
            </a>
          </th>
          <th>Image</th>
          <th>
            <a href="?q=<?=urlencode($search)?>&sort=name&order=<?=$sortOrder==='ASC'?'desc':'asc'?>" class="text-muted text-decoration-none">
              Product Name <i class="bi bi-chevron-expand fs-13"></i>
            </a>
          </th>
          <th>Category</th>
          <th>Metal / Purity</th>
          <th>
            <a href="?q=<?=urlencode($search)?>&sort=quantity&order=<?=$sortOrder==='ASC'?'desc':'asc'?>" class="text-muted text-decoration-none">
              Stock <i class="bi bi-chevron-expand fs-13"></i>
            </a>
          </th>
          <th>
            <a href="?q=<?=urlencode($search)?>&sort=purchase_cost&order=<?=$sortOrder==='ASC'?'desc':'asc'?>" class="text-muted text-decoration-none">
              Cost <i class="bi bi-chevron-expand fs-13"></i>
            </a>
          </th>
          <th>
            <a href="?q=<?=urlencode($search)?>&sort=selling_price&order=<?=$sortOrder==='ASC'?'desc':'asc'?>" class="text-muted text-decoration-none">
              Sale Price <i class="bi bi-chevron-expand fs-13"></i>
            </a>
          </th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($products as $i => $p): ?>
        <tr>
          <td class="text-muted fs-13"><?= $pager['offset'] + $i + 1 ?></td>
          <td><code class="fs-13"><?= e($p['sku']) ?></code></td>
          <td>
            <?php if ($p['image']): ?>
              <img src="/jeweltrack/assets/uploads/products/<?= e($p['image']) ?>"
                   alt="<?= e($p['name']) ?>" class="product-img-thumb">
            <?php else: ?>
              <div class="product-img-placeholder"><i class="bi bi-gem"></i></div>
            <?php endif; ?>
          </td>
          <td>
            <a href="/jeweltrack/modules/products/view.php?id=<?= $p['id'] ?>" class="fw-600 text-emerald">
              <?= e($p['name']) ?>
            </a>
          </td>
          <td class="fs-13"><?= e($p['category']) ?></td>
          <td class="fs-13"><?= e($p['metal_type']) ?> <?= $p['purity'] ? '/ ' . e($p['purity']) : '' ?></td>
          <td>
            <span class="fw-700 <?= $p['quantity'] == 0 ? 'text-danger' : ($p['quantity'] <= $p['reorder_level'] ? 'text-warning' : '') ?>">
              <?= (int)$p['quantity'] ?>
            </span>
          </td>
          <td class="fs-13"><?= formatMoney((float)$p['purchase_cost'], $sym) ?></td>
          <td class="fw-600"><?= formatMoney((float)$p['selling_price'], $sym) ?></td>
          <td><?= stockBadge((int)$p['quantity'], (int)$p['reorder_level']) ?></td>
          <td>
            <div class="d-flex gap-1">
              <a href="/jeweltrack/modules/products/view.php?id=<?= $p['id'] ?>"
                 class="btn btn-sm btn-outline-secondary" title="View"><i class="bi bi-eye"></i></a>
              <?php if (isAdmin()): ?>
              <a href="/jeweltrack/modules/products/edit.php?id=<?= $p['id'] ?>"
                 class="btn btn-sm btn-outline-gold" title="Edit"><i class="bi bi-pencil"></i></a>
              <a href="/jeweltrack/modules/products/delete.php?id=<?= $p['id'] ?>"
                 class="btn btn-sm btn-outline-danger" title="Deactivate"
                 data-confirm="Deactivate product '<?= e(addslashes($p['name'])) ?>'? It will be hidden from inventory.">
                <i class="bi bi-slash-circle"></i>
              </a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state">
      <i class="bi bi-gem d-block"></i>
      <p>No products found. <?php if(isAdmin()): ?><a href="/jeweltrack/modules/products/create.php">Add your first product</a>.<?php endif; ?></p>
    </div>
    <?php endif; ?>
  </div>

  <!-- Pagination -->
  <?php if ($pager['total_pages'] > 1): ?>
  <div class="jt-card-body border-top d-flex justify-content-between align-items-center">
    <small class="text-muted">
      Showing <?= $pager['offset'] + 1 ?>–<?= min($pager['offset'] + $pager['per_page'], $total) ?> of <?= $total ?> products
    </small>
    <?= renderPagination($pager, $baseUrl) ?>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
