<?php
/**
 * JewelTrack — Deactivate (soft-delete) Product
 */

require_once __DIR__ . '/../../config/app.php';
requireAdmin();
verifyCsrf();

$db = getDB();
$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect('/jeweltrack/modules/products/index.php');

$stmt = $db->prepare("SELECT name FROM products WHERE id=?");
$stmt->execute([$id]);
$p = $stmt->fetch();
if (!$p) { setFlash('error','Product not found.'); redirect('/jeweltrack/modules/products/index.php'); }

$db->prepare("UPDATE products SET is_active=0 WHERE id=?")->execute([$id]);
logActivity('product_deactivated', 'products', $id, "Product '{$p['name']}' deactivated");
setFlash('success', "Product '{$p['name']}' has been deactivated.");
redirect('/jeweltrack/modules/products/index.php');
