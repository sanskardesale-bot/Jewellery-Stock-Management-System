<?php
/**
 * JewelTrack — Add New Product
 */

$pageTitle  = 'Add Product';
$activePage = 'products';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';
requireAdmin();

$db         = getDB();
$categories = $db->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();
$errors     = [];
$old        = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $v = new Validator($_POST);
    $v->required('sku',         'SKU')
      ->required('name',        'Product Name')
      ->required('category_id', 'Category')
      ->required('metal_type',  'Metal Type')
      ->required('purchase_cost','Purchase Cost')
      ->required('selling_price','Selling Price')
      ->numeric('purchase_cost','Purchase Cost', 0)
      ->numeric('selling_price','Selling Price', 0)
      ->numeric('gross_weight_g','Gross Weight',  0)
      ->numeric('net_weight_g',  'Net Weight',    0)
      ->integer('reorder_level', 'Reorder Level', 0)
      ->unique('sku', 'SKU', 'products', 'sku')
      ->inList('metal_type','Metal Type',['Gold','Silver','Platinum','Rhodium','Other']);

    $errors = $v->errors();
    $old    = $_POST;

    // Image upload
    $imageFilename = null;
    if (!empty($_FILES['image']['name'])) {
        $uploadResult = uploadProductImage($_FILES['image']);
        if (!$uploadResult['success']) {
            $errors['image'] = $uploadResult['message'];
        } else {
            $imageFilename = $uploadResult['filename'];
        }
    }

    if (empty($errors)) {
        $db->prepare(
            "INSERT INTO products
               (sku, name, category_id, metal_type, purity, gross_weight_g, net_weight_g,
                quantity, reorder_level, purchase_cost, selling_price, image, description)
             VALUES (?,?,?,?,?,?,?,0,?,?,?,?,?)"
        )->execute([
            trim($_POST['sku']),
            trim($_POST['name']),
            (int)$_POST['category_id'],
            $_POST['metal_type'],
            trim($_POST['purity'] ?? ''),
            (float)$_POST['gross_weight_g'],
            (float)$_POST['net_weight_g'],
            (int)$_POST['reorder_level'],
            (float)$_POST['purchase_cost'],
            (float)$_POST['selling_price'],
            $imageFilename,
            trim($_POST['description'] ?? ''),
        ]);
        $newId = (int)$db->lastInsertId();
        logActivity('product_created', 'products', $newId, "Product '{$_POST['name']}' created");
        setFlash('success', "Product '{$_POST['name']}' added successfully.");
        redirect('/jeweltrack/modules/products/view.php?id=' . $newId);
    }
}
?>

<div class="page-header">
  <h1><i class="bi bi-plus-circle text-gold me-2"></i>Add New Product</h1>
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/jeweltrack/modules/products/index.php">Inventory</a></li>
      <li class="breadcrumb-item active">Add Product</li>
    </ol>
  </nav>
</div>

<?php if ($errors): ?>
<div class="alert alert-danger">
  <i class="bi bi-x-circle-fill me-2"></i>
  <strong>Please fix the following errors:</strong>
  <ul class="mb-0 mt-1">
    <?php foreach ($errors as $err): ?>
      <li><?= e($err) ?></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<form method="POST" action="/jeweltrack/modules/products/create.php"
      enctype="multipart/form-data" novalidate>
  <?= csrfField() ?>

  <div class="row g-4">

    <!-- Left Column -->
    <div class="col-lg-8">
      <div class="jt-card">
        <div class="jt-card-header"><h2>Product Details</h2></div>
        <div class="jt-card-body">

          <div class="row g-3">
            <div class="col-md-6">
              <label for="sku" class="form-label">SKU / Product Code <span class="text-danger">*</span></label>
              <input type="text" id="sku" name="sku" class="form-control <?= isset($errors['sku'])?'is-invalid':'' ?>"
                     value="<?= e($old['sku'] ?? '') ?>" placeholder="JT-RG-001" maxlength="50" required>
              <div class="invalid-feedback"><?= e($errors['sku'] ?? '') ?></div>
            </div>
            <div class="col-md-6">
              <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
              <input type="text" id="name" name="name" class="form-control <?= isset($errors['name'])?'is-invalid':'' ?>"
                     value="<?= e($old['name'] ?? '') ?>" placeholder="Classic Gold Ring" maxlength="200" required>
              <div class="invalid-feedback"><?= e($errors['name'] ?? '') ?></div>
            </div>

            <div class="col-md-6">
              <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
              <select id="category_id" name="category_id" class="form-select <?= isset($errors['category_id'])?'is-invalid':'' ?>" required>
                <option value="">— Select Category —</option>
                <?php foreach ($categories as $cat): ?>
                  <option value="<?= $cat['id'] ?>" <?= ($old['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>>
                    <?= e($cat['name']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <div class="invalid-feedback"><?= e($errors['category_id'] ?? '') ?></div>
            </div>

            <div class="col-md-3">
              <label for="metal_type" class="form-label">Metal Type <span class="text-danger">*</span></label>
              <select id="metal_type" name="metal_type" class="form-select <?= isset($errors['metal_type'])?'is-invalid':'' ?>" required>
                <?php foreach (['Gold','Silver','Platinum','Rhodium','Other'] as $m): ?>
                  <option value="<?= $m ?>" <?= ($old['metal_type'] ?? '') === $m ? 'selected' : '' ?>><?= $m ?></option>
                <?php endforeach; ?>
              </select>
              <div class="invalid-feedback"><?= e($errors['metal_type'] ?? '') ?></div>
            </div>

            <div class="col-md-3">
              <label for="purity" class="form-label">Purity</label>
              <input type="text" id="purity" name="purity" class="form-control"
                     value="<?= e($old['purity'] ?? '') ?>" placeholder="22K, 925, 950…" maxlength="30">
            </div>

            <div class="col-md-6">
              <label for="gross_weight_g" class="form-label">Gross Weight (grams)</label>
              <input type="number" id="gross_weight_g" name="gross_weight_g"
                     class="form-control <?= isset($errors['gross_weight_g'])?'is-invalid':'' ?>"
                     step="0.001" min="0" value="<?= e($old['gross_weight_g'] ?? '0') ?>">
              <div class="invalid-feedback"><?= e($errors['gross_weight_g'] ?? '') ?></div>
            </div>
            <div class="col-md-6">
              <label for="net_weight_g" class="form-label">Net Metal Weight (grams)</label>
              <input type="number" id="net_weight_g" name="net_weight_g"
                     class="form-control <?= isset($errors['net_weight_g'])?'is-invalid':'' ?>"
                     step="0.001" min="0" value="<?= e($old['net_weight_g'] ?? '0') ?>">
              <div class="invalid-feedback"><?= e($errors['net_weight_g'] ?? '') ?></div>
            </div>

            <div class="col-md-6">
              <label for="purchase_cost" class="form-label">Purchase Cost per Piece (<?= $sym ?>) <span class="text-danger">*</span></label>
              <input type="number" id="purchase_cost" name="purchase_cost"
                     class="form-control <?= isset($errors['purchase_cost'])?'is-invalid':'' ?>"
                     step="0.01" min="0" value="<?= e($old['purchase_cost'] ?? '') ?>" required>
              <div class="invalid-feedback"><?= e($errors['purchase_cost'] ?? '') ?></div>
            </div>
            <div class="col-md-6">
              <label for="selling_price" class="form-label">Selling Price per Piece (<?= $sym ?>) <span class="text-danger">*</span></label>
              <input type="number" id="selling_price" name="selling_price"
                     class="form-control <?= isset($errors['selling_price'])?'is-invalid':'' ?>"
                     step="0.01" min="0" value="<?= e($old['selling_price'] ?? '') ?>" required>
              <div class="invalid-feedback"><?= e($errors['selling_price'] ?? '') ?></div>
            </div>

            <div class="col-md-4">
              <label for="reorder_level" class="form-label">Reorder Level (pieces)</label>
              <input type="number" id="reorder_level" name="reorder_level"
                     class="form-control <?= isset($errors['reorder_level'])?'is-invalid':'' ?>"
                     min="0" value="<?= e($old['reorder_level'] ?? '2') ?>">
              <div class="invalid-feedback"><?= e($errors['reorder_level'] ?? '') ?></div>
            </div>

            <div class="col-12">
              <label for="description" class="form-label">Description</label>
              <textarea id="description" name="description" class="form-control" rows="3"
                        placeholder="Optional product description…"><?= e($old['description'] ?? '') ?></textarea>
            </div>
          </div>
        </div><!-- /.jt-card-body -->
      </div><!-- /.jt-card -->
    </div><!-- col-lg-8 -->

    <!-- Right Column -->
    <div class="col-lg-4">
      <div class="jt-card mb-3">
        <div class="jt-card-header"><h2>Product Image</h2></div>
        <div class="jt-card-body">
          <label for="image" class="form-label">Upload Image (JPEG/PNG/WebP, max 2 MB)</label>
          <input type="file" id="image" name="image"
                 class="form-control <?= isset($errors['image'])?'is-invalid':'' ?>"
                 accept=".jpg,.jpeg,.png,.webp">
          <div class="invalid-feedback"><?= e($errors['image'] ?? '') ?></div>
          <small class="text-muted mt-1 d-block">Image will be displayed in inventory and product pages.</small>
          <div id="imgPreviewWrap" class="mt-2 d-none">
            <img id="imgPreview" src="" alt="Preview" class="img-fluid rounded-10 border">
          </div>
        </div>
      </div>

      <div class="jt-card">
        <div class="jt-card-body">
          <div class="alert alert-info mb-3" style="font-size:0.8rem;">
            <i class="bi bi-info-circle me-1"></i>
            <strong>Stock Quantity</strong> starts at 0. Record a purchase or use Stock Adjustment to add stock.
          </div>
          <div class="d-grid gap-2">
            <button type="submit" class="btn btn-gold">
              <i class="bi bi-check-lg me-1"></i>Save Product
            </button>
            <a href="/jeweltrack/modules/products/index.php" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </div>
      </div>
    </div><!-- col-lg-4 -->

  </div><!-- row -->
</form>

<script>
document.getElementById('image')?.addEventListener('change', function() {
  const file = this.files[0];
  if (file) {
    const wrap = document.getElementById('imgPreviewWrap');
    const img  = document.getElementById('imgPreview');
    img.src = URL.createObjectURL(file);
    wrap.classList.remove('d-none');
  }
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
