<?php
/**
 * JewelTrack — Product Detail View
 */

$pageTitle  = 'Product Details';
$activePage = 'products';
require_once __DIR__ . '/../../includes/header.php';

$db  = getDB();
$sym = currencySymbol();
$id  = (int)($_GET['id'] ?? 0);
if (!$id) { redirect('/jeweltrack/modules/products/index.php'); }

$product = $db->prepare(
    "SELECT p.*, c.name AS category FROM products p
     JOIN categories c ON c.id=p.category_id WHERE p.id=?"
);
$product->execute([$id]);
$p = $product->fetch();
if (!$p) { setFlash('error','Product not found.'); redirect('/jeweltrack/modules/products/index.php'); }

// Recent stock movements
$movements = $db->prepare(
    "SELECT sm.*, u.name AS user_name FROM stock_movements sm
     JOIN users u ON u.id=sm.user_id
     WHERE sm.product_id=? ORDER BY sm.created_at DESC LIMIT 15"
);
$movements->execute([$id]);
$moves = $movements->fetchAll();

// Sales count
$salesCount = $db->prepare("SELECT COALESCE(SUM(si.quantity),0) FROM sale_items si WHERE si.product_id=?");
$salesCount->execute([$id]);
$totalSold = (int)$salesCount->fetchColumn();
?>

<div class="page-header d-flex align-items-start justify-content-between flex-wrap gap-2">
  <div>
    <h1><i class="bi bi-gem text-gold me-2"></i><?= e($p['name']) ?></h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/jeweltrack/modules/products/index.php">Inventory</a></li>
        <li class="breadcrumb-item active"><?= e($p['sku']) ?></li>
      </ol>
    </nav>
  </div>
  <?php if (isAdmin()): ?>
  <div class="d-flex gap-2">
    <a href="/jeweltrack/modules/products/edit.php?id=<?= $p['id'] ?>" class="btn btn-gold btn-sm">
      <i class="bi bi-pencil me-1"></i>Edit
    </a>
    <a href="/jeweltrack/modules/stock/adjust.php?product_id=<?= $p['id'] ?>" class="btn btn-emerald btn-sm">
      <i class="bi bi-sliders me-1"></i>Adjust Stock
    </a>
  </div>
  <?php endif; ?>
</div>

<div class="row g-4">
  <!-- Product Info -->
  <div class="col-lg-4">
    <div class="jt-card mb-3">
      <div class="jt-card-body text-center">
        <?php if ($p['image']): ?>
          <img src="/jeweltrack/assets/uploads/products/<?= e($p['image']) ?>"
               alt="<?= e($p['name']) ?>" class="img-fluid rounded-10 mb-3" style="max-height:220px;object-fit:cover;">
        <?php else: ?>
          <div class="empty-state py-3">
            <i class="bi bi-gem" style="font-size:4rem;color:var(--clr-gold);opacity:0.7;"></i>
            <p class="mt-2 text-muted fs-13">No image uploaded</p>
          </div>
        <?php endif; ?>
        <h2 class="fw-700" style="font-size:1.1rem;"><?= e($p['name']) ?></h2>
        <p class="text-muted fs-13 mb-2"><code><?= e($p['sku']) ?></code></p>
        <?= stockBadge((int)$p['quantity'], (int)$p['reorder_level']) ?>
        <?php if (!$p['is_active']): ?>
          <span class="badge bg-secondary ms-1">Inactive</span>
        <?php endif; ?>
      </div>
    </div>

    <div class="jt-card">
      <div class="jt-card-header"><h3>Quick Stats</h3></div>
      <div class="jt-card-body">
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted fs-13">In Stock</span>
          <span class="fw-700 <?= $p['quantity']==0?'text-danger':($p['quantity']<=$p['reorder_level']?'text-warning':'') ?>">
            <?= (int)$p['quantity'] ?> pcs
          </span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted fs-13">Total Sold</span>
          <span class="fw-600"><?= $totalSold ?> pcs</span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted fs-13">Purchase Cost</span>
          <span class="fw-600"><?= formatMoney((float)$p['purchase_cost'], $sym) ?></span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="text-muted fs-13">Selling Price</span>
          <span class="fw-600 text-emerald"><?= formatMoney((float)$p['selling_price'], $sym) ?></span>
        </div>
        <div class="d-flex justify-content-between py-2">
          <span class="text-muted fs-13">Margin</span>
          <?php
          $margin = $p['purchase_cost'] > 0
            ? round(($p['selling_price'] - $p['purchase_cost']) / $p['purchase_cost'] * 100, 1)
            : 0;
          ?>
          <span class="fw-600 text-success">+<?= $margin ?>%</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Details + Movements -->
  <div class="col-lg-8">
    <div class="jt-card mb-3">
      <div class="jt-card-header"><h2>Product Specifications</h2></div>
      <div class="jt-card-body">
        <div class="row g-3">
          <div class="col-6 col-md-4">
            <p class="text-muted fs-13 mb-1">Category</p>
            <p class="fw-600"><?= e($p['category']) ?></p>
          </div>
          <div class="col-6 col-md-4">
            <p class="text-muted fs-13 mb-1">Metal Type</p>
            <p class="fw-600"><?= e($p['metal_type']) ?></p>
          </div>
          <div class="col-6 col-md-4">
            <p class="text-muted fs-13 mb-1">Purity</p>
            <p class="fw-600"><?= e($p['purity'] ?: '—') ?></p>
          </div>
          <div class="col-6 col-md-4">
            <p class="text-muted fs-13 mb-1">Gross Weight</p>
            <p class="fw-600"><?= number_format((float)$p['gross_weight_g'], 3) ?> g</p>
          </div>
          <div class="col-6 col-md-4">
            <p class="text-muted fs-13 mb-1">Net Metal Weight</p>
            <p class="fw-600"><?= number_format((float)$p['net_weight_g'], 3) ?> g</p>
          </div>
          <div class="col-6 col-md-4">
            <p class="text-muted fs-13 mb-1">Reorder Level</p>
            <p class="fw-600"><?= (int)$p['reorder_level'] ?> pcs</p>
          </div>
          <?php if ($p['description']): ?>
          <div class="col-12">
            <p class="text-muted fs-13 mb-1">Description</p>
            <p class="mb-0"><?= nl2br(e($p['description'])) ?></p>
          </div>
          <?php endif; ?>
          <div class="col-6 col-md-4">
            <p class="text-muted fs-13 mb-1">Added On</p>
            <p class="fw-600"><?= date('d M Y', strtotime($p['created_at'])) ?></p>
          </div>
          <div class="col-6 col-md-4">
            <p class="text-muted fs-13 mb-1">Last Updated</p>
            <p class="fw-600"><?= date('d M Y H:i', strtotime($p['updated_at'])) ?></p>
          </div>
        </div>
      </div>
    </div>

    <!-- Stock Movement History -->
    <div class="jt-card">
      <div class="jt-card-header">
        <h2><i class="bi bi-arrow-left-right me-2 text-gold"></i>Stock Movement History</h2>
        <a href="/jeweltrack/modules/stock/index.php?product_id=<?= $id ?>" class="btn btn-sm btn-outline-gold">Full History</a>
      </div>
      <div class="table-responsive">
        <?php if ($moves): ?>
        <table class="jt-table">
          <thead>
            <tr>
              <th>Date &amp; Time</th>
              <th>Type</th>
              <th>Change</th>
              <th>Before</th>
              <th>After</th>
              <th>By</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($moves as $m): ?>
            <?php
            $typeLabel = match($m['movement_type']) {
              'opening_stock'      => ['Opening Stock',     'secondary'],
              'purchase_received'  => ['Purchase In',       'success'],
              'sale_dispatched'    => ['Sale Out',          'danger'],
              'customer_return'    => ['Customer Return',   'info'],
              'supplier_return'    => ['Supplier Return',   'warning'],
              'manual_correction'  => ['Manual Adj.',       'primary'],
              default              => [$m['movement_type'], 'secondary'],
            };
            ?>
            <tr>
              <td class="text-muted fs-13"><?= date('d M Y H:i', strtotime($m['created_at'])) ?></td>
              <td><span class="badge bg-<?= $typeLabel[1] ?>"><?= $typeLabel[0] ?></span></td>
              <td>
                <span class="fw-700 <?= $m['quantity'] > 0 ? 'text-success' : 'text-danger' ?>">
                  <?= $m['quantity'] > 0 ? '+' : '' ?><?= (int)$m['quantity'] ?>
                </span>
              </td>
              <td class="text-muted"><?= (int)$m['qty_before'] ?></td>
              <td class="fw-600"><?= (int)$m['qty_after'] ?></td>
              <td class="fs-13"><?= e($m['user_name']) ?></td>
              <td class="text-muted fs-13"><?= e($m['notes'] ?? '—') ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state"><i class="bi bi-arrow-left-right d-block"></i><p>No stock movements yet</p></div>
        <?php endif; ?>
      </div>
    </div>

  </div><!-- col-lg-8 -->
</div><!-- row -->

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
