<?php
/**
 * JewelTrack — Edit Product
 */

$pageTitle  = 'Edit Product';
$activePage = 'products';
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/validation.php';
requireAdmin();

$db  = getDB();
$id  = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
if (!$id) redirect('/jeweltrack/modules/products/index.php');

$product = $db->prepare("SELECT * FROM products WHERE id=?");
$product->execute([$id]);
$p = $product->fetch();
if (!$p) { setFlash('error','Product not found.'); redirect('/jeweltrack/modules/products/index.php'); }

$categories = $db->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();
$errors     = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $v = new Validator($_POST);
    $v->required('sku',          'SKU')
      ->required('name',         'Product Name')
      ->required('category_id',  'Category')
      ->required('metal_type',   'Metal Type')
      ->required('purchase_cost','Purchase Cost')
      ->required('selling_price','Selling Price')
      ->numeric('purchase_cost','Purchase Cost', 0)
      ->numeric('selling_price','Selling Price', 0)
      ->numeric('gross_weight_g','Gross Weight',  0)
      ->numeric('net_weight_g',  'Net Weight',    0)
      ->integer('reorder_level', 'Reorder Level', 0)
      ->unique('sku', 'SKU', 'products', 'sku', $id)
      ->inList('metal_type','Metal Type',['Gold','Silver','Platinum','Rhodium','Other']);

    $errors = $v->errors();

    // Handle image
    $imageFilename = $p['image'];
    if (!empty($_FILES['image']['name'])) {
        $uploadResult = uploadProductImage($_FILES['image']);
        if (!$uploadResult['success']) {
            $errors['image'] = $uploadResult['message'];
        } else {
            // Delete old image
            if ($imageFilename && file_exists(UPLOAD_PATH . $imageFilename)) {
                @unlink(UPLOAD_PATH . $imageFilename);
            }
            $imageFilename = $uploadResult['filename'];
        }
    }

    if (empty($errors)) {
        $db->prepare(
            "UPDATE products SET
               sku=?, name=?, category_id=?, metal_type=?, purity=?,
               gross_weight_g=?, net_weight_g=?, reorder_level=?,
               purchase_cost=?, selling_price=?, image=?, description=?
             WHERE id=?"
        )->execute([
            trim($_POST['sku']),
            trim($_POST['name']),
            (int)$_POST['category_id'],
            $_POST['metal_type'],
            trim($_POST['purity'] ?? ''),
            (float)$_POST['gross_weight_g'],
            (float)$_POST['net_weight_g'],
            (int)$_POST['reorder_level'],
            (float)$_POST['purchase_cost'],
            (float)$_POST['selling_price'],
            $imageFilename,
            trim($_POST['description'] ?? ''),
            $id,
        ]);
        logActivity('product_updated', 'products', $id, "Product '{$_POST['name']}' updated");
        setFlash('success', "Product updated successfully.");
        redirect('/jeweltrack/modules/products/view.php?id=' . $id);
    }
    // Repopulate $p with POST data on error
    $p = array_merge($p, $_POST);
}
?>

<div class="page-header">
  <h1><i class="bi bi-pencil-square text-gold me-2"></i>Edit Product</h1>
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/jeweltrack/modules/products/index.php">Inventory</a></li>
      <li class="breadcrumb-item"><a href="/jeweltrack/modules/products/view.php?id=<?= $id ?>"><?= e($p['sku']) ?></a></li>
      <li class="breadcrumb-item active">Edit</li>
    </ol>
  </nav>
</div>

<?php if ($errors): ?>
<div class="alert alert-danger">
  <i class="bi bi-x-circle-fill me-2"></i><strong>Please fix errors:</strong>
  <ul class="mb-0 mt-1"><?php foreach($errors as $e2): ?><li><?= e($e2) ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<div class="alert alert-warning fs-13">
  <i class="bi bi-exclamation-triangle-fill me-1"></i>
  <strong>Note:</strong> Editing this form will NOT change the stock quantity. Use
  <a href="/jeweltrack/modules/stock/adjust.php?product_id=<?= $id ?>">Stock Adjustment</a> to change quantity.
</div>

<form method="POST" enctype="multipart/form-data" novalidate>
  <?= csrfField() ?>
  <input type="hidden" name="id" value="<?= $id ?>">

  <div class="row g-4">
    <div class="col-lg-8">
      <div class="jt-card">
        <div class="jt-card-header"><h2>Product Details</h2></div>
        <div class="jt-card-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label for="sku" class="form-label">SKU <span class="text-danger">*</span></label>
              <input type="text" id="sku" name="sku" class="form-control <?= isset($errors['sku'])?'is-invalid':'' ?>"
                     value="<?= e($p['sku']) ?>" required maxlength="50">
              <div class="invalid-feedback"><?= e($errors['sku'] ?? '') ?></div>
            </div>
            <div class="col-md-6">
              <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
              <input type="text" id="name" name="name" class="form-control <?= isset($errors['name'])?'is-invalid':'' ?>"
                     value="<?= e($p['name']) ?>" required maxlength="200">
              <div class="invalid-feedback"><?= e($errors['name'] ?? '') ?></div>
            </div>
            <div class="col-md-6">
              <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
              <select id="category_id" name="category_id" class="form-select" required>
                <option value="">— Select —</option>
                <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>" <?= $p['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                  <?= e($cat['name']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-3">
              <label for="metal_type" class="form-label">Metal Type <span class="text-danger">*</span></label>
              <select id="metal_type" name="metal_type" class="form-select" required>
                <?php foreach (['Gold','Silver','Platinum','Rhodium','Other'] as $m): ?>
                <option value="<?= $m ?>" <?= $p['metal_type']===$m?'selected':'' ?>><?= $m ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-3">
              <label for="purity" class="form-label">Purity</label>
              <input type="text" id="purity" name="purity" class="form-control" value="<?= e($p['purity']) ?>" maxlength="30">
            </div>
            <div class="col-md-6">
              <label for="gross_weight_g" class="form-label">Gross Weight (g)</label>
              <input type="number" id="gross_weight_g" name="gross_weight_g" class="form-control"
                     step="0.001" min="0" value="<?= e($p['gross_weight_g']) ?>">
            </div>
            <div class="col-md-6">
              <label for="net_weight_g" class="form-label">Net Metal Weight (g)</label>
              <input type="number" id="net_weight_g" name="net_weight_g" class="form-control"
                     step="0.001" min="0" value="<?= e($p['net_weight_g']) ?>">
            </div>
            <div class="col-md-6">
              <label for="purchase_cost" class="form-label">Purchase Cost (₹) <span class="text-danger">*</span></label>
              <input type="number" id="purchase_cost" name="purchase_cost" class="form-control"
                     step="0.01" min="0" value="<?= e($p['purchase_cost']) ?>" required>
            </div>
            <div class="col-md-6">
              <label for="selling_price" class="form-label">Selling Price (₹) <span class="text-danger">*</span></label>
              <input type="number" id="selling_price" name="selling_price" class="form-control"
                     step="0.01" min="0" value="<?= e($p['selling_price']) ?>" required>
            </div>
            <div class="col-md-4">
              <label for="reorder_level" class="form-label">Reorder Level</label>
              <input type="number" id="reorder_level" name="reorder_level" class="form-control"
                     min="0" value="<?= e($p['reorder_level']) ?>">
            </div>
            <div class="col-12">
              <label for="description" class="form-label">Description</label>
              <textarea id="description" name="description" class="form-control" rows="3"><?= e($p['description']) ?></textarea>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="jt-card mb-3">
        <div class="jt-card-header"><h2>Product Image</h2></div>
        <div class="jt-card-body">
          <?php if ($p['image']): ?>
          <img src="/jeweltrack/assets/uploads/products/<?= e($p['image']) ?>" alt="Current"
               class="img-fluid rounded-10 border mb-2">
          <?php endif; ?>
          <label for="image" class="form-label">Replace Image</label>
          <input type="file" id="image" name="image" class="form-control" accept=".jpg,.jpeg,.png,.webp">
          <div class="invalid-feedback"><?= e($errors['image'] ?? '') ?></div>
        </div>
      </div>
      <div class="jt-card">
        <div class="jt-card-body">
          <div class="d-grid gap-2">
            <button type="submit" class="btn btn-gold"><i class="bi bi-check-lg me-1"></i>Update Product</button>
            <a href="/jeweltrack/modules/products/view.php?id=<?= $id ?>" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
