-- ============================================================
-- JewelTrack - Jewellery Inventory & Stock Management System
-- Database: jeweltrack_db
-- MySQL 8.0+ / MariaDB 10.4+
-- Engine: InnoDB (for transaction support)
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- Create and use database
CREATE DATABASE IF NOT EXISTS `jeweltrack_db`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `jeweltrack_db`;

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE `users` (
  `id`            INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(120)     NOT NULL,
  `email`         VARCHAR(180)     NOT NULL,
  `password_hash` VARCHAR(255)     NOT NULL,
  `role`          ENUM('admin','staff') NOT NULL DEFAULT 'staff',
  `is_active`     TINYINT(1)       NOT NULL DEFAULT 1,
  `last_login_at` DATETIME         DEFAULT NULL,
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: categories
-- ============================================================
CREATE TABLE `categories` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(100)  NOT NULL,
  `description` TEXT          DEFAULT NULL,
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_categories_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: suppliers
-- ============================================================
CREATE TABLE `suppliers` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(150) NOT NULL,
  `phone`      VARCHAR(30)  DEFAULT NULL,
  `email`      VARCHAR(180) DEFAULT NULL,
  `address`    TEXT         DEFAULT NULL,
  `notes`      TEXT         DEFAULT NULL,
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: customers
-- ============================================================
CREATE TABLE `customers` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(150) NOT NULL,
  `phone`      VARCHAR(30)  DEFAULT NULL,
  `email`      VARCHAR(180) DEFAULT NULL,
  `address`    TEXT         DEFAULT NULL,
  `notes`      TEXT         DEFAULT NULL,
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: products
-- ============================================================
CREATE TABLE `products` (
  `id`              INT UNSIGNED      NOT NULL AUTO_INCREMENT,
  `sku`             VARCHAR(50)       NOT NULL,
  `name`            VARCHAR(200)      NOT NULL,
  `category_id`     INT UNSIGNED      NOT NULL,
  `metal_type`      ENUM('Gold','Silver','Platinum','Rhodium','Other') NOT NULL DEFAULT 'Gold',
  `purity`          VARCHAR(30)       DEFAULT NULL  COMMENT 'e.g. 22K, 18K, 925, etc.',
  `gross_weight_g`  DECIMAL(10,3)     NOT NULL DEFAULT 0.000,
  `net_weight_g`    DECIMAL(10,3)     NOT NULL DEFAULT 0.000,
  `quantity`        INT               NOT NULL DEFAULT 0,
  `reorder_level`   INT               NOT NULL DEFAULT 2,
  `purchase_cost`   DECIMAL(12,2)     NOT NULL DEFAULT 0.00,
  `selling_price`   DECIMAL(12,2)     NOT NULL DEFAULT 0.00,
  `image`           VARCHAR(255)      DEFAULT NULL,
  `description`     TEXT              DEFAULT NULL,
  `is_active`       TINYINT(1)        NOT NULL DEFAULT 1,
  `created_at`      DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_products_sku` (`sku`),
  KEY `idx_products_category` (`category_id`),
  KEY `idx_products_metal` (`metal_type`),
  KEY `idx_products_active` (`is_active`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: stock_movements
-- ============================================================
CREATE TABLE `stock_movements` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id`    INT UNSIGNED NOT NULL,
  `movement_type` ENUM('opening_stock','purchase_received','sale_dispatched',
                       'customer_return','supplier_return','manual_correction') NOT NULL,
  `quantity`      INT          NOT NULL COMMENT 'positive = in, negative = out',
  `qty_before`    INT          NOT NULL,
  `qty_after`     INT          NOT NULL,
  `reference_id`  INT UNSIGNED DEFAULT NULL COMMENT 'purchase_id or sale_id',
  `reference_type`VARCHAR(20)  DEFAULT NULL COMMENT 'purchase or sale',
  `notes`         TEXT         DEFAULT NULL,
  `user_id`       INT UNSIGNED NOT NULL,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sm_product` (`product_id`),
  KEY `idx_sm_type`    (`movement_type`),
  KEY `idx_sm_user`    (`user_id`),
  KEY `idx_sm_created` (`created_at`),
  CONSTRAINT `fk_sm_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_sm_user`    FOREIGN KEY (`user_id`)    REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: purchases
-- ============================================================
CREATE TABLE `purchases` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `ref_number`     VARCHAR(30)   NOT NULL,
  `supplier_id`    INT UNSIGNED  NOT NULL,
  `purchase_date`  DATE          NOT NULL,
  `subtotal`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `discount`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `tax_rate`       DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
  `tax_amount`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `grand_total`    DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `payment_status` ENUM('paid','partial','unpaid') NOT NULL DEFAULT 'unpaid',
  `notes`          TEXT          DEFAULT NULL,
  `user_id`        INT UNSIGNED  NOT NULL,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_purchases_ref` (`ref_number`),
  KEY `idx_purchases_supplier` (`supplier_id`),
  KEY `idx_purchases_date`     (`purchase_date`),
  CONSTRAINT `fk_purchases_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `fk_purchases_user`     FOREIGN KEY (`user_id`)     REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: purchase_items
-- ============================================================
CREATE TABLE `purchase_items` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `purchase_id`     INT UNSIGNED  NOT NULL,
  `product_id`      INT UNSIGNED  NOT NULL,
  `quantity`        INT           NOT NULL,
  `unit_cost`       DECIMAL(12,2) NOT NULL,
  `line_total`      DECIMAL(14,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pi_purchase` (`purchase_id`),
  KEY `idx_pi_product`  (`product_id`),
  CONSTRAINT `fk_pi_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pi_product`  FOREIGN KEY (`product_id`)  REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: sales
-- ============================================================
CREATE TABLE `sales` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `invoice_number` VARCHAR(30)   NOT NULL,
  `customer_id`    INT UNSIGNED  DEFAULT NULL COMMENT 'NULL = walk-in customer',
  `sale_date`      DATE          NOT NULL,
  `subtotal`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `discount`       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `tax_rate`       DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
  `tax_amount`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `grand_total`    DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `payment_method` ENUM('cash','card','upi','bank_transfer','other') NOT NULL DEFAULT 'cash',
  `payment_status` ENUM('paid','partial','unpaid') NOT NULL DEFAULT 'paid',
  `notes`          TEXT          DEFAULT NULL,
  `user_id`        INT UNSIGNED  NOT NULL,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sales_invoice` (`invoice_number`),
  KEY `idx_sales_customer`   (`customer_id`),
  KEY `idx_sales_date`       (`sale_date`),
  KEY `idx_sales_user`       (`user_id`),
  CONSTRAINT `fk_sales_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sales_user`     FOREIGN KEY (`user_id`)     REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: sale_items
-- ============================================================
CREATE TABLE `sale_items` (
  `id`            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `sale_id`       INT UNSIGNED  NOT NULL,
  `product_id`    INT UNSIGNED  NOT NULL,
  `quantity`      INT           NOT NULL,
  `unit_price`    DECIMAL(12,2) NOT NULL COMMENT 'price at time of sale',
  `line_total`    DECIMAL(14,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_si_sale`    (`sale_id`),
  KEY `idx_si_product` (`product_id`),
  CONSTRAINT `fk_si_sale`    FOREIGN KEY (`sale_id`)    REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_si_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: settings
-- ============================================================
CREATE TABLE `settings` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(60)   NOT NULL,
  `setting_val` TEXT          DEFAULT NULL,
  `updated_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_settings_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: activity_logs
-- ============================================================
CREATE TABLE `activity_logs` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED DEFAULT NULL,
  `action`      VARCHAR(80)  NOT NULL,
  `entity_type` VARCHAR(40)  DEFAULT NULL,
  `entity_id`   INT UNSIGNED DEFAULT NULL,
  `description` TEXT         DEFAULT NULL,
  `ip_address`  VARCHAR(45)  DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_al_user`    (`user_id`),
  KEY `idx_al_action`  (`action`),
  KEY `idx_al_created` (`created_at`),
  CONSTRAINT `fk_al_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEED DATA
-- ============================================================

-- USERS
-- Admin password: Admin@123  (bcrypt hash)
-- Staff password: Staff@123  (bcrypt hash)
INSERT INTO `users` (`name`, `email`, `password_hash`, `role`, `is_active`) VALUES
('Admin User',  'admin@jeweltrack.com', '$2y$10$6sMqW.jSn9eetwaPuOE80eXGryKWBrRHSNgOOHAG1IThov7.gFSNq', 'admin', 1),
('Priya Sharma','priya@jeweltrack.com', '$2y$10$1IranWpG7.kcI7USDWhLx.g/Tw7j8WD50u7DiZYU.r8.3a12Kl3SS', 'staff', 1),
('Raj Mehta',  'raj@jeweltrack.com',   '$2y$10$1IranWpG7.kcI7USDWhLx.g/Tw7j8WD50u7DiZYU.r8.3a12Kl3SS', 'staff', 1);

-- CATEGORIES
INSERT INTO `categories` (`name`, `description`) VALUES
('Rings',      'All types of rings including engagement, wedding, and fashion rings'),
('Necklaces',  'Traditional and modern necklaces and haars'),
('Earrings',   'Studs, drops, jhumkas, and hoop earrings'),
('Bracelets',  'Gold, silver, and diamond bracelets'),
('Bangles',    'Traditional bangles in gold and silver'),
('Chains',     'Gold and silver chains of various lengths and styles'),
('Pendants',   'Decorative pendants and lockets'),
('Anklets',    'Payal / anklets in gold and silver'),
('Nosepins',   'Nose pins and nose rings');

-- SUPPLIERS
INSERT INTO `suppliers` (`name`, `phone`, `email`, `address`, `notes`, `is_active`) VALUES
('Rajkot Gold Traders',     '9876543210', 'info@rajkotgold.com',    '12 Gold Market, Rajkot, Gujarat 360001',    'Primary wholesale supplier for 22K gold products', 1),
('Mumbai Jewels Pvt Ltd',   '9123456780', 'sales@mumbaijewels.com', '45 Zaveri Bazaar, Mumbai, Maharashtra 400002','High-quality diamond-set pieces supplier',        1),
('Surat Silver House',      '9988776655', 'contact@suratsilver.com','8 Textile Market, Surat, Gujarat 395003',   'Specializes in silver jewellery and antiques',    1),
('Chennai Gem Exports',     '9845623170', 'gems@chennaiexport.com', '22 T. Nagar, Chennai, Tamil Nadu 600017',   'Supplier for gemstone jewellery',                 1);

-- CUSTOMERS
INSERT INTO `customers` (`name`, `phone`, `email`, `address`, `notes`, `is_active`) VALUES
('Meera Patel',      '9823456701', 'meera.patel@gmail.com',    '15 Shanti Nagar, Ahmedabad, Gujarat',       'Loyal customer since 2020',  1),
('Sunita Desai',     '9012345678', 'sunita.desai@yahoo.com',   '3 Rose Garden, Vadodara, Gujarat',          'Wedding purchase customer',  1),
('Kavita Joshi',     '9765432100', 'kavita.j@hotmail.com',     '27 MG Road, Bengaluru, Karnataka',          NULL, 1),
('Ritu Agarwal',     '9887654321', 'ritu.a@gmail.com',         '9 Civil Lines, Jaipur, Rajasthan',          'Bulk buyer for gifting',     1),
('Pooja Nair',       '9654321098', 'pooja.nair@gmail.com',     '11 Marine Drive, Kochi, Kerala',            NULL, 1),
('Anita Bose',       '9543210987', 'anita.bose@gmail.com',     '5 Park Street, Kolkata, West Bengal',       NULL, 1);

-- PRODUCTS (quantity set to match opening stock movements below)
INSERT INTO `products`
  (`sku`,`name`,`category_id`,`metal_type`,`purity`,`gross_weight_g`,`net_weight_g`,`quantity`,`reorder_level`,`purchase_cost`,`selling_price`,`description`,`is_active`)
VALUES
('JT-RG-001','Classic Solitaire Ring',       1,'Gold',   '22K', 5.500,  5.200,  8,  3,  18500.00, 22000.00, 'Elegant solitaire ring in 22K gold with a single diamond', 1),
('JT-RG-002','Floral Cluster Ring',          1,'Gold',   '18K', 4.200,  4.000,  5,  2,  14200.00, 17500.00, '18K gold ring with floral cluster design', 1),
('JT-RG-003','Silver Band Ring',             1,'Silver', '925', 8.000,  7.800,  12, 4,   1200.00,  1800.00, 'Sterling silver band ring', 1),
('JT-NK-001','Traditional Temple Necklace',  2,'Gold',   '22K',42.000, 40.500,  4,  2, 140000.00,168000.00, '22K gold temple necklace with ruby accents', 1),
('JT-NK-002','Layered Gold Chain Necklace',  2,'Gold',   '18K',18.500, 17.800,  6,  2,  62000.00, 76000.00, '18K layered gold necklace, contemporary design', 1),
('JT-NK-003','Silver Antique Necklace',      2,'Silver', '925',55.000, 52.000,  3,  2,   8500.00, 12000.00, 'Oxidised silver antique necklace', 1),
('JT-ER-001','Jhumka Earrings 22K',          3,'Gold',   '22K', 7.800,  7.500,  9,  3,  26500.00, 32000.00, 'Traditional 22K gold jhumka earring pair', 1),
('JT-ER-002','Diamond Stud Earrings',        3,'Gold',   '18K', 3.100,  2.900, 10,  3,  22000.00, 28500.00, '18K gold diamond stud earring pair', 1),
('JT-ER-003','Silver Hoop Earrings',         3,'Silver', '925', 5.500,  5.200, 15,  5,   1500.00,  2200.00, 'Sterling silver hoop earring pair', 1),
('JT-BR-001','Gold Tennis Bracelet',         4,'Gold',   '18K',14.200, 13.800,  5,  2,  47800.00, 58000.00, '18K gold tennis bracelet with CZ stones', 1),
('JT-BR-002','Silver Charm Bracelet',        4,'Silver', '925',12.000, 11.500,  8,  3,   2800.00,  4200.00, 'Sterling silver bracelet with assorted charms', 1),
('JT-BG-001','Plain Gold Bangle Set (6 pc)', 5,'Gold',   '22K',38.000, 36.000,  4,  2, 128000.00,155000.00, '22K gold plain bangle set of 6 pieces', 1),
('JT-BG-002','Silver Bangle Pair',           5,'Silver', '925',20.000, 19.200,  7,  3,   4200.00,  6000.00, 'Sterling silver bangle pair with intricate work', 1),
('JT-CH-001','22K Gold Box Chain 18inch',    6,'Gold',   '22K', 8.500,  8.200,  6,  2,  28800.00, 35000.00, '22K yellow gold box chain, 18 inches', 1),
('JT-CH-002','Silver Rope Chain 20inch',     6,'Silver', '925',10.000,  9.700, 10,  4,   2200.00,  3200.00, '925 silver rope chain, 20 inches', 1),
('JT-PD-001','Ganesh Pendant Gold',          7,'Gold',   '22K', 4.500,  4.300,  7,  2,  15300.00, 18500.00, '22K gold Ganesh ji pendant', 1),
('JT-PD-002','Heart Locket Silver',          7,'Silver', '925', 3.800,  3.600, 11,  4,    900.00,  1400.00, '925 silver heart locket pendant', 1),
('JT-AK-001','Gold Anklet Pair',             8,'Gold',   '22K', 9.500,  9.100,  3,  2,  32200.00, 39000.00, '22K gold payal pair with ghungroo', 1),
('JT-NP-001','Diamond Nosepin',              9,'Gold',   '18K', 0.600,  0.500, 20,  5,   3800.00,  5200.00, '18K gold nosepin with single diamond', 1),
('JT-RG-004','Platinum Wedding Band',        1,'Platinum','950', 6.200,  6.000,  3,  1,  45000.00, 58000.00, 'Platinum 950 plain wedding band', 1);

-- STOCK MOVEMENTS – Opening Stock (one movement per product)
INSERT INTO `stock_movements` (`product_id`,`movement_type`,`quantity`,`qty_before`,`qty_after`,`notes`,`user_id`) VALUES
(1,  'opening_stock', 8,  0, 8,  'Initial opening stock', 1),
(2,  'opening_stock', 5,  0, 5,  'Initial opening stock', 1),
(3,  'opening_stock', 12, 0, 12, 'Initial opening stock', 1),
(4,  'opening_stock', 4,  0, 4,  'Initial opening stock', 1),
(5,  'opening_stock', 6,  0, 6,  'Initial opening stock', 1),
(6,  'opening_stock', 3,  0, 3,  'Initial opening stock', 1),
(7,  'opening_stock', 9,  0, 9,  'Initial opening stock', 1),
(8,  'opening_stock', 10, 0, 10, 'Initial opening stock', 1),
(9,  'opening_stock', 15, 0, 15, 'Initial opening stock', 1),
(10, 'opening_stock', 5,  0, 5,  'Initial opening stock', 1),
(11, 'opening_stock', 8,  0, 8,  'Initial opening stock', 1),
(12, 'opening_stock', 4,  0, 4,  'Initial opening stock', 1),
(13, 'opening_stock', 7,  0, 7,  'Initial opening stock', 1),
(14, 'opening_stock', 6,  0, 6,  'Initial opening stock', 1),
(15, 'opening_stock', 10, 0, 10, 'Initial opening stock', 1),
(16, 'opening_stock', 7,  0, 7,  'Initial opening stock', 1),
(17, 'opening_stock', 11, 0, 11, 'Initial opening stock', 1),
(18, 'opening_stock', 3,  0, 3,  'Initial opening stock', 1),
(19, 'opening_stock', 20, 0, 20, 'Initial opening stock', 1),
(20, 'opening_stock', 3,  0, 3,  'Initial opening stock', 1);

-- PURCHASES (2 demo purchases)
INSERT INTO `purchases` (`ref_number`,`supplier_id`,`purchase_date`,`subtotal`,`discount`,`tax_rate`,`tax_amount`,`grand_total`,`payment_status`,`notes`,`user_id`) VALUES
('PO-2026-0001', 1, '2026-10-01', 218500.00, 0.00, 3.00, 6555.00, 225055.00, 'paid',    'Gold stock replenishment – October batch',    1),
('PO-2026-0002', 3, '2026-10-10', 15800.00,  500.00, 3.00, 459.00, 15759.00,  'partial', 'Silver items monthly restock',                2);

-- PURCHASE ITEMS
INSERT INTO `purchase_items` (`purchase_id`,`product_id`,`quantity`,`unit_cost`,`line_total`) VALUES
-- PO-2026-0001
(1, 1, 3, 18500.00, 55500.00),
(1, 7, 2, 26500.00, 53000.00),
(1, 14,2, 28800.00, 57600.00),
(1, 16,2, 15300.00, 30600.00),
(1, 19,3,  3800.00, 11400.00),
-- PO-2026-0002
(2, 3, 4,  1200.00,  4800.00),
(2, 11,3,  2800.00,  8400.00),
(2, 17,2,   900.00,  1800.00);

-- STOCK MOVEMENTS for purchases (purchase_received)
INSERT INTO `stock_movements` (`product_id`,`movement_type`,`quantity`,`qty_before`,`qty_after`,`reference_id`,`reference_type`,`notes`,`user_id`) VALUES
(1,  'purchase_received', 3,  8, 11, 1, 'purchase', 'PO-2026-0001', 1),
(7,  'purchase_received', 2,  9, 11, 1, 'purchase', 'PO-2026-0001', 1),
(14, 'purchase_received', 2,  6,  8, 1, 'purchase', 'PO-2026-0001', 1),
(16, 'purchase_received', 2,  7,  9, 1, 'purchase', 'PO-2026-0001', 1),
(19, 'purchase_received', 3, 20, 23, 1, 'purchase', 'PO-2026-0001', 1),
(3,  'purchase_received', 4, 12, 16, 2, 'purchase', 'PO-2026-0002', 2),
(11, 'purchase_received', 3,  8, 11, 2, 'purchase', 'PO-2026-0002', 2),
(17, 'purchase_received', 2, 11, 13, 2, 'purchase', 'PO-2026-0002', 2);

-- Update product quantities to reflect purchases received
UPDATE `products` SET `quantity`=11 WHERE `id`=1;
UPDATE `products` SET `quantity`=11 WHERE `id`=7;
UPDATE `products` SET `quantity`=8  WHERE `id`=14;
UPDATE `products` SET `quantity`=9  WHERE `id`=16;
UPDATE `products` SET `quantity`=23 WHERE `id`=19;
UPDATE `products` SET `quantity`=16 WHERE `id`=3;
UPDATE `products` SET `quantity`=11 WHERE `id`=11;
UPDATE `products` SET `quantity`=13 WHERE `id`=17;

-- SALES (3 demo sales)
INSERT INTO `sales` (`invoice_number`,`customer_id`,`sale_date`,`subtotal`,`discount`,`tax_rate`,`tax_amount`,`grand_total`,`payment_method`,`payment_status`,`notes`,`user_id`) VALUES
('INV-2026-0001', 1, '2026-10-05', 22000.00, 0.00,    3.00, 660.00,   22660.00, 'upi',  'paid', NULL,                   2),
('INV-2026-0002', 2, '2026-10-12', 76000.00, 2000.00, 3.00, 2220.00,  76220.00, 'cash', 'paid', 'Wedding jewellery set', 1),
('INV-2026-0003', NULL,'2026-10-15',32000.00, 0.00,    3.00, 960.00,   32960.00, 'card', 'paid', 'Walk-in customer',      2);

-- SALE ITEMS
INSERT INTO `sale_items` (`sale_id`,`product_id`,`quantity`,`unit_price`,`line_total`) VALUES
(1, 1,  1, 22000.00, 22000.00),
(2, 5,  1, 76000.00, 76000.00),
(3, 14, 1, 35000.00, 35000.00);

-- Correction: sale 3 line total vs subtotal
UPDATE `sales` SET `subtotal`=35000.00, `tax_amount`=1050.00, `grand_total`=36050.00 WHERE `id`=3;

-- STOCK MOVEMENTS for sales (sale_dispatched)
INSERT INTO `stock_movements` (`product_id`,`movement_type`,`quantity`,`qty_before`,`qty_after`,`reference_id`,`reference_type`,`notes`,`user_id`) VALUES
(1,  'sale_dispatched', -1, 11, 10, 1, 'sale', 'INV-2026-0001', 2),
(5,  'sale_dispatched', -1,  6,  5, 2, 'sale', 'INV-2026-0002', 1),
(14, 'sale_dispatched', -1,  8,  7, 3, 'sale', 'INV-2026-0003', 2);

-- Update quantities after sales
UPDATE `products` SET `quantity`=10 WHERE `id`=1;
UPDATE `products` SET `quantity`=5  WHERE `id`=5;
UPDATE `products` SET `quantity`=7  WHERE `id`=14;

-- SETTINGS
INSERT INTO `settings` (`setting_key`, `setting_val`) VALUES
('shop_name',           'JewelTrack Store'),
('shop_phone',          '+91 98765 43210'),
('shop_email',          'contact@jeweltrack.com'),
('shop_address',        '123 Jewellery Market, Gold Street, Mumbai - 400001'),
('currency_symbol',     '₹'),
('currency_code',       'INR'),
('tax_rate',            '3'),
('tax_label',           'GST'),
('invoice_footer',      'Thank you for shopping with us! All sales are final. Goods once sold will not be taken back.'),
('low_stock_threshold', '2'),
('app_version',         '1.0.0');

COMMIT;
